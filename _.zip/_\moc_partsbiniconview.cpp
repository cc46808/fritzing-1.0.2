/****************************************************************************
** Meta object code from reading C++ file 'partsbiniconview.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/partsbinpalette/partsbiniconview.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'partsbiniconview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPartsBinIconViewENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPartsBinIconViewENDCLASS = QtMocHelpers::stringData(
    "PartsBinIconView",
    "informItemMoved",
    "",
    "fromIndex",
    "toIndex",
    "selectionChanged",
    "index",
    "settingItem",
    "setSelected",
    "position",
    "doEmit",
    "informNewSelection",
    "itemMoved",
    "showContextMenu",
    "pos"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPartsBinIconViewENDCLASS_t {
    uint offsetsAndSizes[30];
    char stringdata0[17];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[10];
    char stringdata4[8];
    char stringdata5[17];
    char stringdata6[6];
    char stringdata7[12];
    char stringdata8[12];
    char stringdata9[9];
    char stringdata10[7];
    char stringdata11[19];
    char stringdata12[10];
    char stringdata13[16];
    char stringdata14[4];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPartsBinIconViewENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPartsBinIconViewENDCLASS_t qt_meta_stringdata_CLASSPartsBinIconViewENDCLASS = {
    {
        QT_MOC_LITERAL(0, 16),  // "PartsBinIconView"
        QT_MOC_LITERAL(17, 15),  // "informItemMoved"
        QT_MOC_LITERAL(33, 0),  // ""
        QT_MOC_LITERAL(34, 9),  // "fromIndex"
        QT_MOC_LITERAL(44, 7),  // "toIndex"
        QT_MOC_LITERAL(52, 16),  // "selectionChanged"
        QT_MOC_LITERAL(69, 5),  // "index"
        QT_MOC_LITERAL(75, 11),  // "settingItem"
        QT_MOC_LITERAL(87, 11),  // "setSelected"
        QT_MOC_LITERAL(99, 8),  // "position"
        QT_MOC_LITERAL(108, 6),  // "doEmit"
        QT_MOC_LITERAL(115, 18),  // "informNewSelection"
        QT_MOC_LITERAL(134, 9),  // "itemMoved"
        QT_MOC_LITERAL(144, 15),  // "showContextMenu"
        QT_MOC_LITERAL(160, 3)   // "pos"
    },
    "PartsBinIconView",
    "informItemMoved",
    "",
    "fromIndex",
    "toIndex",
    "selectionChanged",
    "index",
    "settingItem",
    "setSelected",
    "position",
    "doEmit",
    "informNewSelection",
    "itemMoved",
    "showContextMenu",
    "pos"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPartsBinIconViewENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   62,    2, 0x06,    1 /* Public */,
       5,    1,   67,    2, 0x06,    4 /* Public */,
       7,    0,   70,    2, 0x06,    6 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    2,   71,    2, 0x0a,    7 /* Public */,
       8,    1,   76,    2, 0x2a,   10 /* Public | MethodCloned */,
      11,    0,   79,    2, 0x0a,   12 /* Public */,
      12,    2,   80,    2, 0x0a,   13 /* Public */,
      13,    1,   85,    2, 0x09,   16 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    3,    4,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,    9,   10,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    3,    4,
    QMetaType::Void, QMetaType::QPoint,   14,

       0        // eod
};

Q_CONSTINIT const QMetaObject PartsBinIconView::staticMetaObject = { {
    QMetaObject::SuperData::link<InfoGraphicsView::staticMetaObject>(),
    qt_meta_stringdata_CLASSPartsBinIconViewENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPartsBinIconViewENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPartsBinIconViewENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PartsBinIconView, std::true_type>,
        // method 'informItemMoved'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'selectionChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'settingItem'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setSelected'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setSelected'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'informNewSelection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'itemMoved'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'showContextMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>
    >,
    nullptr
} };

void PartsBinIconView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PartsBinIconView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->informItemMoved((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 1: _t->selectionChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->settingItem(); break;
        case 3: _t->setSelected((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 4: _t->setSelected((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->informNewSelection(); break;
        case 6: _t->itemMoved((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 7: _t->showContextMenu((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PartsBinIconView::*)(int , int );
            if (_t _q_method = &PartsBinIconView::informItemMoved; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PartsBinIconView::*)(int );
            if (_t _q_method = &PartsBinIconView::selectionChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PartsBinIconView::*)();
            if (_t _q_method = &PartsBinIconView::settingItem; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject *PartsBinIconView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PartsBinIconView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPartsBinIconViewENDCLASS.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "PartsBinView"))
        return static_cast< PartsBinView*>(this);
    return InfoGraphicsView::qt_metacast(_clname);
}

int PartsBinIconView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = InfoGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void PartsBinIconView::informItemMoved(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void PartsBinIconView::selectionChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void PartsBinIconView::settingItem()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
