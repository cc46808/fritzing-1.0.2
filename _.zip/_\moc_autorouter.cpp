/****************************************************************************
** Meta object code from reading C++ file 'autorouter.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/autoroute/autorouter.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'autorouter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSAutorouterENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSAutorouterENDCLASS = QtMocHelpers::stringData(
    "Autorouter",
    "setMaximumProgress",
    "",
    "setProgressValue",
    "wantTopVisible",
    "wantBottomVisible",
    "wantBothVisible",
    "setProgressMessage",
    "setProgressMessage2",
    "setCycleMessage",
    "setCycleCount",
    "disableButtons",
    "cancel",
    "cancelTrace",
    "stopTracing",
    "useBest",
    "setMaxCycles"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSAutorouterENDCLASS_t {
    uint offsetsAndSizes[34];
    char stringdata0[11];
    char stringdata1[19];
    char stringdata2[1];
    char stringdata3[17];
    char stringdata4[15];
    char stringdata5[18];
    char stringdata6[16];
    char stringdata7[19];
    char stringdata8[20];
    char stringdata9[16];
    char stringdata10[14];
    char stringdata11[15];
    char stringdata12[7];
    char stringdata13[12];
    char stringdata14[12];
    char stringdata15[8];
    char stringdata16[13];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSAutorouterENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSAutorouterENDCLASS_t qt_meta_stringdata_CLASSAutorouterENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "Autorouter"
        QT_MOC_LITERAL(11, 18),  // "setMaximumProgress"
        QT_MOC_LITERAL(30, 0),  // ""
        QT_MOC_LITERAL(31, 16),  // "setProgressValue"
        QT_MOC_LITERAL(48, 14),  // "wantTopVisible"
        QT_MOC_LITERAL(63, 17),  // "wantBottomVisible"
        QT_MOC_LITERAL(81, 15),  // "wantBothVisible"
        QT_MOC_LITERAL(97, 18),  // "setProgressMessage"
        QT_MOC_LITERAL(116, 19),  // "setProgressMessage2"
        QT_MOC_LITERAL(136, 15),  // "setCycleMessage"
        QT_MOC_LITERAL(152, 13),  // "setCycleCount"
        QT_MOC_LITERAL(166, 14),  // "disableButtons"
        QT_MOC_LITERAL(181, 6),  // "cancel"
        QT_MOC_LITERAL(188, 11),  // "cancelTrace"
        QT_MOC_LITERAL(200, 11),  // "stopTracing"
        QT_MOC_LITERAL(212, 7),  // "useBest"
        QT_MOC_LITERAL(220, 12)   // "setMaxCycles"
    },
    "Autorouter",
    "setMaximumProgress",
    "",
    "setProgressValue",
    "wantTopVisible",
    "wantBottomVisible",
    "wantBothVisible",
    "setProgressMessage",
    "setProgressMessage2",
    "setCycleMessage",
    "setCycleCount",
    "disableButtons",
    "cancel",
    "cancelTrace",
    "stopTracing",
    "useBest",
    "setMaxCycles"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSAutorouterENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      10,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  104,    2, 0x06,    1 /* Public */,
       3,    1,  107,    2, 0x06,    3 /* Public */,
       4,    0,  110,    2, 0x06,    5 /* Public */,
       5,    0,  111,    2, 0x06,    6 /* Public */,
       6,    0,  112,    2, 0x06,    7 /* Public */,
       7,    1,  113,    2, 0x06,    8 /* Public */,
       8,    1,  116,    2, 0x06,   10 /* Public */,
       9,    1,  119,    2, 0x06,   12 /* Public */,
      10,    1,  122,    2, 0x06,   14 /* Public */,
      11,    0,  125,    2, 0x06,   16 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      12,    0,  126,    2, 0x0a,   17 /* Public */,
      13,    0,  127,    2, 0x0a,   18 /* Public */,
      14,    0,  128,    2, 0x0a,   19 /* Public */,
      15,    0,  129,    2, 0x0a,   20 /* Public */,
      16,    1,  130,    2, 0x0a,   21 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,

       0        // eod
};

Q_CONSTINIT const QMetaObject Autorouter::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSAutorouterENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSAutorouterENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSAutorouterENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Autorouter, std::true_type>,
        // method 'setMaximumProgress'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setProgressValue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'wantTopVisible'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'wantBottomVisible'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'wantBothVisible'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setProgressMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setProgressMessage2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setCycleMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setCycleCount'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'disableButtons'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cancel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cancelTrace'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'stopTracing'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'useBest'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setMaxCycles'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>
    >,
    nullptr
} };

void Autorouter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Autorouter *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->setMaximumProgress((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->setProgressValue((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->wantTopVisible(); break;
        case 3: _t->wantBottomVisible(); break;
        case 4: _t->wantBothVisible(); break;
        case 5: _t->setProgressMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 6: _t->setProgressMessage2((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->setCycleMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->setCycleCount((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 9: _t->disableButtons(); break;
        case 10: _t->cancel(); break;
        case 11: _t->cancelTrace(); break;
        case 12: _t->stopTracing(); break;
        case 13: _t->useBest(); break;
        case 14: _t->setMaxCycles((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Autorouter::*)(int );
            if (_t _q_method = &Autorouter::setMaximumProgress; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Autorouter::*)(int );
            if (_t _q_method = &Autorouter::setProgressValue; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Autorouter::*)();
            if (_t _q_method = &Autorouter::wantTopVisible; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Autorouter::*)();
            if (_t _q_method = &Autorouter::wantBottomVisible; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Autorouter::*)();
            if (_t _q_method = &Autorouter::wantBothVisible; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Autorouter::*)(const QString & );
            if (_t _q_method = &Autorouter::setProgressMessage; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Autorouter::*)(const QString & );
            if (_t _q_method = &Autorouter::setProgressMessage2; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (Autorouter::*)(const QString & );
            if (_t _q_method = &Autorouter::setCycleMessage; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (Autorouter::*)(int );
            if (_t _q_method = &Autorouter::setCycleCount; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (Autorouter::*)();
            if (_t _q_method = &Autorouter::disableButtons; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 9;
                return;
            }
        }
    }
}

const QMetaObject *Autorouter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Autorouter::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSAutorouterENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Autorouter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void Autorouter::setMaximumProgress(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Autorouter::setProgressValue(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Autorouter::wantTopVisible()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void Autorouter::wantBottomVisible()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void Autorouter::wantBothVisible()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void Autorouter::setProgressMessage(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Autorouter::setProgressMessage2(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void Autorouter::setCycleMessage(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void Autorouter::setCycleCount(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void Autorouter::disableButtons()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}
QT_WARNING_POP
