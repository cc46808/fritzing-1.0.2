/****************************************************************************
** Meta object code from reading C++ file 'htmlinfoview.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/infoview/htmlinfoview.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'htmlinfoview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSTagLabelENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSTagLabelENDCLASS = QtMocHelpers::stringData(
    "TagLabel"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSTagLabelENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[9];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSTagLabelENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSTagLabelENDCLASS_t qt_meta_stringdata_CLASSTagLabelENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8)   // "TagLabel"
    },
    "TagLabel"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSTagLabelENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject TagLabel::staticMetaObject = { {
    QMetaObject::SuperData::link<QLabel::staticMetaObject>(),
    qt_meta_stringdata_CLASSTagLabelENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSTagLabelENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSTagLabelENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<TagLabel, std::true_type>
    >,
    nullptr
} };

void TagLabel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *TagLabel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TagLabel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSTagLabelENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QLabel::qt_metacast(_clname);
}

int TagLabel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QLabel::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSHtmlInfoViewENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSHtmlInfoViewENDCLASS = QtMocHelpers::stringData(
    "HtmlInfoView",
    "clickObsoleteSignal",
    "",
    "setContent",
    "setInstanceTitle",
    "instanceTitleEnter",
    "instanceTitleLeave",
    "instanceTitleEditable",
    "editable",
    "changeLock",
    "changeSticky",
    "clickObsolete",
    "xyEntry",
    "unitsClicked",
    "rotEntry"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSHtmlInfoViewENDCLASS_t {
    uint offsetsAndSizes[30];
    char stringdata0[13];
    char stringdata1[20];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[17];
    char stringdata5[19];
    char stringdata6[19];
    char stringdata7[22];
    char stringdata8[9];
    char stringdata9[11];
    char stringdata10[13];
    char stringdata11[14];
    char stringdata12[8];
    char stringdata13[13];
    char stringdata14[9];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSHtmlInfoViewENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSHtmlInfoViewENDCLASS_t qt_meta_stringdata_CLASSHtmlInfoViewENDCLASS = {
    {
        QT_MOC_LITERAL(0, 12),  // "HtmlInfoView"
        QT_MOC_LITERAL(13, 19),  // "clickObsoleteSignal"
        QT_MOC_LITERAL(33, 0),  // ""
        QT_MOC_LITERAL(34, 10),  // "setContent"
        QT_MOC_LITERAL(45, 16),  // "setInstanceTitle"
        QT_MOC_LITERAL(62, 18),  // "instanceTitleEnter"
        QT_MOC_LITERAL(81, 18),  // "instanceTitleLeave"
        QT_MOC_LITERAL(100, 21),  // "instanceTitleEditable"
        QT_MOC_LITERAL(122, 8),  // "editable"
        QT_MOC_LITERAL(131, 10),  // "changeLock"
        QT_MOC_LITERAL(142, 12),  // "changeSticky"
        QT_MOC_LITERAL(155, 13),  // "clickObsolete"
        QT_MOC_LITERAL(169, 7),  // "xyEntry"
        QT_MOC_LITERAL(177, 12),  // "unitsClicked"
        QT_MOC_LITERAL(190, 8)   // "rotEntry"
    },
    "HtmlInfoView",
    "clickObsoleteSignal",
    "",
    "setContent",
    "setInstanceTitle",
    "instanceTitleEnter",
    "instanceTitleLeave",
    "instanceTitleEditable",
    "editable",
    "changeLock",
    "changeSticky",
    "clickObsolete",
    "xyEntry",
    "unitsClicked",
    "rotEntry"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSHtmlInfoViewENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   86,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,   87,    2, 0x09,    2 /* Protected */,
       4,    0,   88,    2, 0x09,    3 /* Protected */,
       5,    0,   89,    2, 0x09,    4 /* Protected */,
       6,    0,   90,    2, 0x09,    5 /* Protected */,
       7,    1,   91,    2, 0x09,    6 /* Protected */,
       9,    1,   94,    2, 0x09,    8 /* Protected */,
      10,    1,   97,    2, 0x09,   10 /* Protected */,
      11,    1,  100,    2, 0x09,   12 /* Protected */,
      12,    0,  103,    2, 0x09,   14 /* Protected */,
      13,    0,  104,    2, 0x09,   15 /* Protected */,
      14,    0,  105,    2, 0x09,   16 /* Protected */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject HtmlInfoView::staticMetaObject = { {
    QMetaObject::SuperData::link<QScrollArea::staticMetaObject>(),
    qt_meta_stringdata_CLASSHtmlInfoViewENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSHtmlInfoViewENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSHtmlInfoViewENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<HtmlInfoView, std::true_type>,
        // method 'clickObsoleteSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setContent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setInstanceTitle'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'instanceTitleEnter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'instanceTitleLeave'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'instanceTitleEditable'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'changeLock'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'changeSticky'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'clickObsolete'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'xyEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'unitsClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void HtmlInfoView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<HtmlInfoView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->clickObsoleteSignal(); break;
        case 1: _t->setContent(); break;
        case 2: _t->setInstanceTitle(); break;
        case 3: _t->instanceTitleEnter(); break;
        case 4: _t->instanceTitleLeave(); break;
        case 5: _t->instanceTitleEditable((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 6: _t->changeLock((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 7: _t->changeSticky((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 8: _t->clickObsolete((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 9: _t->xyEntry(); break;
        case 10: _t->unitsClicked(); break;
        case 11: _t->rotEntry(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (HtmlInfoView::*)();
            if (_t _q_method = &HtmlInfoView::clickObsoleteSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *HtmlInfoView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *HtmlInfoView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSHtmlInfoViewENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QScrollArea::qt_metacast(_clname);
}

int HtmlInfoView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QScrollArea::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void HtmlInfoView::clickObsoleteSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
