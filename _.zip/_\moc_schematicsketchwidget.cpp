/****************************************************************************
** Meta object code from reading C++ file 'schematicsketchwidget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/sketch/schematicsketchwidget.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'schematicsketchwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSSchematicSketchWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSSchematicSketchWidgetENDCLASS = QtMocHelpers::stringData(
    "SchematicSketchWidget",
    "setVoltage",
    "",
    "voltage",
    "doEmit",
    "setProp",
    "ItemBase*",
    "propName",
    "translatedPropName",
    "oldValue",
    "newValue",
    "redraw",
    "setInstanceTitleForCommand",
    "id",
    "oldTitle",
    "newTitle",
    "isUndoable",
    "updateBigDots",
    "getDroppedItemViewLayerPlacement",
    "ModelPart*",
    "modelPart",
    "ViewLayer::ViewLayerPlacement&"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSSchematicSketchWidgetENDCLASS_t {
    uint offsetsAndSizes[44];
    char stringdata0[22];
    char stringdata1[11];
    char stringdata2[1];
    char stringdata3[8];
    char stringdata4[7];
    char stringdata5[8];
    char stringdata6[10];
    char stringdata7[9];
    char stringdata8[19];
    char stringdata9[9];
    char stringdata10[9];
    char stringdata11[7];
    char stringdata12[27];
    char stringdata13[3];
    char stringdata14[9];
    char stringdata15[9];
    char stringdata16[11];
    char stringdata17[14];
    char stringdata18[33];
    char stringdata19[11];
    char stringdata20[10];
    char stringdata21[31];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSSchematicSketchWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSSchematicSketchWidgetENDCLASS_t qt_meta_stringdata_CLASSSchematicSketchWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 21),  // "SchematicSketchWidget"
        QT_MOC_LITERAL(22, 10),  // "setVoltage"
        QT_MOC_LITERAL(33, 0),  // ""
        QT_MOC_LITERAL(34, 7),  // "voltage"
        QT_MOC_LITERAL(42, 6),  // "doEmit"
        QT_MOC_LITERAL(49, 7),  // "setProp"
        QT_MOC_LITERAL(57, 9),  // "ItemBase*"
        QT_MOC_LITERAL(67, 8),  // "propName"
        QT_MOC_LITERAL(76, 18),  // "translatedPropName"
        QT_MOC_LITERAL(95, 8),  // "oldValue"
        QT_MOC_LITERAL(104, 8),  // "newValue"
        QT_MOC_LITERAL(113, 6),  // "redraw"
        QT_MOC_LITERAL(120, 26),  // "setInstanceTitleForCommand"
        QT_MOC_LITERAL(147, 2),  // "id"
        QT_MOC_LITERAL(150, 8),  // "oldTitle"
        QT_MOC_LITERAL(159, 8),  // "newTitle"
        QT_MOC_LITERAL(168, 10),  // "isUndoable"
        QT_MOC_LITERAL(179, 13),  // "updateBigDots"
        QT_MOC_LITERAL(193, 32),  // "getDroppedItemViewLayerPlacement"
        QT_MOC_LITERAL(226, 10),  // "ModelPart*"
        QT_MOC_LITERAL(237, 9),  // "modelPart"
        QT_MOC_LITERAL(247, 30)   // "ViewLayer::ViewLayerPlacement&"
    },
    "SchematicSketchWidget",
    "setVoltage",
    "",
    "voltage",
    "doEmit",
    "setProp",
    "ItemBase*",
    "propName",
    "translatedPropName",
    "oldValue",
    "newValue",
    "redraw",
    "setInstanceTitleForCommand",
    "id",
    "oldTitle",
    "newTitle",
    "isUndoable",
    "updateBigDots",
    "getDroppedItemViewLayerPlacement",
    "ModelPart*",
    "modelPart",
    "ViewLayer::ViewLayerPlacement&"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSSchematicSketchWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   44,    2, 0x0a,    1 /* Public */,
       5,    6,   49,    2, 0x0a,    4 /* Public */,
      12,    5,   62,    2, 0x0a,   11 /* Public */,
      17,    0,   73,    2, 0x09,   17 /* Protected */,
      18,    2,   74,    2, 0x09,   18 /* Protected */,

 // slots: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::Bool,    3,    4,
    QMetaType::Void, 0x80000000 | 6, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    2,    7,    8,    9,   10,   11,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::QString, QMetaType::Bool, QMetaType::Bool,   13,   14,   15,   16,    4,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 19, 0x80000000 | 21,   20,    2,

       0        // eod
};

Q_CONSTINIT const QMetaObject SchematicSketchWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<PCBSketchWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSSchematicSketchWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSSchematicSketchWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSSchematicSketchWidgetENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<SchematicSketchWidget, std::true_type>,
        // method 'setVoltage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setProp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setInstanceTitleForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'updateBigDots'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'getDroppedItemViewLayerPlacement'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement &, std::false_type>
    >,
    nullptr
} };

void SchematicSketchWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SchematicSketchWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->setVoltage((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 1: _t->setProp((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[6]))); break;
        case 2: _t->setInstanceTitleForCommand((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5]))); break;
        case 3: _t->updateBigDots(); break;
        case 4: _t->getDroppedItemViewLayerPlacement((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement&>>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *SchematicSketchWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SchematicSketchWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSSchematicSketchWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return PCBSketchWidget::qt_metacast(_clname);
}

int SchematicSketchWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = PCBSketchWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}
QT_WARNING_POP
