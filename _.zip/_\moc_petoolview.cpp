/****************************************************************************
** Meta object code from reading C++ file 'petoolview.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/partseditor/petoolview.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'petoolview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPEDoubleSpinBoxENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPEDoubleSpinBoxENDCLASS = QtMocHelpers::stringData(
    "PEDoubleSpinBox",
    "getSpinAmount",
    "",
    "double&"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPEDoubleSpinBoxENDCLASS_t {
    uint offsetsAndSizes[8];
    char stringdata0[16];
    char stringdata1[14];
    char stringdata2[1];
    char stringdata3[8];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPEDoubleSpinBoxENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPEDoubleSpinBoxENDCLASS_t qt_meta_stringdata_CLASSPEDoubleSpinBoxENDCLASS = {
    {
        QT_MOC_LITERAL(0, 15),  // "PEDoubleSpinBox"
        QT_MOC_LITERAL(16, 13),  // "getSpinAmount"
        QT_MOC_LITERAL(30, 0),  // ""
        QT_MOC_LITERAL(31, 7)   // "double&"
    },
    "PEDoubleSpinBox",
    "getSpinAmount",
    "",
    "double&"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPEDoubleSpinBoxENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   20,    2, 0x06,    1 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    2,

       0        // eod
};

Q_CONSTINIT const QMetaObject PEDoubleSpinBox::staticMetaObject = { {
    QMetaObject::SuperData::link<QDoubleSpinBox::staticMetaObject>(),
    qt_meta_stringdata_CLASSPEDoubleSpinBoxENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPEDoubleSpinBoxENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPEDoubleSpinBoxENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PEDoubleSpinBox, std::true_type>,
        // method 'getSpinAmount'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double &, std::false_type>
    >,
    nullptr
} };

void PEDoubleSpinBox::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PEDoubleSpinBox *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->getSpinAmount((*reinterpret_cast< std::add_pointer_t<double&>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PEDoubleSpinBox::*)(double & );
            if (_t _q_method = &PEDoubleSpinBox::getSpinAmount; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *PEDoubleSpinBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PEDoubleSpinBox::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPEDoubleSpinBoxENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDoubleSpinBox::qt_metacast(_clname);
}

int PEDoubleSpinBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDoubleSpinBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void PEDoubleSpinBox::getSpinAmount(double & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPEToolViewENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPEToolViewENDCLASS = QtMocHelpers::stringData(
    "PEToolView",
    "switchedConnector",
    "",
    "removedConnector",
    "QDomElement",
    "pickModeChanged",
    "busModeChanged",
    "terminalPointChanged",
    "how",
    "coord",
    "value",
    "getSpinAmount",
    "double&",
    "connectorMetadataChanged",
    "ConnectorMetadata*",
    "switchConnector",
    "QTreeWidgetItem*",
    "current",
    "previous",
    "pickModeChangedSlot",
    "busModeChangedSlot",
    "descriptionEntry",
    "typeEntry",
    "nameEntry",
    "buttonChangeTerminalPoint",
    "terminalPointEntry",
    "getSpinAmountSlot",
    "removeConnector"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPEToolViewENDCLASS_t {
    uint offsetsAndSizes[56];
    char stringdata0[11];
    char stringdata1[18];
    char stringdata2[1];
    char stringdata3[17];
    char stringdata4[12];
    char stringdata5[16];
    char stringdata6[15];
    char stringdata7[21];
    char stringdata8[4];
    char stringdata9[6];
    char stringdata10[6];
    char stringdata11[14];
    char stringdata12[8];
    char stringdata13[25];
    char stringdata14[19];
    char stringdata15[16];
    char stringdata16[17];
    char stringdata17[8];
    char stringdata18[9];
    char stringdata19[20];
    char stringdata20[19];
    char stringdata21[17];
    char stringdata22[10];
    char stringdata23[10];
    char stringdata24[26];
    char stringdata25[19];
    char stringdata26[18];
    char stringdata27[16];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPEToolViewENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPEToolViewENDCLASS_t qt_meta_stringdata_CLASSPEToolViewENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "PEToolView"
        QT_MOC_LITERAL(11, 17),  // "switchedConnector"
        QT_MOC_LITERAL(29, 0),  // ""
        QT_MOC_LITERAL(30, 16),  // "removedConnector"
        QT_MOC_LITERAL(47, 11),  // "QDomElement"
        QT_MOC_LITERAL(59, 15),  // "pickModeChanged"
        QT_MOC_LITERAL(75, 14),  // "busModeChanged"
        QT_MOC_LITERAL(90, 20),  // "terminalPointChanged"
        QT_MOC_LITERAL(111, 3),  // "how"
        QT_MOC_LITERAL(115, 5),  // "coord"
        QT_MOC_LITERAL(121, 5),  // "value"
        QT_MOC_LITERAL(127, 13),  // "getSpinAmount"
        QT_MOC_LITERAL(141, 7),  // "double&"
        QT_MOC_LITERAL(149, 24),  // "connectorMetadataChanged"
        QT_MOC_LITERAL(174, 18),  // "ConnectorMetadata*"
        QT_MOC_LITERAL(193, 15),  // "switchConnector"
        QT_MOC_LITERAL(209, 16),  // "QTreeWidgetItem*"
        QT_MOC_LITERAL(226, 7),  // "current"
        QT_MOC_LITERAL(234, 8),  // "previous"
        QT_MOC_LITERAL(243, 19),  // "pickModeChangedSlot"
        QT_MOC_LITERAL(263, 18),  // "busModeChangedSlot"
        QT_MOC_LITERAL(282, 16),  // "descriptionEntry"
        QT_MOC_LITERAL(299, 9),  // "typeEntry"
        QT_MOC_LITERAL(309, 9),  // "nameEntry"
        QT_MOC_LITERAL(319, 25),  // "buttonChangeTerminalPoint"
        QT_MOC_LITERAL(345, 18),  // "terminalPointEntry"
        QT_MOC_LITERAL(364, 17),  // "getSpinAmountSlot"
        QT_MOC_LITERAL(382, 15)   // "removeConnector"
    },
    "PEToolView",
    "switchedConnector",
    "",
    "removedConnector",
    "QDomElement",
    "pickModeChanged",
    "busModeChanged",
    "terminalPointChanged",
    "how",
    "coord",
    "value",
    "getSpinAmount",
    "double&",
    "connectorMetadataChanged",
    "ConnectorMetadata*",
    "switchConnector",
    "QTreeWidgetItem*",
    "current",
    "previous",
    "pickModeChangedSlot",
    "busModeChangedSlot",
    "descriptionEntry",
    "typeEntry",
    "nameEntry",
    "buttonChangeTerminalPoint",
    "terminalPointEntry",
    "getSpinAmountSlot",
    "removeConnector"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPEToolViewENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  122,    2, 0x06,    1 /* Public */,
       3,    1,  125,    2, 0x06,    3 /* Public */,
       5,    1,  128,    2, 0x06,    5 /* Public */,
       6,    1,  131,    2, 0x06,    7 /* Public */,
       7,    1,  134,    2, 0x06,    9 /* Public */,
       7,    2,  137,    2, 0x06,   11 /* Public */,
      11,    1,  142,    2, 0x06,   14 /* Public */,
      13,    1,  145,    2, 0x06,   16 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      15,    2,  148,    2, 0x09,   18 /* Protected */,
      19,    0,  153,    2, 0x09,   21 /* Protected */,
      20,    1,  154,    2, 0x09,   22 /* Protected */,
      21,    0,  157,    2, 0x09,   24 /* Protected */,
      22,    0,  158,    2, 0x09,   25 /* Protected */,
      23,    0,  159,    2, 0x09,   26 /* Protected */,
      24,    0,  160,    2, 0x09,   27 /* Protected */,
      25,    0,  161,    2, 0x09,   28 /* Protected */,
      26,    1,  162,    2, 0x09,   29 /* Protected */,
      27,    0,  165,    2, 0x09,   31 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, 0x80000000 | 4,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString, QMetaType::Double,    9,   10,
    QMetaType::Void, 0x80000000 | 12,    2,
    QMetaType::Void, 0x80000000 | 14,    2,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 16, 0x80000000 | 16,   17,   18,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12,    2,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject PEToolView::staticMetaObject = { {
    QMetaObject::SuperData::link<QFrame::staticMetaObject>(),
    qt_meta_stringdata_CLASSPEToolViewENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPEToolViewENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPEToolViewENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PEToolView, std::true_type>,
        // method 'switchedConnector'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'removedConnector'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QDomElement &, std::false_type>,
        // method 'pickModeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'busModeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'terminalPointChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'terminalPointChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'getSpinAmount'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double &, std::false_type>,
        // method 'connectorMetadataChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorMetadata *, std::false_type>,
        // method 'switchConnector'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTreeWidgetItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTreeWidgetItem *, std::false_type>,
        // method 'pickModeChangedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'busModeChangedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'descriptionEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'typeEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'nameEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'buttonChangeTerminalPoint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'terminalPointEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'getSpinAmountSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double &, std::false_type>,
        // method 'removeConnector'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void PEToolView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PEToolView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->switchedConnector((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->removedConnector((*reinterpret_cast< std::add_pointer_t<QDomElement>>(_a[1]))); break;
        case 2: _t->pickModeChanged((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 3: _t->busModeChanged((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 4: _t->terminalPointChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->terminalPointChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2]))); break;
        case 6: _t->getSpinAmount((*reinterpret_cast< std::add_pointer_t<double&>>(_a[1]))); break;
        case 7: _t->connectorMetadataChanged((*reinterpret_cast< std::add_pointer_t<ConnectorMetadata*>>(_a[1]))); break;
        case 8: _t->switchConnector((*reinterpret_cast< std::add_pointer_t<QTreeWidgetItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QTreeWidgetItem*>>(_a[2]))); break;
        case 9: _t->pickModeChangedSlot(); break;
        case 10: _t->busModeChangedSlot((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 11: _t->descriptionEntry(); break;
        case 12: _t->typeEntry(); break;
        case 13: _t->nameEntry(); break;
        case 14: _t->buttonChangeTerminalPoint(); break;
        case 15: _t->terminalPointEntry(); break;
        case 16: _t->getSpinAmountSlot((*reinterpret_cast< std::add_pointer_t<double&>>(_a[1]))); break;
        case 17: _t->removeConnector(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PEToolView::*)(int );
            if (_t _q_method = &PEToolView::switchedConnector; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PEToolView::*)(const QDomElement & );
            if (_t _q_method = &PEToolView::removedConnector; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PEToolView::*)(bool );
            if (_t _q_method = &PEToolView::pickModeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (PEToolView::*)(bool );
            if (_t _q_method = &PEToolView::busModeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (PEToolView::*)(const QString & );
            if (_t _q_method = &PEToolView::terminalPointChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (PEToolView::*)(const QString & , double );
            if (_t _q_method = &PEToolView::terminalPointChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (PEToolView::*)(double & );
            if (_t _q_method = &PEToolView::getSpinAmount; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (PEToolView::*)(ConnectorMetadata * );
            if (_t _q_method = &PEToolView::connectorMetadataChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
    }
}

const QMetaObject *PEToolView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PEToolView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPEToolViewENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int PEToolView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void PEToolView::switchedConnector(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void PEToolView::removedConnector(const QDomElement & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void PEToolView::pickModeChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void PEToolView::busModeChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void PEToolView::terminalPointChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void PEToolView::terminalPointChanged(const QString & _t1, double _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void PEToolView::getSpinAmount(double & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void PEToolView::connectorMetadataChanged(ConnectorMetadata * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_WARNING_POP
