/****************************************************************************
** Meta object code from reading C++ file 'programtab.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/program/programtab.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'programtab.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSSerialPortComboBoxENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSSerialPortComboBoxENDCLASS = QtMocHelpers::stringData(
    "SerialPortComboBox",
    "aboutToShow",
    ""
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSSerialPortComboBoxENDCLASS_t {
    uint offsetsAndSizes[6];
    char stringdata0[19];
    char stringdata1[12];
    char stringdata2[1];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSSerialPortComboBoxENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSSerialPortComboBoxENDCLASS_t qt_meta_stringdata_CLASSSerialPortComboBoxENDCLASS = {
    {
        QT_MOC_LITERAL(0, 18),  // "SerialPortComboBox"
        QT_MOC_LITERAL(19, 11),  // "aboutToShow"
        QT_MOC_LITERAL(31, 0)   // ""
    },
    "SerialPortComboBox",
    "aboutToShow",
    ""
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSSerialPortComboBoxENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   20,    2, 0x06,    1 /* Public */,

 // signals: parameters
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject SerialPortComboBox::staticMetaObject = { {
    QMetaObject::SuperData::link<QComboBox::staticMetaObject>(),
    qt_meta_stringdata_CLASSSerialPortComboBoxENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSSerialPortComboBoxENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSSerialPortComboBoxENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<SerialPortComboBox, std::true_type>,
        // method 'aboutToShow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void SerialPortComboBox::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SerialPortComboBox *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->aboutToShow(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SerialPortComboBox::*)();
            if (_t _q_method = &SerialPortComboBox::aboutToShow; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
    (void)_a;
}

const QMetaObject *SerialPortComboBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SerialPortComboBox::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSSerialPortComboBoxENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QComboBox::qt_metacast(_clname);
}

int SerialPortComboBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QComboBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void SerialPortComboBox::aboutToShow()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSProgramTabENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSProgramTabENDCLASS = QtMocHelpers::stringData(
    "ProgramTab",
    "wantToSave",
    "",
    "wantToSaveAs",
    "wantToRename",
    "wantToDelete",
    "deleteFile",
    "platformChanged",
    "Platform*",
    "newPlatform",
    "programWindowUpdateRequest",
    "programEnable",
    "undoEnable",
    "redoEnable",
    "cutEnable",
    "copyEnable",
    "pasteEnable",
    "platform",
    "port",
    "board",
    "filename",
    "setPlatform",
    "index",
    "setPort",
    "setBoard",
    "loadProgramFile",
    "textChanged",
    "undo",
    "enableUndo",
    "enable",
    "redo",
    "enableRedo",
    "cut",
    "enableCut",
    "copy",
    "enableCopy",
    "paste",
    "enablePaste",
    "selectAll",
    "deleteTab",
    "save",
    "saveAs",
    "rename",
    "serialMonitor",
    "sendProgram",
    "programProcessFinished",
    "exitCode",
    "QProcess::ExitStatus",
    "exitStatus",
    "programProcessReadyRead",
    "updateMenu",
    "updateSerialPorts",
    "updateBoards",
    "enableProgramButton",
    "enableMonitorButton"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSProgramTabENDCLASS_t {
    uint offsetsAndSizes[110];
    char stringdata0[11];
    char stringdata1[11];
    char stringdata2[1];
    char stringdata3[13];
    char stringdata4[13];
    char stringdata5[13];
    char stringdata6[11];
    char stringdata7[16];
    char stringdata8[10];
    char stringdata9[12];
    char stringdata10[27];
    char stringdata11[14];
    char stringdata12[11];
    char stringdata13[11];
    char stringdata14[10];
    char stringdata15[11];
    char stringdata16[12];
    char stringdata17[9];
    char stringdata18[5];
    char stringdata19[6];
    char stringdata20[9];
    char stringdata21[12];
    char stringdata22[6];
    char stringdata23[8];
    char stringdata24[9];
    char stringdata25[16];
    char stringdata26[12];
    char stringdata27[5];
    char stringdata28[11];
    char stringdata29[7];
    char stringdata30[5];
    char stringdata31[11];
    char stringdata32[4];
    char stringdata33[10];
    char stringdata34[5];
    char stringdata35[11];
    char stringdata36[6];
    char stringdata37[12];
    char stringdata38[10];
    char stringdata39[10];
    char stringdata40[5];
    char stringdata41[7];
    char stringdata42[7];
    char stringdata43[14];
    char stringdata44[12];
    char stringdata45[23];
    char stringdata46[9];
    char stringdata47[21];
    char stringdata48[11];
    char stringdata49[24];
    char stringdata50[11];
    char stringdata51[18];
    char stringdata52[13];
    char stringdata53[20];
    char stringdata54[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSProgramTabENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSProgramTabENDCLASS_t qt_meta_stringdata_CLASSProgramTabENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "ProgramTab"
        QT_MOC_LITERAL(11, 10),  // "wantToSave"
        QT_MOC_LITERAL(22, 0),  // ""
        QT_MOC_LITERAL(23, 12),  // "wantToSaveAs"
        QT_MOC_LITERAL(36, 12),  // "wantToRename"
        QT_MOC_LITERAL(49, 12),  // "wantToDelete"
        QT_MOC_LITERAL(62, 10),  // "deleteFile"
        QT_MOC_LITERAL(73, 15),  // "platformChanged"
        QT_MOC_LITERAL(89, 9),  // "Platform*"
        QT_MOC_LITERAL(99, 11),  // "newPlatform"
        QT_MOC_LITERAL(111, 26),  // "programWindowUpdateRequest"
        QT_MOC_LITERAL(138, 13),  // "programEnable"
        QT_MOC_LITERAL(152, 10),  // "undoEnable"
        QT_MOC_LITERAL(163, 10),  // "redoEnable"
        QT_MOC_LITERAL(174, 9),  // "cutEnable"
        QT_MOC_LITERAL(184, 10),  // "copyEnable"
        QT_MOC_LITERAL(195, 11),  // "pasteEnable"
        QT_MOC_LITERAL(207, 8),  // "platform"
        QT_MOC_LITERAL(216, 4),  // "port"
        QT_MOC_LITERAL(221, 5),  // "board"
        QT_MOC_LITERAL(227, 8),  // "filename"
        QT_MOC_LITERAL(236, 11),  // "setPlatform"
        QT_MOC_LITERAL(248, 5),  // "index"
        QT_MOC_LITERAL(254, 7),  // "setPort"
        QT_MOC_LITERAL(262, 8),  // "setBoard"
        QT_MOC_LITERAL(271, 15),  // "loadProgramFile"
        QT_MOC_LITERAL(287, 11),  // "textChanged"
        QT_MOC_LITERAL(299, 4),  // "undo"
        QT_MOC_LITERAL(304, 10),  // "enableUndo"
        QT_MOC_LITERAL(315, 6),  // "enable"
        QT_MOC_LITERAL(322, 4),  // "redo"
        QT_MOC_LITERAL(327, 10),  // "enableRedo"
        QT_MOC_LITERAL(338, 3),  // "cut"
        QT_MOC_LITERAL(342, 9),  // "enableCut"
        QT_MOC_LITERAL(352, 4),  // "copy"
        QT_MOC_LITERAL(357, 10),  // "enableCopy"
        QT_MOC_LITERAL(368, 5),  // "paste"
        QT_MOC_LITERAL(374, 11),  // "enablePaste"
        QT_MOC_LITERAL(386, 9),  // "selectAll"
        QT_MOC_LITERAL(396, 9),  // "deleteTab"
        QT_MOC_LITERAL(406, 4),  // "save"
        QT_MOC_LITERAL(411, 6),  // "saveAs"
        QT_MOC_LITERAL(418, 6),  // "rename"
        QT_MOC_LITERAL(425, 13),  // "serialMonitor"
        QT_MOC_LITERAL(439, 11),  // "sendProgram"
        QT_MOC_LITERAL(451, 22),  // "programProcessFinished"
        QT_MOC_LITERAL(474, 8),  // "exitCode"
        QT_MOC_LITERAL(483, 20),  // "QProcess::ExitStatus"
        QT_MOC_LITERAL(504, 10),  // "exitStatus"
        QT_MOC_LITERAL(515, 23),  // "programProcessReadyRead"
        QT_MOC_LITERAL(539, 10),  // "updateMenu"
        QT_MOC_LITERAL(550, 17),  // "updateSerialPorts"
        QT_MOC_LITERAL(568, 12),  // "updateBoards"
        QT_MOC_LITERAL(581, 19),  // "enableProgramButton"
        QT_MOC_LITERAL(601, 19)   // "enableMonitorButton"
    },
    "ProgramTab",
    "wantToSave",
    "",
    "wantToSaveAs",
    "wantToRename",
    "wantToDelete",
    "deleteFile",
    "platformChanged",
    "Platform*",
    "newPlatform",
    "programWindowUpdateRequest",
    "programEnable",
    "undoEnable",
    "redoEnable",
    "cutEnable",
    "copyEnable",
    "pasteEnable",
    "platform",
    "port",
    "board",
    "filename",
    "setPlatform",
    "index",
    "setPort",
    "setBoard",
    "loadProgramFile",
    "textChanged",
    "undo",
    "enableUndo",
    "enable",
    "redo",
    "enableRedo",
    "cut",
    "enableCut",
    "copy",
    "enableCopy",
    "paste",
    "enablePaste",
    "selectAll",
    "deleteTab",
    "save",
    "saveAs",
    "rename",
    "serialMonitor",
    "sendProgram",
    "programProcessFinished",
    "exitCode",
    "QProcess::ExitStatus",
    "exitStatus",
    "programProcessReadyRead",
    "updateMenu",
    "updateSerialPorts",
    "updateBoards",
    "enableProgramButton",
    "enableMonitorButton"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSProgramTabENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      36,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  230,    2, 0x06,    1 /* Public */,
       3,    1,  233,    2, 0x06,    3 /* Public */,
       4,    1,  236,    2, 0x06,    5 /* Public */,
       5,    2,  239,    2, 0x06,    7 /* Public */,
       7,    1,  244,    2, 0x06,   10 /* Public */,
      10,   10,  247,    2, 0x06,   12 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      21,    1,  268,    2, 0x0a,   23 /* Public */,
      21,    1,  271,    2, 0x0a,   25 /* Public */,
      23,    1,  274,    2, 0x0a,   27 /* Public */,
      24,    1,  277,    2, 0x0a,   29 /* Public */,
      25,    0,  280,    2, 0x0a,   31 /* Public */,
      26,    0,  281,    2, 0x0a,   32 /* Public */,
      27,    0,  282,    2, 0x0a,   33 /* Public */,
      28,    1,  283,    2, 0x0a,   34 /* Public */,
      30,    0,  286,    2, 0x0a,   36 /* Public */,
      31,    1,  287,    2, 0x0a,   37 /* Public */,
      32,    0,  290,    2, 0x0a,   39 /* Public */,
      33,    1,  291,    2, 0x0a,   40 /* Public */,
      34,    0,  294,    2, 0x0a,   42 /* Public */,
      35,    1,  295,    2, 0x0a,   43 /* Public */,
      36,    0,  298,    2, 0x0a,   45 /* Public */,
      37,    1,  299,    2, 0x0a,   46 /* Public */,
      38,    0,  302,    2, 0x0a,   48 /* Public */,
      39,    0,  303,    2, 0x0a,   49 /* Public */,
      40,    0,  304,    2, 0x0a,   50 /* Public */,
      41,    0,  305,    2, 0x0a,   51 /* Public */,
      42,    0,  306,    2, 0x0a,   52 /* Public */,
      43,    0,  307,    2, 0x0a,   53 /* Public */,
      44,    0,  308,    2, 0x0a,   54 /* Public */,
      45,    2,  309,    2, 0x0a,   55 /* Public */,
      49,    0,  314,    2, 0x0a,   58 /* Public */,
      50,    0,  315,    2, 0x0a,   59 /* Public */,
      51,    0,  316,    2, 0x0a,   60 /* Public */,
      52,    0,  317,    2, 0x0a,   61 /* Public */,
      53,    0,  318,    2, 0x09,   62 /* Protected */,
      54,    0,  319,    2, 0x09,   63 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,    2,    6,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, 0x80000000 | 8, QMetaType::QString, QMetaType::QString, QMetaType::QString,   11,   12,   13,   14,   15,   16,   17,   18,   19,   20,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Void, QMetaType::Int,   22,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   29,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   29,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   29,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   29,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   29,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 47,   46,   48,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject ProgramTab::staticMetaObject = { {
    QMetaObject::SuperData::link<QFrame::staticMetaObject>(),
    qt_meta_stringdata_CLASSProgramTabENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSProgramTabENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSProgramTabENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ProgramTab, std::true_type>,
        // method 'wantToSave'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'wantToSaveAs'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'wantToRename'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'wantToDelete'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'platformChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Platform *, std::false_type>,
        // method 'programWindowUpdateRequest'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<Platform *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setPlatform'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Platform *, std::false_type>,
        // method 'setPlatform'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setPort'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setBoard'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'loadProgramFile'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'textChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'undo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'enableUndo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'redo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'enableRedo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'cut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'enableCut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'copy'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'enableCopy'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'paste'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'enablePaste'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'selectAll'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'deleteTab'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'save'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveAs'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rename'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'serialMonitor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sendProgram'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'programProcessFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<QProcess::ExitStatus, std::false_type>,
        // method 'programProcessReadyRead'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateSerialPorts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateBoards'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'enableProgramButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'enableMonitorButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void ProgramTab::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ProgramTab *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->wantToSave((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->wantToSaveAs((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->wantToRename((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->wantToDelete((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 4: _t->platformChanged((*reinterpret_cast< std::add_pointer_t<Platform*>>(_a[1]))); break;
        case 5: _t->programWindowUpdateRequest((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<Platform*>>(_a[7])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[8])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[9])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[10]))); break;
        case 6: _t->setPlatform((*reinterpret_cast< std::add_pointer_t<Platform*>>(_a[1]))); break;
        case 7: _t->setPlatform((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: _t->setPort((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 9: _t->setBoard((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 10: { bool _r = _t->loadProgramFile();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 11: _t->textChanged(); break;
        case 12: _t->undo(); break;
        case 13: _t->enableUndo((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 14: _t->redo(); break;
        case 15: _t->enableRedo((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 16: _t->cut(); break;
        case 17: _t->enableCut((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 18: _t->copy(); break;
        case 19: _t->enableCopy((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 20: _t->paste(); break;
        case 21: _t->enablePaste((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 22: _t->selectAll(); break;
        case 23: _t->deleteTab(); break;
        case 24: _t->save(); break;
        case 25: _t->saveAs(); break;
        case 26: _t->rename(); break;
        case 27: _t->serialMonitor(); break;
        case 28: _t->sendProgram(); break;
        case 29: _t->programProcessFinished((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QProcess::ExitStatus>>(_a[2]))); break;
        case 30: _t->programProcessReadyRead(); break;
        case 31: _t->updateMenu(); break;
        case 32: _t->updateSerialPorts(); break;
        case 33: _t->updateBoards(); break;
        case 34: _t->enableProgramButton(); break;
        case 35: _t->enableMonitorButton(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Platform* >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 6:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Platform* >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Platform* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ProgramTab::*)(int );
            if (_t _q_method = &ProgramTab::wantToSave; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ProgramTab::*)(int );
            if (_t _q_method = &ProgramTab::wantToSaveAs; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (ProgramTab::*)(int );
            if (_t _q_method = &ProgramTab::wantToRename; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (ProgramTab::*)(int , bool );
            if (_t _q_method = &ProgramTab::wantToDelete; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (ProgramTab::*)(Platform * );
            if (_t _q_method = &ProgramTab::platformChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (ProgramTab::*)(bool , bool , bool , bool , bool , bool , Platform * , const QString & , const QString & , const QString & );
            if (_t _q_method = &ProgramTab::programWindowUpdateRequest; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    }
}

const QMetaObject *ProgramTab::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ProgramTab::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSProgramTabENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int ProgramTab::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 36)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 36;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 36)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 36;
    }
    return _id;
}

// SIGNAL 0
void ProgramTab::wantToSave(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ProgramTab::wantToSaveAs(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void ProgramTab::wantToRename(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void ProgramTab::wantToDelete(int _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void ProgramTab::platformChanged(Platform * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void ProgramTab::programWindowUpdateRequest(bool _t1, bool _t2, bool _t3, bool _t4, bool _t5, bool _t6, Platform * _t7, const QString & _t8, const QString & _t9, const QString & _t10)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t8))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t9))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t10))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSDeleteDialogENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSDeleteDialogENDCLASS = QtMocHelpers::stringData(
    "DeleteDialog",
    "buttonClicked",
    "",
    "QAbstractButton*",
    "button"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSDeleteDialogENDCLASS_t {
    uint offsetsAndSizes[10];
    char stringdata0[13];
    char stringdata1[14];
    char stringdata2[1];
    char stringdata3[17];
    char stringdata4[7];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSDeleteDialogENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSDeleteDialogENDCLASS_t qt_meta_stringdata_CLASSDeleteDialogENDCLASS = {
    {
        QT_MOC_LITERAL(0, 12),  // "DeleteDialog"
        QT_MOC_LITERAL(13, 13),  // "buttonClicked"
        QT_MOC_LITERAL(27, 0),  // ""
        QT_MOC_LITERAL(28, 16),  // "QAbstractButton*"
        QT_MOC_LITERAL(45, 6)   // "button"
    },
    "DeleteDialog",
    "buttonClicked",
    "",
    "QAbstractButton*",
    "button"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSDeleteDialogENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   20,    2, 0x09,    1 /* Protected */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

       0        // eod
};

Q_CONSTINIT const QMetaObject DeleteDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSDeleteDialogENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSDeleteDialogENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSDeleteDialogENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<DeleteDialog, std::true_type>,
        // method 'buttonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QAbstractButton *, std::false_type>
    >,
    nullptr
} };

void DeleteDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DeleteDialog *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->buttonClicked((*reinterpret_cast< std::add_pointer_t<QAbstractButton*>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAbstractButton* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *DeleteDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DeleteDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSDeleteDialogENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int DeleteDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
QT_WARNING_POP
