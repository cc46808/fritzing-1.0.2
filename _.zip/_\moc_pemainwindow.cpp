/****************************************************************************
** Meta object code from reading C++ file 'pemainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/partseditor/pemainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'pemainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSIconSketchWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSIconSketchWidgetENDCLASS = QtMocHelpers::stringData(
    "IconSketchWidget"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSIconSketchWidgetENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[17];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSIconSketchWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSIconSketchWidgetENDCLASS_t qt_meta_stringdata_CLASSIconSketchWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 16)   // "IconSketchWidget"
    },
    "IconSketchWidget"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSIconSketchWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject IconSketchWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<SketchWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSIconSketchWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSIconSketchWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSIconSketchWidgetENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<IconSketchWidget, std::true_type>
    >,
    nullptr
} };

void IconSketchWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *IconSketchWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *IconSketchWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSIconSketchWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return SketchWidget::qt_metacast(_clname);
}

int IconSketchWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SketchWidget::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPEMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPEMainWindowENDCLASS = QtMocHelpers::stringData(
    "PEMainWindow",
    "addToMyPartsSignal",
    "",
    "ModelPart*",
    "metadataChanged",
    "name",
    "value",
    "propertiesChanged",
    "QHash<QString,QString>",
    "tagsChanged",
    "connectorMetadataChanged",
    "ConnectorMetadata*",
    "removedConnectors",
    "QList<ConnectorMetadata*>&",
    "highlightSlot",
    "PEGraphicsItem*",
    "pegiMousePressed",
    "bool&",
    "ignore",
    "pegiMouseReleased",
    "pegiTerminalPointMoved",
    "pegiTerminalPointChanged",
    "before",
    "after",
    "switchedConnector",
    "removedConnector",
    "QDomElement",
    "terminalPointChanged",
    "how",
    "coord",
    "getSpinAmount",
    "double&",
    "amount",
    "pickModeChanged",
    "busModeChanged",
    "connectorCountChanged",
    "deleteBusConnection",
    "newWireSlot",
    "Wire*",
    "wireChangedSlot",
    "oldLine",
    "newLine",
    "oldPos",
    "newPos",
    "ConnectorItem*",
    "from",
    "to",
    "connectorsTypeChanged",
    "Connector::ConnectorType",
    "smdChanged",
    "showing",
    "SketchWidget*",
    "updateExportMenu",
    "updateEditMenu",
    "s2sMessageSlot",
    "message",
    "initZoom",
    "showMetadataView",
    "showConnectorsView",
    "showIconView",
    "loadImage",
    "save",
    "saveAs",
    "showInOS",
    "tabWidget_currentChanged",
    "index",
    "backupSketch",
    "updateWindowMenu",
    "updateWireMenu",
    "closeLater",
    "resetNextPick",
    "reuseBreadboard",
    "reuseSchematic",
    "reusePCB",
    "convertToTenth",
    "hideOtherViews",
    "updateLayerMenu",
    "resetLayout",
    "updateAssignedConnectors",
    "itemAddedSlot",
    "ItemBase*",
    "ViewLayer::ViewLayerPlacement",
    "ViewGeometry",
    "id",
    "dropOrigin",
    "itemMovedSlot",
    "clickedItemCandidateSlot",
    "QGraphicsItem*",
    "ok",
    "resizedSlot"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPEMainWindowENDCLASS_t {
    uint offsetsAndSizes[180];
    char stringdata0[13];
    char stringdata1[19];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[16];
    char stringdata5[5];
    char stringdata6[6];
    char stringdata7[18];
    char stringdata8[23];
    char stringdata9[12];
    char stringdata10[25];
    char stringdata11[19];
    char stringdata12[18];
    char stringdata13[27];
    char stringdata14[14];
    char stringdata15[16];
    char stringdata16[17];
    char stringdata17[6];
    char stringdata18[7];
    char stringdata19[18];
    char stringdata20[23];
    char stringdata21[25];
    char stringdata22[7];
    char stringdata23[6];
    char stringdata24[18];
    char stringdata25[17];
    char stringdata26[12];
    char stringdata27[21];
    char stringdata28[4];
    char stringdata29[6];
    char stringdata30[14];
    char stringdata31[8];
    char stringdata32[7];
    char stringdata33[16];
    char stringdata34[15];
    char stringdata35[22];
    char stringdata36[20];
    char stringdata37[12];
    char stringdata38[6];
    char stringdata39[16];
    char stringdata40[8];
    char stringdata41[8];
    char stringdata42[7];
    char stringdata43[7];
    char stringdata44[15];
    char stringdata45[5];
    char stringdata46[3];
    char stringdata47[22];
    char stringdata48[25];
    char stringdata49[11];
    char stringdata50[8];
    char stringdata51[14];
    char stringdata52[17];
    char stringdata53[15];
    char stringdata54[15];
    char stringdata55[8];
    char stringdata56[9];
    char stringdata57[17];
    char stringdata58[19];
    char stringdata59[13];
    char stringdata60[10];
    char stringdata61[5];
    char stringdata62[7];
    char stringdata63[9];
    char stringdata64[25];
    char stringdata65[6];
    char stringdata66[13];
    char stringdata67[17];
    char stringdata68[15];
    char stringdata69[11];
    char stringdata70[14];
    char stringdata71[16];
    char stringdata72[15];
    char stringdata73[9];
    char stringdata74[15];
    char stringdata75[15];
    char stringdata76[16];
    char stringdata77[12];
    char stringdata78[25];
    char stringdata79[14];
    char stringdata80[10];
    char stringdata81[30];
    char stringdata82[13];
    char stringdata83[3];
    char stringdata84[11];
    char stringdata85[14];
    char stringdata86[25];
    char stringdata87[15];
    char stringdata88[3];
    char stringdata89[12];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPEMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPEMainWindowENDCLASS_t qt_meta_stringdata_CLASSPEMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 12),  // "PEMainWindow"
        QT_MOC_LITERAL(13, 18),  // "addToMyPartsSignal"
        QT_MOC_LITERAL(32, 0),  // ""
        QT_MOC_LITERAL(33, 10),  // "ModelPart*"
        QT_MOC_LITERAL(44, 15),  // "metadataChanged"
        QT_MOC_LITERAL(60, 4),  // "name"
        QT_MOC_LITERAL(65, 5),  // "value"
        QT_MOC_LITERAL(71, 17),  // "propertiesChanged"
        QT_MOC_LITERAL(89, 22),  // "QHash<QString,QString>"
        QT_MOC_LITERAL(112, 11),  // "tagsChanged"
        QT_MOC_LITERAL(124, 24),  // "connectorMetadataChanged"
        QT_MOC_LITERAL(149, 18),  // "ConnectorMetadata*"
        QT_MOC_LITERAL(168, 17),  // "removedConnectors"
        QT_MOC_LITERAL(186, 26),  // "QList<ConnectorMetadata*>&"
        QT_MOC_LITERAL(213, 13),  // "highlightSlot"
        QT_MOC_LITERAL(227, 15),  // "PEGraphicsItem*"
        QT_MOC_LITERAL(243, 16),  // "pegiMousePressed"
        QT_MOC_LITERAL(260, 5),  // "bool&"
        QT_MOC_LITERAL(266, 6),  // "ignore"
        QT_MOC_LITERAL(273, 17),  // "pegiMouseReleased"
        QT_MOC_LITERAL(291, 22),  // "pegiTerminalPointMoved"
        QT_MOC_LITERAL(314, 24),  // "pegiTerminalPointChanged"
        QT_MOC_LITERAL(339, 6),  // "before"
        QT_MOC_LITERAL(346, 5),  // "after"
        QT_MOC_LITERAL(352, 17),  // "switchedConnector"
        QT_MOC_LITERAL(370, 16),  // "removedConnector"
        QT_MOC_LITERAL(387, 11),  // "QDomElement"
        QT_MOC_LITERAL(399, 20),  // "terminalPointChanged"
        QT_MOC_LITERAL(420, 3),  // "how"
        QT_MOC_LITERAL(424, 5),  // "coord"
        QT_MOC_LITERAL(430, 13),  // "getSpinAmount"
        QT_MOC_LITERAL(444, 7),  // "double&"
        QT_MOC_LITERAL(452, 6),  // "amount"
        QT_MOC_LITERAL(459, 15),  // "pickModeChanged"
        QT_MOC_LITERAL(475, 14),  // "busModeChanged"
        QT_MOC_LITERAL(490, 21),  // "connectorCountChanged"
        QT_MOC_LITERAL(512, 19),  // "deleteBusConnection"
        QT_MOC_LITERAL(532, 11),  // "newWireSlot"
        QT_MOC_LITERAL(544, 5),  // "Wire*"
        QT_MOC_LITERAL(550, 15),  // "wireChangedSlot"
        QT_MOC_LITERAL(566, 7),  // "oldLine"
        QT_MOC_LITERAL(574, 7),  // "newLine"
        QT_MOC_LITERAL(582, 6),  // "oldPos"
        QT_MOC_LITERAL(589, 6),  // "newPos"
        QT_MOC_LITERAL(596, 14),  // "ConnectorItem*"
        QT_MOC_LITERAL(611, 4),  // "from"
        QT_MOC_LITERAL(616, 2),  // "to"
        QT_MOC_LITERAL(619, 21),  // "connectorsTypeChanged"
        QT_MOC_LITERAL(641, 24),  // "Connector::ConnectorType"
        QT_MOC_LITERAL(666, 10),  // "smdChanged"
        QT_MOC_LITERAL(677, 7),  // "showing"
        QT_MOC_LITERAL(685, 13),  // "SketchWidget*"
        QT_MOC_LITERAL(699, 16),  // "updateExportMenu"
        QT_MOC_LITERAL(716, 14),  // "updateEditMenu"
        QT_MOC_LITERAL(731, 14),  // "s2sMessageSlot"
        QT_MOC_LITERAL(746, 7),  // "message"
        QT_MOC_LITERAL(754, 8),  // "initZoom"
        QT_MOC_LITERAL(763, 16),  // "showMetadataView"
        QT_MOC_LITERAL(780, 18),  // "showConnectorsView"
        QT_MOC_LITERAL(799, 12),  // "showIconView"
        QT_MOC_LITERAL(812, 9),  // "loadImage"
        QT_MOC_LITERAL(822, 4),  // "save"
        QT_MOC_LITERAL(827, 6),  // "saveAs"
        QT_MOC_LITERAL(834, 8),  // "showInOS"
        QT_MOC_LITERAL(843, 24),  // "tabWidget_currentChanged"
        QT_MOC_LITERAL(868, 5),  // "index"
        QT_MOC_LITERAL(874, 12),  // "backupSketch"
        QT_MOC_LITERAL(887, 16),  // "updateWindowMenu"
        QT_MOC_LITERAL(904, 14),  // "updateWireMenu"
        QT_MOC_LITERAL(919, 10),  // "closeLater"
        QT_MOC_LITERAL(930, 13),  // "resetNextPick"
        QT_MOC_LITERAL(944, 15),  // "reuseBreadboard"
        QT_MOC_LITERAL(960, 14),  // "reuseSchematic"
        QT_MOC_LITERAL(975, 8),  // "reusePCB"
        QT_MOC_LITERAL(984, 14),  // "convertToTenth"
        QT_MOC_LITERAL(999, 14),  // "hideOtherViews"
        QT_MOC_LITERAL(1014, 15),  // "updateLayerMenu"
        QT_MOC_LITERAL(1030, 11),  // "resetLayout"
        QT_MOC_LITERAL(1042, 24),  // "updateAssignedConnectors"
        QT_MOC_LITERAL(1067, 13),  // "itemAddedSlot"
        QT_MOC_LITERAL(1081, 9),  // "ItemBase*"
        QT_MOC_LITERAL(1091, 29),  // "ViewLayer::ViewLayerPlacement"
        QT_MOC_LITERAL(1121, 12),  // "ViewGeometry"
        QT_MOC_LITERAL(1134, 2),  // "id"
        QT_MOC_LITERAL(1137, 10),  // "dropOrigin"
        QT_MOC_LITERAL(1148, 13),  // "itemMovedSlot"
        QT_MOC_LITERAL(1162, 24),  // "clickedItemCandidateSlot"
        QT_MOC_LITERAL(1187, 14),  // "QGraphicsItem*"
        QT_MOC_LITERAL(1202, 2),  // "ok"
        QT_MOC_LITERAL(1205, 11)   // "resizedSlot"
    },
    "PEMainWindow",
    "addToMyPartsSignal",
    "",
    "ModelPart*",
    "metadataChanged",
    "name",
    "value",
    "propertiesChanged",
    "QHash<QString,QString>",
    "tagsChanged",
    "connectorMetadataChanged",
    "ConnectorMetadata*",
    "removedConnectors",
    "QList<ConnectorMetadata*>&",
    "highlightSlot",
    "PEGraphicsItem*",
    "pegiMousePressed",
    "bool&",
    "ignore",
    "pegiMouseReleased",
    "pegiTerminalPointMoved",
    "pegiTerminalPointChanged",
    "before",
    "after",
    "switchedConnector",
    "removedConnector",
    "QDomElement",
    "terminalPointChanged",
    "how",
    "coord",
    "getSpinAmount",
    "double&",
    "amount",
    "pickModeChanged",
    "busModeChanged",
    "connectorCountChanged",
    "deleteBusConnection",
    "newWireSlot",
    "Wire*",
    "wireChangedSlot",
    "oldLine",
    "newLine",
    "oldPos",
    "newPos",
    "ConnectorItem*",
    "from",
    "to",
    "connectorsTypeChanged",
    "Connector::ConnectorType",
    "smdChanged",
    "showing",
    "SketchWidget*",
    "updateExportMenu",
    "updateEditMenu",
    "s2sMessageSlot",
    "message",
    "initZoom",
    "showMetadataView",
    "showConnectorsView",
    "showIconView",
    "loadImage",
    "save",
    "saveAs",
    "showInOS",
    "tabWidget_currentChanged",
    "index",
    "backupSketch",
    "updateWindowMenu",
    "updateWireMenu",
    "closeLater",
    "resetNextPick",
    "reuseBreadboard",
    "reuseSchematic",
    "reusePCB",
    "convertToTenth",
    "hideOtherViews",
    "updateLayerMenu",
    "resetLayout",
    "updateAssignedConnectors",
    "itemAddedSlot",
    "ItemBase*",
    "ViewLayer::ViewLayerPlacement",
    "ViewGeometry",
    "id",
    "dropOrigin",
    "itemMovedSlot",
    "clickedItemCandidateSlot",
    "QGraphicsItem*",
    "ok",
    "resizedSlot"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPEMainWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      54,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,  338,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    2,  343,    2, 0x0a,    4 /* Public */,
       7,    1,  348,    2, 0x0a,    7 /* Public */,
       9,    1,  351,    2, 0x0a,    9 /* Public */,
      10,    1,  354,    2, 0x0a,   11 /* Public */,
      12,    1,  357,    2, 0x0a,   13 /* Public */,
      14,    1,  360,    2, 0x0a,   15 /* Public */,
      16,    2,  363,    2, 0x0a,   17 /* Public */,
      19,    1,  368,    2, 0x0a,   20 /* Public */,
      20,    2,  371,    2, 0x0a,   22 /* Public */,
      21,    3,  376,    2, 0x0a,   25 /* Public */,
      24,    1,  383,    2, 0x0a,   29 /* Public */,
      25,    1,  386,    2, 0x0a,   31 /* Public */,
      27,    1,  389,    2, 0x0a,   33 /* Public */,
      27,    2,  392,    2, 0x0a,   35 /* Public */,
      30,    1,  397,    2, 0x0a,   38 /* Public */,
      33,    1,  400,    2, 0x0a,   40 /* Public */,
      34,    1,  403,    2, 0x0a,   42 /* Public */,
      35,    1,  406,    2, 0x0a,   44 /* Public */,
      36,    0,  409,    2, 0x0a,   46 /* Public */,
      37,    1,  410,    2, 0x0a,   47 /* Public */,
      39,    7,  413,    2, 0x0a,   49 /* Public */,
      47,    1,  428,    2, 0x0a,   57 /* Public */,
      49,    1,  431,    2, 0x0a,   59 /* Public */,
      50,    1,  434,    2, 0x0a,   61 /* Public */,
      52,    0,  437,    2, 0x0a,   63 /* Public */,
      53,    0,  438,    2, 0x0a,   64 /* Public */,
      54,    1,  439,    2, 0x0a,   65 /* Public */,
      56,    0,  442,    2, 0x09,   67 /* Protected */,
      57,    0,  443,    2, 0x09,   68 /* Protected */,
      58,    0,  444,    2, 0x09,   69 /* Protected */,
      59,    0,  445,    2, 0x09,   70 /* Protected */,
      60,    0,  446,    2, 0x09,   71 /* Protected */,
      61,    0,  447,    2, 0x09,   72 /* Protected */,
      62,    0,  448,    2, 0x09,   73 /* Protected */,
      63,    0,  449,    2, 0x09,   74 /* Protected */,
      64,    1,  450,    2, 0x09,   75 /* Protected */,
      66,    0,  453,    2, 0x09,   77 /* Protected */,
      67,    0,  454,    2, 0x09,   78 /* Protected */,
      68,    0,  455,    2, 0x09,   79 /* Protected */,
      69,    0,  456,    2, 0x09,   80 /* Protected */,
      70,    0,  457,    2, 0x09,   81 /* Protected */,
      71,    0,  458,    2, 0x09,   82 /* Protected */,
      72,    0,  459,    2, 0x09,   83 /* Protected */,
      73,    0,  460,    2, 0x09,   84 /* Protected */,
      74,    0,  461,    2, 0x09,   85 /* Protected */,
      75,    0,  462,    2, 0x09,   86 /* Protected */,
      76,    1,  463,    2, 0x09,   87 /* Protected */,
      76,    0,  466,    2, 0x29,   89 /* Protected | MethodCloned */,
      78,    0,  467,    2, 0x09,   90 /* Protected */,
      79,    6,  468,    2, 0x09,   91 /* Protected */,
      85,    1,  481,    2, 0x09,   98 /* Protected */,
      86,    2,  484,    2, 0x09,  100 /* Protected */,
      89,    1,  489,    2, 0x09,  103 /* Protected */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::QStringList,    2,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    5,    6,
    QMetaType::Void, 0x80000000 | 8,    2,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, 0x80000000 | 11,    2,
    QMetaType::Void, 0x80000000 | 13,    2,
    QMetaType::Void, 0x80000000 | 15,    2,
    QMetaType::Void, 0x80000000 | 15, 0x80000000 | 17,    2,   18,
    QMetaType::Void, 0x80000000 | 15,    2,
    QMetaType::Void, 0x80000000 | 15, QMetaType::QPointF,    2,    2,
    QMetaType::Void, 0x80000000 | 15, QMetaType::QPointF, QMetaType::QPointF,    2,   22,   23,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, 0x80000000 | 26,    2,
    QMetaType::Void, QMetaType::QString,   28,
    QMetaType::Void, QMetaType::QString, QMetaType::Double,   29,    6,
    QMetaType::Void, 0x80000000 | 31,   32,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 38,    2,
    QMetaType::Void, 0x80000000 | 38, QMetaType::QLineF, QMetaType::QLineF, QMetaType::QPointF, QMetaType::QPointF, 0x80000000 | 44, 0x80000000 | 44,    2,   40,   41,   42,   43,   45,   46,
    QMetaType::Void, 0x80000000 | 48,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, 0x80000000 | 51,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   55,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   65,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   77,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 80, 0x80000000 | 81, 0x80000000 | 82, QMetaType::Long, 0x80000000 | 51,    2,    2,    2,    2,   83,   84,
    QMetaType::Void, 0x80000000 | 80,    2,
    QMetaType::Void, 0x80000000 | 87, 0x80000000 | 17,    2,   88,
    QMetaType::Void, 0x80000000 | 80,    2,

       0        // eod
};

Q_CONSTINIT const QMetaObject PEMainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<MainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSPEMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPEMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPEMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PEMainWindow, std::true_type>,
        // method 'addToMyPartsSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QStringList &, std::false_type>,
        // method 'metadataChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'propertiesChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QHash<QString,QString> &, std::false_type>,
        // method 'tagsChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QStringList &, std::false_type>,
        // method 'connectorMetadataChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorMetadata *, std::false_type>,
        // method 'removedConnectors'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<ConnectorMetadata*> &, std::false_type>,
        // method 'highlightSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PEGraphicsItem *, std::false_type>,
        // method 'pegiMousePressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PEGraphicsItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool &, std::false_type>,
        // method 'pegiMouseReleased'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PEGraphicsItem *, std::false_type>,
        // method 'pegiTerminalPointMoved'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PEGraphicsItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        // method 'pegiTerminalPointChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PEGraphicsItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        // method 'switchedConnector'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'removedConnector'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QDomElement &, std::false_type>,
        // method 'terminalPointChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'terminalPointChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'getSpinAmount'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double &, std::false_type>,
        // method 'pickModeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'busModeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'connectorCountChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'deleteBusConnection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'newWireSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        // method 'wireChangedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QLineF &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QLineF &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        // method 'connectorsTypeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Connector::ConnectorType, std::false_type>,
        // method 'smdChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'showing'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        // method 'updateExportMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateEditMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 's2sMessageSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'initZoom'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showMetadataView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showConnectorsView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showIconView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loadImage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'save'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'saveAs'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'showInOS'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tabWidget_currentChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'backupSketch'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateWindowMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateWireMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'closeLater'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'resetNextPick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'reuseBreadboard'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'reuseSchematic'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'reusePCB'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'convertToTenth'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'hideOtherViews'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateLayerMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'updateLayerMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateAssignedConnectors'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'itemAddedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement, std::false_type>,
        QtPrivate::TypeAndForceComplete<const ViewGeometry &, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        // method 'itemMovedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        // method 'clickedItemCandidateSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool &, std::false_type>,
        // method 'resizedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>
    >,
    nullptr
} };

void PEMainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PEMainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->addToMyPartsSignal((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[2]))); break;
        case 1: _t->metadataChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 2: _t->propertiesChanged((*reinterpret_cast< std::add_pointer_t<QHash<QString,QString>>>(_a[1]))); break;
        case 3: _t->tagsChanged((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 4: _t->connectorMetadataChanged((*reinterpret_cast< std::add_pointer_t<ConnectorMetadata*>>(_a[1]))); break;
        case 5: _t->removedConnectors((*reinterpret_cast< std::add_pointer_t<QList<ConnectorMetadata*>&>>(_a[1]))); break;
        case 6: _t->highlightSlot((*reinterpret_cast< std::add_pointer_t<PEGraphicsItem*>>(_a[1]))); break;
        case 7: _t->pegiMousePressed((*reinterpret_cast< std::add_pointer_t<PEGraphicsItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool&>>(_a[2]))); break;
        case 8: _t->pegiMouseReleased((*reinterpret_cast< std::add_pointer_t<PEGraphicsItem*>>(_a[1]))); break;
        case 9: _t->pegiTerminalPointMoved((*reinterpret_cast< std::add_pointer_t<PEGraphicsItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[2]))); break;
        case 10: _t->pegiTerminalPointChanged((*reinterpret_cast< std::add_pointer_t<PEGraphicsItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[3]))); break;
        case 11: _t->switchedConnector((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 12: _t->removedConnector((*reinterpret_cast< std::add_pointer_t<QDomElement>>(_a[1]))); break;
        case 13: _t->terminalPointChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 14: _t->terminalPointChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2]))); break;
        case 15: _t->getSpinAmount((*reinterpret_cast< std::add_pointer_t<double&>>(_a[1]))); break;
        case 16: _t->pickModeChanged((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 17: _t->busModeChanged((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 18: _t->connectorCountChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 19: _t->deleteBusConnection(); break;
        case 20: _t->newWireSlot((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1]))); break;
        case 21: _t->wireChangedSlot((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QLineF>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QLineF>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[7]))); break;
        case 22: _t->connectorsTypeChanged((*reinterpret_cast< std::add_pointer_t<Connector::ConnectorType>>(_a[1]))); break;
        case 23: _t->smdChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 24: _t->showing((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1]))); break;
        case 25: _t->updateExportMenu(); break;
        case 26: _t->updateEditMenu(); break;
        case 27: _t->s2sMessageSlot((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 28: _t->initZoom(); break;
        case 29: _t->showMetadataView(); break;
        case 30: _t->showConnectorsView(); break;
        case 31: _t->showIconView(); break;
        case 32: _t->loadImage(); break;
        case 33: { bool _r = _t->save();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 34: { bool _r = _t->saveAs();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 35: _t->showInOS(); break;
        case 36: _t->tabWidget_currentChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 37: _t->backupSketch(); break;
        case 38: _t->updateWindowMenu(); break;
        case 39: _t->updateWireMenu(); break;
        case 40: _t->closeLater(); break;
        case 41: _t->resetNextPick(); break;
        case 42: _t->reuseBreadboard(); break;
        case 43: _t->reuseSchematic(); break;
        case 44: _t->reusePCB(); break;
        case 45: _t->convertToTenth(); break;
        case 46: _t->hideOtherViews(); break;
        case 47: _t->updateLayerMenu((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 48: _t->updateLayerMenu(); break;
        case 49: _t->updateAssignedConnectors(); break;
        case 50: _t->itemAddedSlot((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<ViewGeometry>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<long>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[6]))); break;
        case 51: _t->itemMovedSlot((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1]))); break;
        case 52: _t->clickedItemCandidateSlot((*reinterpret_cast< std::add_pointer_t<QGraphicsItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool&>>(_a[2]))); break;
        case 53: _t->resizedSlot((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            }
            break;
        case 20:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Wire* >(); break;
            }
            break;
        case 21:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 6:
            case 5:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ConnectorItem* >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Wire* >(); break;
            }
            break;
        case 24:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 50:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            case 5:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 51:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 52:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QGraphicsItem* >(); break;
            }
            break;
        case 53:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PEMainWindow::*)(ModelPart * , const QStringList & );
            if (_t _q_method = &PEMainWindow::addToMyPartsSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *PEMainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PEMainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPEMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return MainWindow::qt_metacast(_clname);
}

int PEMainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = MainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 54)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 54;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 54)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 54;
    }
    return _id;
}

// SIGNAL 0
void PEMainWindow::addToMyPartsSignal(ModelPart * _t1, const QStringList & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
