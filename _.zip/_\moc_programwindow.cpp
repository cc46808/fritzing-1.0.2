/****************************************************************************
** Meta object code from reading C++ file 'programwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/program/programwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'programwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPTabWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPTabWidgetENDCLASS = QtMocHelpers::stringData(
    "PTabWidget",
    "tabChanged",
    "",
    "index"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPTabWidgetENDCLASS_t {
    uint offsetsAndSizes[8];
    char stringdata0[11];
    char stringdata1[11];
    char stringdata2[1];
    char stringdata3[6];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPTabWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPTabWidgetENDCLASS_t qt_meta_stringdata_CLASSPTabWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "PTabWidget"
        QT_MOC_LITERAL(11, 10),  // "tabChanged"
        QT_MOC_LITERAL(22, 0),  // ""
        QT_MOC_LITERAL(23, 5)   // "index"
    },
    "PTabWidget",
    "tabChanged",
    "",
    "index"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPTabWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   20,    2, 0x09,    1 /* Protected */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,

       0        // eod
};

Q_CONSTINIT const QMetaObject PTabWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QTabWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSPTabWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPTabWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPTabWidgetENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PTabWidget, std::true_type>,
        // method 'tabChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>
    >,
    nullptr
} };

void PTabWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PTabWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->tabChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject *PTabWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PTabWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPTabWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QTabWidget::qt_metacast(_clname);
}

int PTabWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTabWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 1;
    }
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSProgramWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSProgramWindowENDCLASS = QtMocHelpers::stringData(
    "ProgramWindow",
    "closed",
    "",
    "changeActivationSignal",
    "activate",
    "QWidget*",
    "originator",
    "linkToProgramFile",
    "filename",
    "Platform*",
    "platform",
    "addlink",
    "strong",
    "saveAll",
    "loadProgramFile",
    "addTab",
    "ProgramTab*",
    "closeCurrentTab",
    "closeTab",
    "index",
    "saveCurrentTab",
    "tabSave",
    "tabSaveAs",
    "tabRename",
    "duplicateTab",
    "tabBeforeClosing",
    "bool&",
    "ok",
    "tabDelete",
    "deleteFile",
    "updateMenu",
    "programEnable",
    "undoEnable",
    "redoEnable",
    "cutEnable",
    "copyEnable",
    "pasteEnable",
    "port",
    "board",
    "updateSerialPorts",
    "portProcessFinished",
    "exitCode",
    "QProcess::ExitStatus",
    "exitStatus",
    "portProcessReadyRead",
    "updateBoards",
    "setPlatform",
    "QAction*",
    "setPort",
    "setBoard",
    "rename",
    "undo",
    "redo",
    "cut",
    "copy",
    "paste",
    "selectAll",
    "serialMonitor",
    "sendProgram"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSProgramWindowENDCLASS_t {
    uint offsetsAndSizes[118];
    char stringdata0[14];
    char stringdata1[7];
    char stringdata2[1];
    char stringdata3[23];
    char stringdata4[9];
    char stringdata5[9];
    char stringdata6[11];
    char stringdata7[18];
    char stringdata8[9];
    char stringdata9[10];
    char stringdata10[9];
    char stringdata11[8];
    char stringdata12[7];
    char stringdata13[8];
    char stringdata14[16];
    char stringdata15[7];
    char stringdata16[12];
    char stringdata17[16];
    char stringdata18[9];
    char stringdata19[6];
    char stringdata20[15];
    char stringdata21[8];
    char stringdata22[10];
    char stringdata23[10];
    char stringdata24[13];
    char stringdata25[17];
    char stringdata26[6];
    char stringdata27[3];
    char stringdata28[10];
    char stringdata29[11];
    char stringdata30[11];
    char stringdata31[14];
    char stringdata32[11];
    char stringdata33[11];
    char stringdata34[10];
    char stringdata35[11];
    char stringdata36[12];
    char stringdata37[5];
    char stringdata38[6];
    char stringdata39[18];
    char stringdata40[20];
    char stringdata41[9];
    char stringdata42[21];
    char stringdata43[11];
    char stringdata44[21];
    char stringdata45[13];
    char stringdata46[12];
    char stringdata47[9];
    char stringdata48[8];
    char stringdata49[9];
    char stringdata50[7];
    char stringdata51[5];
    char stringdata52[5];
    char stringdata53[4];
    char stringdata54[5];
    char stringdata55[6];
    char stringdata56[10];
    char stringdata57[14];
    char stringdata58[12];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSProgramWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSProgramWindowENDCLASS_t qt_meta_stringdata_CLASSProgramWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 13),  // "ProgramWindow"
        QT_MOC_LITERAL(14, 6),  // "closed"
        QT_MOC_LITERAL(21, 0),  // ""
        QT_MOC_LITERAL(22, 22),  // "changeActivationSignal"
        QT_MOC_LITERAL(45, 8),  // "activate"
        QT_MOC_LITERAL(54, 8),  // "QWidget*"
        QT_MOC_LITERAL(63, 10),  // "originator"
        QT_MOC_LITERAL(74, 17),  // "linkToProgramFile"
        QT_MOC_LITERAL(92, 8),  // "filename"
        QT_MOC_LITERAL(101, 9),  // "Platform*"
        QT_MOC_LITERAL(111, 8),  // "platform"
        QT_MOC_LITERAL(120, 7),  // "addlink"
        QT_MOC_LITERAL(128, 6),  // "strong"
        QT_MOC_LITERAL(135, 7),  // "saveAll"
        QT_MOC_LITERAL(143, 15),  // "loadProgramFile"
        QT_MOC_LITERAL(159, 6),  // "addTab"
        QT_MOC_LITERAL(166, 11),  // "ProgramTab*"
        QT_MOC_LITERAL(178, 15),  // "closeCurrentTab"
        QT_MOC_LITERAL(194, 8),  // "closeTab"
        QT_MOC_LITERAL(203, 5),  // "index"
        QT_MOC_LITERAL(209, 14),  // "saveCurrentTab"
        QT_MOC_LITERAL(224, 7),  // "tabSave"
        QT_MOC_LITERAL(232, 9),  // "tabSaveAs"
        QT_MOC_LITERAL(242, 9),  // "tabRename"
        QT_MOC_LITERAL(252, 12),  // "duplicateTab"
        QT_MOC_LITERAL(265, 16),  // "tabBeforeClosing"
        QT_MOC_LITERAL(282, 5),  // "bool&"
        QT_MOC_LITERAL(288, 2),  // "ok"
        QT_MOC_LITERAL(291, 9),  // "tabDelete"
        QT_MOC_LITERAL(301, 10),  // "deleteFile"
        QT_MOC_LITERAL(312, 10),  // "updateMenu"
        QT_MOC_LITERAL(323, 13),  // "programEnable"
        QT_MOC_LITERAL(337, 10),  // "undoEnable"
        QT_MOC_LITERAL(348, 10),  // "redoEnable"
        QT_MOC_LITERAL(359, 9),  // "cutEnable"
        QT_MOC_LITERAL(369, 10),  // "copyEnable"
        QT_MOC_LITERAL(380, 11),  // "pasteEnable"
        QT_MOC_LITERAL(392, 4),  // "port"
        QT_MOC_LITERAL(397, 5),  // "board"
        QT_MOC_LITERAL(403, 17),  // "updateSerialPorts"
        QT_MOC_LITERAL(421, 19),  // "portProcessFinished"
        QT_MOC_LITERAL(441, 8),  // "exitCode"
        QT_MOC_LITERAL(450, 20),  // "QProcess::ExitStatus"
        QT_MOC_LITERAL(471, 10),  // "exitStatus"
        QT_MOC_LITERAL(482, 20),  // "portProcessReadyRead"
        QT_MOC_LITERAL(503, 12),  // "updateBoards"
        QT_MOC_LITERAL(516, 11),  // "setPlatform"
        QT_MOC_LITERAL(528, 8),  // "QAction*"
        QT_MOC_LITERAL(537, 7),  // "setPort"
        QT_MOC_LITERAL(545, 8),  // "setBoard"
        QT_MOC_LITERAL(554, 6),  // "rename"
        QT_MOC_LITERAL(561, 4),  // "undo"
        QT_MOC_LITERAL(566, 4),  // "redo"
        QT_MOC_LITERAL(571, 3),  // "cut"
        QT_MOC_LITERAL(575, 4),  // "copy"
        QT_MOC_LITERAL(580, 5),  // "paste"
        QT_MOC_LITERAL(586, 9),  // "selectAll"
        QT_MOC_LITERAL(596, 13),  // "serialMonitor"
        QT_MOC_LITERAL(610, 11)   // "sendProgram"
    },
    "ProgramWindow",
    "closed",
    "",
    "changeActivationSignal",
    "activate",
    "QWidget*",
    "originator",
    "linkToProgramFile",
    "filename",
    "Platform*",
    "platform",
    "addlink",
    "strong",
    "saveAll",
    "loadProgramFile",
    "addTab",
    "ProgramTab*",
    "closeCurrentTab",
    "closeTab",
    "index",
    "saveCurrentTab",
    "tabSave",
    "tabSaveAs",
    "tabRename",
    "duplicateTab",
    "tabBeforeClosing",
    "bool&",
    "ok",
    "tabDelete",
    "deleteFile",
    "updateMenu",
    "programEnable",
    "undoEnable",
    "redoEnable",
    "cutEnable",
    "copyEnable",
    "pasteEnable",
    "port",
    "board",
    "updateSerialPorts",
    "portProcessFinished",
    "exitCode",
    "QProcess::ExitStatus",
    "exitStatus",
    "portProcessReadyRead",
    "updateBoards",
    "setPlatform",
    "QAction*",
    "setPort",
    "setBoard",
    "rename",
    "undo",
    "redo",
    "cut",
    "copy",
    "paste",
    "selectAll",
    "serialMonitor",
    "sendProgram"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSProgramWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      32,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  206,    2, 0x06,    1 /* Public */,
       3,    2,  207,    2, 0x06,    2 /* Public */,
       7,    4,  212,    2, 0x06,    5 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      13,    0,  221,    2, 0x0a,   10 /* Public */,
      14,    0,  222,    2, 0x09,   11 /* Protected */,
      15,    0,  223,    2, 0x09,   12 /* Protected */,
      17,    0,  224,    2, 0x09,   13 /* Protected */,
      18,    1,  225,    2, 0x09,   14 /* Protected */,
      20,    0,  228,    2, 0x09,   16 /* Protected */,
      21,    1,  229,    2, 0x09,   17 /* Protected */,
      22,    1,  232,    2, 0x09,   19 /* Protected */,
      23,    1,  235,    2, 0x09,   21 /* Protected */,
      24,    0,  238,    2, 0x09,   23 /* Protected */,
      25,    2,  239,    2, 0x09,   24 /* Protected */,
      28,    2,  244,    2, 0x09,   27 /* Protected */,
      30,   10,  249,    2, 0x09,   30 /* Protected */,
      39,    0,  270,    2, 0x09,   41 /* Protected */,
      40,    2,  271,    2, 0x09,   42 /* Protected */,
      44,    0,  276,    2, 0x09,   45 /* Protected */,
      45,    0,  277,    2, 0x09,   46 /* Protected */,
      46,    1,  278,    2, 0x09,   47 /* Protected */,
      48,    1,  281,    2, 0x09,   49 /* Protected */,
      49,    1,  284,    2, 0x09,   51 /* Protected */,
      50,    0,  287,    2, 0x09,   53 /* Protected */,
      51,    0,  288,    2, 0x09,   54 /* Protected */,
      52,    0,  289,    2, 0x09,   55 /* Protected */,
      53,    0,  290,    2, 0x09,   56 /* Protected */,
      54,    0,  291,    2, 0x09,   57 /* Protected */,
      55,    0,  292,    2, 0x09,   58 /* Protected */,
      56,    0,  293,    2, 0x09,   59 /* Protected */,
      57,    0,  294,    2, 0x09,   60 /* Protected */,
      58,    0,  295,    2, 0x09,   61 /* Protected */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 5,    4,    6,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 9, QMetaType::Bool, QMetaType::Bool,    8,   10,   11,   12,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 16,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 26,    2,   27,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,   19,   29,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, 0x80000000 | 9, QMetaType::QString, QMetaType::QString, QMetaType::QString,   31,   32,   33,   34,   35,   36,   10,   37,   38,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 42,   41,   43,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 47,    2,
    QMetaType::Void, 0x80000000 | 47,    2,
    QMetaType::Void, 0x80000000 | 47,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject ProgramWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<FritzingWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSProgramWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSProgramWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSProgramWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ProgramWindow, std::true_type>,
        // method 'closed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'changeActivationSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QWidget *, std::false_type>,
        // method 'linkToProgramFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<Platform *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'saveAll'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loadProgramFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'addTab'
        QtPrivate::TypeAndForceComplete<ProgramTab *, std::false_type>,
        // method 'closeCurrentTab'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'closeTab'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'saveCurrentTab'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tabSave'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'tabSaveAs'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'tabRename'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'duplicateTab'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tabBeforeClosing'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool &, std::false_type>,
        // method 'tabDelete'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'updateMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<Platform *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'updateSerialPorts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'portProcessFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<QProcess::ExitStatus, std::false_type>,
        // method 'portProcessReadyRead'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateBoards'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setPlatform'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QAction *, std::false_type>,
        // method 'setPort'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QAction *, std::false_type>,
        // method 'setBoard'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QAction *, std::false_type>,
        // method 'rename'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'undo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'redo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copy'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'paste'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectAll'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'serialMonitor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sendProgram'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void ProgramWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ProgramWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->closed(); break;
        case 1: _t->changeActivationSignal((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QWidget*>>(_a[2]))); break;
        case 2: _t->linkToProgramFile((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Platform*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 3: _t->saveAll(); break;
        case 4: _t->loadProgramFile(); break;
        case 5: { ProgramTab* _r = _t->addTab();
            if (_a[0]) *reinterpret_cast< ProgramTab**>(_a[0]) = std::move(_r); }  break;
        case 6: _t->closeCurrentTab(); break;
        case 7: _t->closeTab((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: _t->saveCurrentTab(); break;
        case 9: _t->tabSave((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 10: _t->tabSaveAs((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 11: _t->tabRename((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 12: _t->duplicateTab(); break;
        case 13: _t->tabBeforeClosing((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool&>>(_a[2]))); break;
        case 14: _t->tabDelete((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 15: _t->updateMenu((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<Platform*>>(_a[7])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[8])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[9])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[10]))); break;
        case 16: _t->updateSerialPorts(); break;
        case 17: _t->portProcessFinished((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QProcess::ExitStatus>>(_a[2]))); break;
        case 18: _t->portProcessReadyRead(); break;
        case 19: _t->updateBoards(); break;
        case 20: _t->setPlatform((*reinterpret_cast< std::add_pointer_t<QAction*>>(_a[1]))); break;
        case 21: _t->setPort((*reinterpret_cast< std::add_pointer_t<QAction*>>(_a[1]))); break;
        case 22: _t->setBoard((*reinterpret_cast< std::add_pointer_t<QAction*>>(_a[1]))); break;
        case 23: _t->rename(); break;
        case 24: _t->undo(); break;
        case 25: _t->redo(); break;
        case 26: _t->cut(); break;
        case 27: _t->copy(); break;
        case 28: _t->paste(); break;
        case 29: _t->selectAll(); break;
        case 30: _t->serialMonitor(); break;
        case 31: _t->sendProgram(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QWidget* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Platform* >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 6:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Platform* >(); break;
            }
            break;
        case 20:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAction* >(); break;
            }
            break;
        case 21:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAction* >(); break;
            }
            break;
        case 22:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QAction* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ProgramWindow::*)();
            if (_t _q_method = &ProgramWindow::closed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ProgramWindow::*)(bool , QWidget * );
            if (_t _q_method = &ProgramWindow::changeActivationSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (ProgramWindow::*)(const QString & , Platform * , bool , bool );
            if (_t _q_method = &ProgramWindow::linkToProgramFile; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject *ProgramWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ProgramWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSProgramWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return FritzingWindow::qt_metacast(_clname);
}

int ProgramWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = FritzingWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 32)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 32;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 32)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 32;
    }
    return _id;
}

// SIGNAL 0
void ProgramWindow::closed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void ProgramWindow::changeActivationSignal(bool _t1, QWidget * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void ProgramWindow::linkToProgramFile(const QString & _t1, Platform * _t2, bool _t3, bool _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
