/****************************************************************************
** Meta object code from reading C++ file 'pcbsketchwidget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/sketch/pcbsketchwidget.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'pcbsketchwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPCBSketchWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPCBSketchWidgetENDCLASS = QtMocHelpers::stringData(
    "PCBSketchWidget",
    "subSwapSignal",
    "",
    "SketchWidget*",
    "ItemBase*",
    "newModuleID",
    "ViewLayer::ViewLayerPlacement",
    "long&",
    "newID",
    "QUndoCommand*",
    "parentCommand",
    "boardDeletedSignal",
    "groundFillSignal",
    "copperFillSignal",
    "groundFillOldSignal",
    "copperFillOldSignal",
    "fabQuoteFinishedSignal",
    "resizeBoard",
    "w",
    "h",
    "doEmit",
    "showLabelFirstTimeForCommand",
    "itemID",
    "show",
    "changeBoardLayers",
    "layers",
    "id",
    "alignJumperItem",
    "JumperItem*",
    "QPointF&",
    "wireSplitSlot",
    "Wire*",
    "newPos",
    "oldPos",
    "oldLine",
    "postImageSlot",
    "GroundPlaneGeneratorOld*",
    "QImage*",
    "copperImage",
    "boardImage",
    "QGraphicsItem*",
    "board",
    "QList<QRectF>*",
    "gotFabQuote",
    "QNetworkReply*",
    "getDroppedItemViewLayerPlacement",
    "ModelPart*",
    "modelPart",
    "ViewLayer::ViewLayerPlacement&"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPCBSketchWidgetENDCLASS_t {
    uint offsetsAndSizes[98];
    char stringdata0[16];
    char stringdata1[14];
    char stringdata2[1];
    char stringdata3[14];
    char stringdata4[10];
    char stringdata5[12];
    char stringdata6[30];
    char stringdata7[6];
    char stringdata8[6];
    char stringdata9[14];
    char stringdata10[14];
    char stringdata11[19];
    char stringdata12[17];
    char stringdata13[17];
    char stringdata14[20];
    char stringdata15[20];
    char stringdata16[23];
    char stringdata17[12];
    char stringdata18[2];
    char stringdata19[2];
    char stringdata20[7];
    char stringdata21[29];
    char stringdata22[7];
    char stringdata23[5];
    char stringdata24[18];
    char stringdata25[7];
    char stringdata26[3];
    char stringdata27[16];
    char stringdata28[12];
    char stringdata29[9];
    char stringdata30[14];
    char stringdata31[6];
    char stringdata32[7];
    char stringdata33[7];
    char stringdata34[8];
    char stringdata35[14];
    char stringdata36[25];
    char stringdata37[8];
    char stringdata38[12];
    char stringdata39[11];
    char stringdata40[15];
    char stringdata41[6];
    char stringdata42[15];
    char stringdata43[12];
    char stringdata44[15];
    char stringdata45[33];
    char stringdata46[11];
    char stringdata47[10];
    char stringdata48[31];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPCBSketchWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPCBSketchWidgetENDCLASS_t qt_meta_stringdata_CLASSPCBSketchWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 15),  // "PCBSketchWidget"
        QT_MOC_LITERAL(16, 13),  // "subSwapSignal"
        QT_MOC_LITERAL(30, 0),  // ""
        QT_MOC_LITERAL(31, 13),  // "SketchWidget*"
        QT_MOC_LITERAL(45, 9),  // "ItemBase*"
        QT_MOC_LITERAL(55, 11),  // "newModuleID"
        QT_MOC_LITERAL(67, 29),  // "ViewLayer::ViewLayerPlacement"
        QT_MOC_LITERAL(97, 5),  // "long&"
        QT_MOC_LITERAL(103, 5),  // "newID"
        QT_MOC_LITERAL(109, 13),  // "QUndoCommand*"
        QT_MOC_LITERAL(123, 13),  // "parentCommand"
        QT_MOC_LITERAL(137, 18),  // "boardDeletedSignal"
        QT_MOC_LITERAL(156, 16),  // "groundFillSignal"
        QT_MOC_LITERAL(173, 16),  // "copperFillSignal"
        QT_MOC_LITERAL(190, 19),  // "groundFillOldSignal"
        QT_MOC_LITERAL(210, 19),  // "copperFillOldSignal"
        QT_MOC_LITERAL(230, 22),  // "fabQuoteFinishedSignal"
        QT_MOC_LITERAL(253, 11),  // "resizeBoard"
        QT_MOC_LITERAL(265, 1),  // "w"
        QT_MOC_LITERAL(267, 1),  // "h"
        QT_MOC_LITERAL(269, 6),  // "doEmit"
        QT_MOC_LITERAL(276, 28),  // "showLabelFirstTimeForCommand"
        QT_MOC_LITERAL(305, 6),  // "itemID"
        QT_MOC_LITERAL(312, 4),  // "show"
        QT_MOC_LITERAL(317, 17),  // "changeBoardLayers"
        QT_MOC_LITERAL(335, 6),  // "layers"
        QT_MOC_LITERAL(342, 2),  // "id"
        QT_MOC_LITERAL(345, 15),  // "alignJumperItem"
        QT_MOC_LITERAL(361, 11),  // "JumperItem*"
        QT_MOC_LITERAL(373, 8),  // "QPointF&"
        QT_MOC_LITERAL(382, 13),  // "wireSplitSlot"
        QT_MOC_LITERAL(396, 5),  // "Wire*"
        QT_MOC_LITERAL(402, 6),  // "newPos"
        QT_MOC_LITERAL(409, 6),  // "oldPos"
        QT_MOC_LITERAL(416, 7),  // "oldLine"
        QT_MOC_LITERAL(424, 13),  // "postImageSlot"
        QT_MOC_LITERAL(438, 24),  // "GroundPlaneGeneratorOld*"
        QT_MOC_LITERAL(463, 7),  // "QImage*"
        QT_MOC_LITERAL(471, 11),  // "copperImage"
        QT_MOC_LITERAL(483, 10),  // "boardImage"
        QT_MOC_LITERAL(494, 14),  // "QGraphicsItem*"
        QT_MOC_LITERAL(509, 5),  // "board"
        QT_MOC_LITERAL(515, 14),  // "QList<QRectF>*"
        QT_MOC_LITERAL(530, 11),  // "gotFabQuote"
        QT_MOC_LITERAL(542, 14),  // "QNetworkReply*"
        QT_MOC_LITERAL(557, 32),  // "getDroppedItemViewLayerPlacement"
        QT_MOC_LITERAL(590, 10),  // "ModelPart*"
        QT_MOC_LITERAL(601, 9),  // "modelPart"
        QT_MOC_LITERAL(611, 30)   // "ViewLayer::ViewLayerPlacement&"
    },
    "PCBSketchWidget",
    "subSwapSignal",
    "",
    "SketchWidget*",
    "ItemBase*",
    "newModuleID",
    "ViewLayer::ViewLayerPlacement",
    "long&",
    "newID",
    "QUndoCommand*",
    "parentCommand",
    "boardDeletedSignal",
    "groundFillSignal",
    "copperFillSignal",
    "groundFillOldSignal",
    "copperFillOldSignal",
    "fabQuoteFinishedSignal",
    "resizeBoard",
    "w",
    "h",
    "doEmit",
    "showLabelFirstTimeForCommand",
    "itemID",
    "show",
    "changeBoardLayers",
    "layers",
    "id",
    "alignJumperItem",
    "JumperItem*",
    "QPointF&",
    "wireSplitSlot",
    "Wire*",
    "newPos",
    "oldPos",
    "oldLine",
    "postImageSlot",
    "GroundPlaneGeneratorOld*",
    "QImage*",
    "copperImage",
    "boardImage",
    "QGraphicsItem*",
    "board",
    "QList<QRectF>*",
    "gotFabQuote",
    "QNetworkReply*",
    "getDroppedItemViewLayerPlacement",
    "ModelPart*",
    "modelPart",
    "ViewLayer::ViewLayerPlacement&"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPCBSketchWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    6,  110,    2, 0x06,    1 /* Public */,
      11,    0,  123,    2, 0x06,    8 /* Public */,
      12,    0,  124,    2, 0x06,    9 /* Public */,
      13,    0,  125,    2, 0x06,   10 /* Public */,
      14,    0,  126,    2, 0x06,   11 /* Public */,
      15,    0,  127,    2, 0x06,   12 /* Public */,
      16,    0,  128,    2, 0x06,   13 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      17,    3,  129,    2, 0x0a,   14 /* Public */,
      21,    3,  136,    2, 0x0a,   18 /* Public */,
      24,    2,  143,    2, 0x0a,   22 /* Public */,
      17,    3,  148,    2, 0x0a,   25 /* Public */,
      27,    2,  155,    2, 0x09,   29 /* Protected */,
      30,    4,  160,    2, 0x09,   32 /* Protected */,
      35,    5,  169,    2, 0x09,   37 /* Protected */,
      43,    1,  180,    2, 0x09,   43 /* Protected */,
      45,    2,  183,    2, 0x09,   45 /* Protected */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 4, QMetaType::QString, 0x80000000 | 6, 0x80000000 | 7, 0x80000000 | 9,    2,    2,    5,    2,    8,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Bool,   18,   19,   20,
    QMetaType::Void, QMetaType::Long, QMetaType::Bool, QMetaType::Bool,   22,   23,   20,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,   25,   20,
    0x80000000 | 4, QMetaType::Long, QMetaType::Double, QMetaType::Double,   26,   18,   19,
    QMetaType::Void, 0x80000000 | 28, 0x80000000 | 29,    2,    2,
    QMetaType::Void, 0x80000000 | 31, QMetaType::QPointF, QMetaType::QPointF, QMetaType::QLineF,    2,   32,   33,   34,
    QMetaType::Void, 0x80000000 | 36, 0x80000000 | 37, 0x80000000 | 37, 0x80000000 | 40, 0x80000000 | 42,    2,   38,   39,   41,    2,
    QMetaType::Void, 0x80000000 | 44,    2,
    QMetaType::Void, 0x80000000 | 46, 0x80000000 | 48,   47,    2,

       0        // eod
};

Q_CONSTINIT const QMetaObject PCBSketchWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<SketchWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSPCBSketchWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPCBSketchWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPCBSketchWidgetENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PCBSketchWidget, std::true_type>,
        // method 'subSwapSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement, std::false_type>,
        QtPrivate::TypeAndForceComplete<long &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'boardDeletedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'groundFillSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copperFillSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'groundFillOldSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copperFillOldSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'fabQuoteFinishedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'resizeBoard'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'showLabelFirstTimeForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'changeBoardLayers'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'resizeBoard'
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'alignJumperItem'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<JumperItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF &, std::false_type>,
        // method 'wireSplitSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QLineF &, std::false_type>,
        // method 'postImageSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<GroundPlaneGeneratorOld *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QImage *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QImage *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<QRectF> *, std::false_type>,
        // method 'gotFabQuote'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QNetworkReply *, std::false_type>,
        // method 'getDroppedItemViewLayerPlacement'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement &, std::false_type>
    >,
    nullptr
} };

void PCBSketchWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PCBSketchWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->subSwapSignal((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<long&>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[6]))); break;
        case 1: _t->boardDeletedSignal(); break;
        case 2: _t->groundFillSignal(); break;
        case 3: _t->copperFillSignal(); break;
        case 4: _t->groundFillOldSignal(); break;
        case 5: _t->copperFillOldSignal(); break;
        case 6: _t->fabQuoteFinishedSignal(); break;
        case 7: _t->resizeBoard((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 8: _t->showLabelFirstTimeForCommand((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 9: _t->changeBoardLayers((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 10: { ItemBase* _r = _t->resizeBoard((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[3])));
            if (_a[0]) *reinterpret_cast< ItemBase**>(_a[0]) = std::move(_r); }  break;
        case 11: _t->alignJumperItem((*reinterpret_cast< std::add_pointer_t<JumperItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPointF&>>(_a[2]))); break;
        case 12: _t->wireSplitSlot((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QLineF>>(_a[4]))); break;
        case 13: _t->postImageSlot((*reinterpret_cast< std::add_pointer_t<GroundPlaneGeneratorOld*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QImage*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QImage*>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QGraphicsItem*>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QList<QRectF>*>>(_a[5]))); break;
        case 14: _t->gotFabQuote((*reinterpret_cast< std::add_pointer_t<QNetworkReply*>>(_a[1]))); break;
        case 15: _t->getDroppedItemViewLayerPlacement((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement&>>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 13:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 3:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QGraphicsItem* >(); break;
            }
            break;
        case 14:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QNetworkReply* >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PCBSketchWidget::*)(SketchWidget * , ItemBase * , const QString & , ViewLayer::ViewLayerPlacement , long & , QUndoCommand * );
            if (_t _q_method = &PCBSketchWidget::subSwapSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PCBSketchWidget::*)();
            if (_t _q_method = &PCBSketchWidget::boardDeletedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PCBSketchWidget::*)();
            if (_t _q_method = &PCBSketchWidget::groundFillSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (PCBSketchWidget::*)();
            if (_t _q_method = &PCBSketchWidget::copperFillSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (PCBSketchWidget::*)();
            if (_t _q_method = &PCBSketchWidget::groundFillOldSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (PCBSketchWidget::*)();
            if (_t _q_method = &PCBSketchWidget::copperFillOldSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (PCBSketchWidget::*)();
            if (_t _q_method = &PCBSketchWidget::fabQuoteFinishedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
    }
}

const QMetaObject *PCBSketchWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PCBSketchWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPCBSketchWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return SketchWidget::qt_metacast(_clname);
}

int PCBSketchWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SketchWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void PCBSketchWidget::subSwapSignal(SketchWidget * _t1, ItemBase * _t2, const QString & _t3, ViewLayer::ViewLayerPlacement _t4, long & _t5, QUndoCommand * _t6)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void PCBSketchWidget::boardDeletedSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void PCBSketchWidget::groundFillSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void PCBSketchWidget::copperFillSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void PCBSketchWidget::groundFillOldSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void PCBSketchWidget::copperFillOldSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void PCBSketchWidget::fabQuoteFinishedSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}
QT_WARNING_POP
