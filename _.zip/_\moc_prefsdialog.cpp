/****************************************************************************
** Meta object code from reading C++ file 'prefsdialog.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/dialogs/prefsdialog.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'prefsdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPrefsDialogENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPrefsDialogENDCLASS = QtMocHelpers::stringData(
    "PrefsDialog",
    "changeLanguage",
    "",
    "clear",
    "setConnectedColor",
    "setUnconnectedColor",
    "changeWheelBehavior",
    "toggleAutosave",
    "changeAutosavePeriod",
    "curvyChanged",
    "chooseProgrammer"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPrefsDialogENDCLASS_t {
    uint offsetsAndSizes[22];
    char stringdata0[12];
    char stringdata1[15];
    char stringdata2[1];
    char stringdata3[6];
    char stringdata4[18];
    char stringdata5[20];
    char stringdata6[20];
    char stringdata7[15];
    char stringdata8[21];
    char stringdata9[13];
    char stringdata10[17];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPrefsDialogENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPrefsDialogENDCLASS_t qt_meta_stringdata_CLASSPrefsDialogENDCLASS = {
    {
        QT_MOC_LITERAL(0, 11),  // "PrefsDialog"
        QT_MOC_LITERAL(12, 14),  // "changeLanguage"
        QT_MOC_LITERAL(27, 0),  // ""
        QT_MOC_LITERAL(28, 5),  // "clear"
        QT_MOC_LITERAL(34, 17),  // "setConnectedColor"
        QT_MOC_LITERAL(52, 19),  // "setUnconnectedColor"
        QT_MOC_LITERAL(72, 19),  // "changeWheelBehavior"
        QT_MOC_LITERAL(92, 14),  // "toggleAutosave"
        QT_MOC_LITERAL(107, 20),  // "changeAutosavePeriod"
        QT_MOC_LITERAL(128, 12),  // "curvyChanged"
        QT_MOC_LITERAL(141, 16)   // "chooseProgrammer"
    },
    "PrefsDialog",
    "changeLanguage",
    "",
    "clear",
    "setConnectedColor",
    "setUnconnectedColor",
    "changeWheelBehavior",
    "toggleAutosave",
    "changeAutosavePeriod",
    "curvyChanged",
    "chooseProgrammer"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPrefsDialogENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   68,    2, 0x09,    1 /* Protected */,
       3,    0,   71,    2, 0x09,    3 /* Protected */,
       4,    0,   72,    2, 0x09,    4 /* Protected */,
       5,    0,   73,    2, 0x09,    5 /* Protected */,
       6,    0,   74,    2, 0x09,    6 /* Protected */,
       7,    1,   75,    2, 0x09,    7 /* Protected */,
       8,    1,   78,    2, 0x09,    9 /* Protected */,
       9,    0,   81,    2, 0x09,   11 /* Protected */,
      10,    0,   82,    2, 0x09,   12 /* Protected */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject PrefsDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSPrefsDialogENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPrefsDialogENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPrefsDialogENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PrefsDialog, std::true_type>,
        // method 'changeLanguage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'clear'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setConnectedColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setUnconnectedColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'changeWheelBehavior'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toggleAutosave'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'changeAutosavePeriod'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'curvyChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'chooseProgrammer'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void PrefsDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PrefsDialog *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->changeLanguage((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->clear(); break;
        case 2: _t->setConnectedColor(); break;
        case 3: _t->setUnconnectedColor(); break;
        case 4: _t->changeWheelBehavior(); break;
        case 5: _t->toggleAutosave((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 6: _t->changeAutosavePeriod((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->curvyChanged(); break;
        case 8: _t->chooseProgrammer(); break;
        default: ;
        }
    }
}

const QMetaObject *PrefsDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PrefsDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPrefsDialogENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int PrefsDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
