/****************************************************************************
** Meta object code from reading C++ file 'note.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/items/note.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'note.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSNoteENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSNoteENDCLASS = QtMocHelpers::stringData(
    "Note",
    "contentsChangeSlot",
    "",
    "position",
    "charsAdded",
    "charsRemoved",
    "contentsChangedSlot",
    "linkDialog",
    "handleZoomChangedSlot",
    "scale",
    "handleMousePressSlot",
    "QGraphicsSceneMouseEvent*",
    "event",
    "ResizeHandle*",
    "resizeHandle",
    "handleMouseMoveSlot",
    "handleMouseReleaseSlot"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSNoteENDCLASS_t {
    uint offsetsAndSizes[34];
    char stringdata0[5];
    char stringdata1[19];
    char stringdata2[1];
    char stringdata3[9];
    char stringdata4[11];
    char stringdata5[13];
    char stringdata6[20];
    char stringdata7[11];
    char stringdata8[22];
    char stringdata9[6];
    char stringdata10[21];
    char stringdata11[26];
    char stringdata12[6];
    char stringdata13[14];
    char stringdata14[13];
    char stringdata15[20];
    char stringdata16[23];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSNoteENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSNoteENDCLASS_t qt_meta_stringdata_CLASSNoteENDCLASS = {
    {
        QT_MOC_LITERAL(0, 4),  // "Note"
        QT_MOC_LITERAL(5, 18),  // "contentsChangeSlot"
        QT_MOC_LITERAL(24, 0),  // ""
        QT_MOC_LITERAL(25, 8),  // "position"
        QT_MOC_LITERAL(34, 10),  // "charsAdded"
        QT_MOC_LITERAL(45, 12),  // "charsRemoved"
        QT_MOC_LITERAL(58, 19),  // "contentsChangedSlot"
        QT_MOC_LITERAL(78, 10),  // "linkDialog"
        QT_MOC_LITERAL(89, 21),  // "handleZoomChangedSlot"
        QT_MOC_LITERAL(111, 5),  // "scale"
        QT_MOC_LITERAL(117, 20),  // "handleMousePressSlot"
        QT_MOC_LITERAL(138, 25),  // "QGraphicsSceneMouseEvent*"
        QT_MOC_LITERAL(164, 5),  // "event"
        QT_MOC_LITERAL(170, 13),  // "ResizeHandle*"
        QT_MOC_LITERAL(184, 12),  // "resizeHandle"
        QT_MOC_LITERAL(197, 19),  // "handleMouseMoveSlot"
        QT_MOC_LITERAL(217, 22)   // "handleMouseReleaseSlot"
    },
    "Note",
    "contentsChangeSlot",
    "",
    "position",
    "charsAdded",
    "charsRemoved",
    "contentsChangedSlot",
    "linkDialog",
    "handleZoomChangedSlot",
    "scale",
    "handleMousePressSlot",
    "QGraphicsSceneMouseEvent*",
    "event",
    "ResizeHandle*",
    "resizeHandle",
    "handleMouseMoveSlot",
    "handleMouseReleaseSlot"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSNoteENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    3,   56,    2, 0x09,    1 /* Protected */,
       6,    0,   63,    2, 0x09,    5 /* Protected */,
       7,    0,   64,    2, 0x09,    6 /* Protected */,
       8,    1,   65,    2, 0x09,    7 /* Protected */,
      10,    2,   68,    2, 0x09,    9 /* Protected */,
      15,    2,   73,    2, 0x09,   12 /* Protected */,
      16,    2,   78,    2, 0x09,   15 /* Protected */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,    3,    4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,    9,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 13,   12,   14,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 13,   12,   14,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 13,   12,   14,

       0        // eod
};

Q_CONSTINIT const QMetaObject Note::staticMetaObject = { {
    QMetaObject::SuperData::link<ItemBase::staticMetaObject>(),
    qt_meta_stringdata_CLASSNoteENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSNoteENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSNoteENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Note, std::true_type>,
        // method 'contentsChangeSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'contentsChangedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'linkDialog'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleZoomChangedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'handleMousePressSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsSceneMouseEvent *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ResizeHandle *, std::false_type>,
        // method 'handleMouseMoveSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsSceneMouseEvent *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ResizeHandle *, std::false_type>,
        // method 'handleMouseReleaseSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsSceneMouseEvent *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ResizeHandle *, std::false_type>
    >,
    nullptr
} };

void Note::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Note *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->contentsChangeSlot((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3]))); break;
        case 1: _t->contentsChangedSlot(); break;
        case 2: _t->linkDialog(); break;
        case 3: _t->handleZoomChangedSlot((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 4: _t->handleMousePressSlot((*reinterpret_cast< std::add_pointer_t<QGraphicsSceneMouseEvent*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ResizeHandle*>>(_a[2]))); break;
        case 5: _t->handleMouseMoveSlot((*reinterpret_cast< std::add_pointer_t<QGraphicsSceneMouseEvent*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ResizeHandle*>>(_a[2]))); break;
        case 6: _t->handleMouseReleaseSlot((*reinterpret_cast< std::add_pointer_t<QGraphicsSceneMouseEvent*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ResizeHandle*>>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObject *Note::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Note::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSNoteENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return ItemBase::qt_metacast(_clname);
}

int Note::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ItemBase::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 7;
    }
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSNoteGraphicsTextItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSNoteGraphicsTextItemENDCLASS = QtMocHelpers::stringData(
    "NoteGraphicsTextItem"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSNoteGraphicsTextItemENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[21];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSNoteGraphicsTextItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSNoteGraphicsTextItemENDCLASS_t qt_meta_stringdata_CLASSNoteGraphicsTextItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 20)   // "NoteGraphicsTextItem"
    },
    "NoteGraphicsTextItem"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSNoteGraphicsTextItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject NoteGraphicsTextItem::staticMetaObject = { {
    QMetaObject::SuperData::link<QGraphicsTextItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSNoteGraphicsTextItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSNoteGraphicsTextItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSNoteGraphicsTextItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<NoteGraphicsTextItem, std::true_type>
    >,
    nullptr
} };

void NoteGraphicsTextItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *NoteGraphicsTextItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NoteGraphicsTextItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSNoteGraphicsTextItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QGraphicsTextItem::qt_metacast(_clname);
}

int NoteGraphicsTextItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsTextItem::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSLinkDialogENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSLinkDialogENDCLASS = QtMocHelpers::stringData(
    "LinkDialog"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSLinkDialogENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[11];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSLinkDialogENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSLinkDialogENDCLASS_t qt_meta_stringdata_CLASSLinkDialogENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10)   // "LinkDialog"
    },
    "LinkDialog"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSLinkDialogENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject LinkDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSLinkDialogENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSLinkDialogENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSLinkDialogENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<LinkDialog, std::true_type>
    >,
    nullptr
} };

void LinkDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *LinkDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LinkDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSLinkDialogENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int LinkDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
