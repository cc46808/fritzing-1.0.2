/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/mainwindow/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSFTabWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSFTabWidgetENDCLASS = QtMocHelpers::stringData(
    "FTabWidget"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSFTabWidgetENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[11];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSFTabWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSFTabWidgetENDCLASS_t qt_meta_stringdata_CLASSFTabWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10)   // "FTabWidget"
    },
    "FTabWidget"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSFTabWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject FTabWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QTabWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSFTabWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSFTabWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSFTabWidgetENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FTabWidget, std::true_type>
    >,
    nullptr
} };

void FTabWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *FTabWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FTabWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSFTabWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QTabWidget::qt_metacast(_clname);
}

int FTabWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTabWidget::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSFTabBarENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSFTabBarENDCLASS = QtMocHelpers::stringData(
    "FTabBar"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSFTabBarENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[8];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSFTabBarENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSFTabBarENDCLASS_t qt_meta_stringdata_CLASSFTabBarENDCLASS = {
    {
        QT_MOC_LITERAL(0, 7)   // "FTabBar"
    },
    "FTabBar"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSFTabBarENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject FTabBar::staticMetaObject = { {
    QMetaObject::SuperData::link<QTabBar::staticMetaObject>(),
    qt_meta_stringdata_CLASSFTabBarENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSFTabBarENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSFTabBarENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FTabBar, std::true_type>
    >,
    nullptr
} };

void FTabBar::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *FTabBar::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FTabBar::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSFTabBarENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QTabBar::qt_metacast(_clname);
}

int FTabBar::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTabBar::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSGridSizeDialogENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSGridSizeDialogENDCLASS = QtMocHelpers::stringData(
    "GridSizeDialog"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSGridSizeDialogENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[15];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSGridSizeDialogENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSGridSizeDialogENDCLASS_t qt_meta_stringdata_CLASSGridSizeDialogENDCLASS = {
    {
        QT_MOC_LITERAL(0, 14)   // "GridSizeDialog"
    },
    "GridSizeDialog"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSGridSizeDialogENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject GridSizeDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSGridSizeDialogENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSGridSizeDialogENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSGridSizeDialogENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<GridSizeDialog, std::true_type>
    >,
    nullptr
} };

void GridSizeDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *GridSizeDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GridSizeDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSGridSizeDialogENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int GridSizeDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "alienPartsDismissed",
    "",
    "mainWindowMoved",
    "QWidget*",
    "changeActivationSignal",
    "activate",
    "originator",
    "externalProcessSignal",
    "QString&",
    "name",
    "path",
    "QStringList&",
    "args",
    "ensureClosable",
    "loadBundledPart",
    "QList<ModelPart*>",
    "fileName",
    "addToBin",
    "loadPart",
    "acceptAlienFiles",
    "statusMessage",
    "message",
    "timeout",
    "showPCBView",
    "groundFill",
    "groundFillOld",
    "removeGroundFill",
    "copperFill",
    "copperFillOld",
    "setOneGroundFillSeed",
    "setGroundFillSeeds",
    "clearGroundFillSeeds",
    "changeBoardLayers",
    "layers",
    "doEmit",
    "selectAllObsolete",
    "swapObsolete",
    "swapBoardImageSlot",
    "SketchWidget*",
    "sketchWidget",
    "ItemBase*",
    "itemBase",
    "filename",
    "moduleID",
    "addName",
    "updateTraceMenu",
    "updateExportMenu",
    "updateFileMenu",
    "showStatusMessage",
    "orderFabHoverEnter",
    "orderFabHoverLeave",
    "setGroundFillKeepout",
    "oldSchematicsSlot",
    "bool&",
    "useOldSchematics",
    "showWelcomeView",
    "putItemByModuleID",
    "postKeyEvent",
    "serializedKeys",
    "mainLoad",
    "revert",
    "openRecentOrExampleFile",
    "actionText",
    "print",
    "doExport",
    "exportEtchable",
    "about",
    "tipsAndTricks",
    "firstTimeHelp",
    "copy",
    "cut",
    "paste",
    "pasteInPlace",
    "duplicate",
    "doDelete",
    "doDeleteMinus",
    "selectAll",
    "deselect",
    "zoomIn",
    "zoomOut",
    "fitInWindow",
    "actualSize",
    "hundredPercentSize",
    "alignToGrid",
    "showGrid",
    "setGridSize",
    "setBackgroundColor",
    "colorWiresByLength",
    "showBreadboardView",
    "showSchematicView",
    "showProgramView",
    "showPartsBinIconView",
    "showPartsBinListView",
    "updateEditMenu",
    "updateLayerMenu",
    "resetLayout",
    "updatePartMenu",
    "updateWireMenu",
    "updateTransformationActions",
    "updateRecentFileActions",
    "tabWidget_currentChanged",
    "index",
    "createNewSketch",
    "minimize",
    "toggleToolbar",
    "toggle",
    "togglePartLibrary",
    "toggleInfo",
    "toggleUndoHistory",
    "toggleDebuggerOutput",
    "openHelp",
    "openExamples",
    "openPartsReference",
    "visitFritzingDotOrg",
    "partsEditorHelp",
    "updateWindowMenu",
    "pageSetup",
    "sendToBack",
    "sendBackward",
    "bringForward",
    "bringToFront",
    "alignLeft",
    "alignRight",
    "alignVerticalCenter",
    "alignTop",
    "alignHorizontalCenter",
    "alignBottom",
    "rotate90cw",
    "rotate90ccw",
    "rotate180",
    "rotate45ccw",
    "rotate45cw",
    "rotateIncCCW",
    "rotateIncCW",
    "rotateIncCCWRubberBand",
    "rotateIncCWRubberBand",
    "flipHorizontal",
    "flipVertical",
    "showAllLayers",
    "hideAllLayers",
    "addBendpoint",
    "convertToVia",
    "convertToBendpoint",
    "flattenCurve",
    "disconnectAll",
    "openInPartsEditorNew",
    "openNewPartsEditor",
    "PaletteItem*",
    "updateZoomSlider",
    "zoom",
    "updateZoomOptionsNoMatterWhat",
    "updateViewZoom",
    "newZoom",
    "setInfoViewOnHover",
    "infoViewOnHover",
    "updateItemMenu",
    "newAutoroute",
    "orderFab",
    "activeLayerTop",
    "activeLayerBottom",
    "activeLayerBoth",
    "toggleActiveLayer",
    "createTrace",
    "excludeFromAutoroute",
    "selectAllTraces",
    "showUnrouted",
    "selectAllCopperFill",
    "updateRoutingStatus",
    "selectAllExcludedTraces",
    "selectAllIncludedTraces",
    "selectAllJumperItems",
    "selectAllVias",
    "shareOnline",
    "saveBundledPart",
    "moduleId",
    "saveBundledAux",
    "ModelPart*",
    "mp",
    "QDir",
    "destFolder",
    "binSaved",
    "hasAlienParts",
    "routingStatusSlot",
    "RoutingStatus",
    "applyReadOnlyChange",
    "isReadOnly",
    "raiseAndActivate",
    "activateWindowAux",
    "showPartLabels",
    "addNote",
    "reportBug",
    "enableDebug",
    "tidyWires",
    "changeWireColor",
    "checked",
    "startSaveInstancesSlot",
    "QXmlStreamWriter&",
    "loadedViewsSlot",
    "ModelBase*",
    "QDomElement&",
    "views",
    "loadedRootSlot",
    "loadedProjectPropertiesSlot",
    "QDomElement",
    "projectProperties",
    "obsoleteSMDOrientationSlot",
    "exportNormalizedSVG",
    "exportNormalizedFlattenedSVG",
    "dumpAllParts",
    "testConnectors",
    "launchExternalProcess",
    "externalProcess",
    "processError",
    "QProcess::ProcessError",
    "processFinished",
    "exitCode",
    "QProcess::ExitStatus",
    "exitStatus",
    "processReadyRead",
    "processStateChanged",
    "QProcess::ProcessState",
    "newState",
    "throwFakeException",
    "dropPaste",
    "openProgramWindow",
    "linkToProgramFile",
    "Platform*",
    "platform",
    "addLink",
    "strong",
    "newDesignRulesCheck",
    "subSwapSlot",
    "newModuleID",
    "ViewLayer::ViewLayerPlacement",
    "long&",
    "newID",
    "QUndoCommand*",
    "parentCommand",
    "updateLayerMenuSlot",
    "save",
    "saveAs",
    "backupSketch",
    "undoStackCleanChanged",
    "isClean",
    "autosaveNeeded",
    "changeTraceLayer",
    "routingStatusLabelMousePress",
    "QMouseEvent*",
    "routingStatusLabelMouseRelease",
    "selectMoveLock",
    "moveLock",
    "setSticky",
    "autorouterSettings",
    "boardDeletedSlot",
    "cursorLocationSlot",
    "locationLabelClicked",
    "swapSelectedMap",
    "family",
    "prop",
    "QMap<QString,QString>&",
    "currPropsMap",
    "filenameIfSlot",
    "openURL",
    "setActiveWire",
    "Wire*",
    "setActiveConnectorItem",
    "ConnectorItem*",
    "gridUnits",
    "restoreDefaultGrid",
    "checkLoadedTraces",
    "keepMargins",
    "dockChangeActivation",
    "addToMyParts",
    "hidePartSilkscreen",
    "fabQuote",
    "findPartInSketch",
    "fireQuote",
    "setViewFromBelowToggle",
    "setViewFromBelow",
    "setViewFromAbove",
    "updateWelcomeViewRecentList",
    "initZoom",
    "onShareOnlineFinished"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[568];
    char stringdata0[11];
    char stringdata1[20];
    char stringdata2[1];
    char stringdata3[16];
    char stringdata4[9];
    char stringdata5[23];
    char stringdata6[9];
    char stringdata7[11];
    char stringdata8[22];
    char stringdata9[9];
    char stringdata10[5];
    char stringdata11[5];
    char stringdata12[13];
    char stringdata13[5];
    char stringdata14[15];
    char stringdata15[16];
    char stringdata16[18];
    char stringdata17[9];
    char stringdata18[9];
    char stringdata19[9];
    char stringdata20[17];
    char stringdata21[14];
    char stringdata22[8];
    char stringdata23[8];
    char stringdata24[12];
    char stringdata25[11];
    char stringdata26[14];
    char stringdata27[17];
    char stringdata28[11];
    char stringdata29[14];
    char stringdata30[21];
    char stringdata31[19];
    char stringdata32[21];
    char stringdata33[18];
    char stringdata34[7];
    char stringdata35[7];
    char stringdata36[18];
    char stringdata37[13];
    char stringdata38[19];
    char stringdata39[14];
    char stringdata40[13];
    char stringdata41[10];
    char stringdata42[9];
    char stringdata43[9];
    char stringdata44[9];
    char stringdata45[8];
    char stringdata46[16];
    char stringdata47[17];
    char stringdata48[15];
    char stringdata49[18];
    char stringdata50[19];
    char stringdata51[19];
    char stringdata52[21];
    char stringdata53[18];
    char stringdata54[6];
    char stringdata55[17];
    char stringdata56[16];
    char stringdata57[18];
    char stringdata58[13];
    char stringdata59[15];
    char stringdata60[9];
    char stringdata61[7];
    char stringdata62[24];
    char stringdata63[11];
    char stringdata64[6];
    char stringdata65[9];
    char stringdata66[15];
    char stringdata67[6];
    char stringdata68[14];
    char stringdata69[14];
    char stringdata70[5];
    char stringdata71[4];
    char stringdata72[6];
    char stringdata73[13];
    char stringdata74[10];
    char stringdata75[9];
    char stringdata76[14];
    char stringdata77[10];
    char stringdata78[9];
    char stringdata79[7];
    char stringdata80[8];
    char stringdata81[12];
    char stringdata82[11];
    char stringdata83[19];
    char stringdata84[12];
    char stringdata85[9];
    char stringdata86[12];
    char stringdata87[19];
    char stringdata88[19];
    char stringdata89[19];
    char stringdata90[18];
    char stringdata91[16];
    char stringdata92[21];
    char stringdata93[21];
    char stringdata94[15];
    char stringdata95[16];
    char stringdata96[12];
    char stringdata97[15];
    char stringdata98[15];
    char stringdata99[28];
    char stringdata100[24];
    char stringdata101[25];
    char stringdata102[6];
    char stringdata103[16];
    char stringdata104[9];
    char stringdata105[14];
    char stringdata106[7];
    char stringdata107[18];
    char stringdata108[11];
    char stringdata109[18];
    char stringdata110[21];
    char stringdata111[9];
    char stringdata112[13];
    char stringdata113[19];
    char stringdata114[20];
    char stringdata115[16];
    char stringdata116[17];
    char stringdata117[10];
    char stringdata118[11];
    char stringdata119[13];
    char stringdata120[13];
    char stringdata121[13];
    char stringdata122[10];
    char stringdata123[11];
    char stringdata124[20];
    char stringdata125[9];
    char stringdata126[22];
    char stringdata127[12];
    char stringdata128[11];
    char stringdata129[12];
    char stringdata130[10];
    char stringdata131[12];
    char stringdata132[11];
    char stringdata133[13];
    char stringdata134[12];
    char stringdata135[23];
    char stringdata136[22];
    char stringdata137[15];
    char stringdata138[13];
    char stringdata139[14];
    char stringdata140[14];
    char stringdata141[13];
    char stringdata142[13];
    char stringdata143[19];
    char stringdata144[13];
    char stringdata145[14];
    char stringdata146[21];
    char stringdata147[19];
    char stringdata148[13];
    char stringdata149[17];
    char stringdata150[5];
    char stringdata151[30];
    char stringdata152[15];
    char stringdata153[8];
    char stringdata154[19];
    char stringdata155[16];
    char stringdata156[15];
    char stringdata157[13];
    char stringdata158[9];
    char stringdata159[15];
    char stringdata160[18];
    char stringdata161[16];
    char stringdata162[18];
    char stringdata163[12];
    char stringdata164[21];
    char stringdata165[16];
    char stringdata166[13];
    char stringdata167[20];
    char stringdata168[20];
    char stringdata169[24];
    char stringdata170[24];
    char stringdata171[21];
    char stringdata172[14];
    char stringdata173[12];
    char stringdata174[16];
    char stringdata175[9];
    char stringdata176[15];
    char stringdata177[11];
    char stringdata178[3];
    char stringdata179[5];
    char stringdata180[11];
    char stringdata181[9];
    char stringdata182[14];
    char stringdata183[18];
    char stringdata184[14];
    char stringdata185[20];
    char stringdata186[11];
    char stringdata187[17];
    char stringdata188[18];
    char stringdata189[15];
    char stringdata190[8];
    char stringdata191[10];
    char stringdata192[12];
    char stringdata193[10];
    char stringdata194[16];
    char stringdata195[8];
    char stringdata196[23];
    char stringdata197[18];
    char stringdata198[16];
    char stringdata199[11];
    char stringdata200[13];
    char stringdata201[6];
    char stringdata202[15];
    char stringdata203[28];
    char stringdata204[12];
    char stringdata205[18];
    char stringdata206[27];
    char stringdata207[20];
    char stringdata208[29];
    char stringdata209[13];
    char stringdata210[15];
    char stringdata211[22];
    char stringdata212[16];
    char stringdata213[13];
    char stringdata214[23];
    char stringdata215[16];
    char stringdata216[9];
    char stringdata217[21];
    char stringdata218[11];
    char stringdata219[17];
    char stringdata220[20];
    char stringdata221[23];
    char stringdata222[9];
    char stringdata223[19];
    char stringdata224[10];
    char stringdata225[18];
    char stringdata226[18];
    char stringdata227[10];
    char stringdata228[9];
    char stringdata229[8];
    char stringdata230[7];
    char stringdata231[20];
    char stringdata232[12];
    char stringdata233[12];
    char stringdata234[30];
    char stringdata235[6];
    char stringdata236[6];
    char stringdata237[14];
    char stringdata238[14];
    char stringdata239[20];
    char stringdata240[5];
    char stringdata241[7];
    char stringdata242[13];
    char stringdata243[22];
    char stringdata244[8];
    char stringdata245[15];
    char stringdata246[17];
    char stringdata247[29];
    char stringdata248[13];
    char stringdata249[31];
    char stringdata250[15];
    char stringdata251[9];
    char stringdata252[10];
    char stringdata253[19];
    char stringdata254[17];
    char stringdata255[19];
    char stringdata256[21];
    char stringdata257[16];
    char stringdata258[7];
    char stringdata259[5];
    char stringdata260[23];
    char stringdata261[13];
    char stringdata262[15];
    char stringdata263[8];
    char stringdata264[14];
    char stringdata265[6];
    char stringdata266[23];
    char stringdata267[15];
    char stringdata268[10];
    char stringdata269[19];
    char stringdata270[18];
    char stringdata271[12];
    char stringdata272[21];
    char stringdata273[13];
    char stringdata274[19];
    char stringdata275[9];
    char stringdata276[17];
    char stringdata277[10];
    char stringdata278[23];
    char stringdata279[17];
    char stringdata280[17];
    char stringdata281[28];
    char stringdata282[9];
    char stringdata283[22];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 19),  // "alienPartsDismissed"
        QT_MOC_LITERAL(31, 0),  // ""
        QT_MOC_LITERAL(32, 15),  // "mainWindowMoved"
        QT_MOC_LITERAL(48, 8),  // "QWidget*"
        QT_MOC_LITERAL(57, 22),  // "changeActivationSignal"
        QT_MOC_LITERAL(80, 8),  // "activate"
        QT_MOC_LITERAL(89, 10),  // "originator"
        QT_MOC_LITERAL(100, 21),  // "externalProcessSignal"
        QT_MOC_LITERAL(122, 8),  // "QString&"
        QT_MOC_LITERAL(131, 4),  // "name"
        QT_MOC_LITERAL(136, 4),  // "path"
        QT_MOC_LITERAL(141, 12),  // "QStringList&"
        QT_MOC_LITERAL(154, 4),  // "args"
        QT_MOC_LITERAL(159, 14),  // "ensureClosable"
        QT_MOC_LITERAL(174, 15),  // "loadBundledPart"
        QT_MOC_LITERAL(190, 17),  // "QList<ModelPart*>"
        QT_MOC_LITERAL(208, 8),  // "fileName"
        QT_MOC_LITERAL(217, 8),  // "addToBin"
        QT_MOC_LITERAL(226, 8),  // "loadPart"
        QT_MOC_LITERAL(235, 16),  // "acceptAlienFiles"
        QT_MOC_LITERAL(252, 13),  // "statusMessage"
        QT_MOC_LITERAL(266, 7),  // "message"
        QT_MOC_LITERAL(274, 7),  // "timeout"
        QT_MOC_LITERAL(282, 11),  // "showPCBView"
        QT_MOC_LITERAL(294, 10),  // "groundFill"
        QT_MOC_LITERAL(305, 13),  // "groundFillOld"
        QT_MOC_LITERAL(319, 16),  // "removeGroundFill"
        QT_MOC_LITERAL(336, 10),  // "copperFill"
        QT_MOC_LITERAL(347, 13),  // "copperFillOld"
        QT_MOC_LITERAL(361, 20),  // "setOneGroundFillSeed"
        QT_MOC_LITERAL(382, 18),  // "setGroundFillSeeds"
        QT_MOC_LITERAL(401, 20),  // "clearGroundFillSeeds"
        QT_MOC_LITERAL(422, 17),  // "changeBoardLayers"
        QT_MOC_LITERAL(440, 6),  // "layers"
        QT_MOC_LITERAL(447, 6),  // "doEmit"
        QT_MOC_LITERAL(454, 17),  // "selectAllObsolete"
        QT_MOC_LITERAL(472, 12),  // "swapObsolete"
        QT_MOC_LITERAL(485, 18),  // "swapBoardImageSlot"
        QT_MOC_LITERAL(504, 13),  // "SketchWidget*"
        QT_MOC_LITERAL(518, 12),  // "sketchWidget"
        QT_MOC_LITERAL(531, 9),  // "ItemBase*"
        QT_MOC_LITERAL(541, 8),  // "itemBase"
        QT_MOC_LITERAL(550, 8),  // "filename"
        QT_MOC_LITERAL(559, 8),  // "moduleID"
        QT_MOC_LITERAL(568, 7),  // "addName"
        QT_MOC_LITERAL(576, 15),  // "updateTraceMenu"
        QT_MOC_LITERAL(592, 16),  // "updateExportMenu"
        QT_MOC_LITERAL(609, 14),  // "updateFileMenu"
        QT_MOC_LITERAL(624, 17),  // "showStatusMessage"
        QT_MOC_LITERAL(642, 18),  // "orderFabHoverEnter"
        QT_MOC_LITERAL(661, 18),  // "orderFabHoverLeave"
        QT_MOC_LITERAL(680, 20),  // "setGroundFillKeepout"
        QT_MOC_LITERAL(701, 17),  // "oldSchematicsSlot"
        QT_MOC_LITERAL(719, 5),  // "bool&"
        QT_MOC_LITERAL(725, 16),  // "useOldSchematics"
        QT_MOC_LITERAL(742, 15),  // "showWelcomeView"
        QT_MOC_LITERAL(758, 17),  // "putItemByModuleID"
        QT_MOC_LITERAL(776, 12),  // "postKeyEvent"
        QT_MOC_LITERAL(789, 14),  // "serializedKeys"
        QT_MOC_LITERAL(804, 8),  // "mainLoad"
        QT_MOC_LITERAL(813, 6),  // "revert"
        QT_MOC_LITERAL(820, 23),  // "openRecentOrExampleFile"
        QT_MOC_LITERAL(844, 10),  // "actionText"
        QT_MOC_LITERAL(855, 5),  // "print"
        QT_MOC_LITERAL(861, 8),  // "doExport"
        QT_MOC_LITERAL(870, 14),  // "exportEtchable"
        QT_MOC_LITERAL(885, 5),  // "about"
        QT_MOC_LITERAL(891, 13),  // "tipsAndTricks"
        QT_MOC_LITERAL(905, 13),  // "firstTimeHelp"
        QT_MOC_LITERAL(919, 4),  // "copy"
        QT_MOC_LITERAL(924, 3),  // "cut"
        QT_MOC_LITERAL(928, 5),  // "paste"
        QT_MOC_LITERAL(934, 12),  // "pasteInPlace"
        QT_MOC_LITERAL(947, 9),  // "duplicate"
        QT_MOC_LITERAL(957, 8),  // "doDelete"
        QT_MOC_LITERAL(966, 13),  // "doDeleteMinus"
        QT_MOC_LITERAL(980, 9),  // "selectAll"
        QT_MOC_LITERAL(990, 8),  // "deselect"
        QT_MOC_LITERAL(999, 6),  // "zoomIn"
        QT_MOC_LITERAL(1006, 7),  // "zoomOut"
        QT_MOC_LITERAL(1014, 11),  // "fitInWindow"
        QT_MOC_LITERAL(1026, 10),  // "actualSize"
        QT_MOC_LITERAL(1037, 18),  // "hundredPercentSize"
        QT_MOC_LITERAL(1056, 11),  // "alignToGrid"
        QT_MOC_LITERAL(1068, 8),  // "showGrid"
        QT_MOC_LITERAL(1077, 11),  // "setGridSize"
        QT_MOC_LITERAL(1089, 18),  // "setBackgroundColor"
        QT_MOC_LITERAL(1108, 18),  // "colorWiresByLength"
        QT_MOC_LITERAL(1127, 18),  // "showBreadboardView"
        QT_MOC_LITERAL(1146, 17),  // "showSchematicView"
        QT_MOC_LITERAL(1164, 15),  // "showProgramView"
        QT_MOC_LITERAL(1180, 20),  // "showPartsBinIconView"
        QT_MOC_LITERAL(1201, 20),  // "showPartsBinListView"
        QT_MOC_LITERAL(1222, 14),  // "updateEditMenu"
        QT_MOC_LITERAL(1237, 15),  // "updateLayerMenu"
        QT_MOC_LITERAL(1253, 11),  // "resetLayout"
        QT_MOC_LITERAL(1265, 14),  // "updatePartMenu"
        QT_MOC_LITERAL(1280, 14),  // "updateWireMenu"
        QT_MOC_LITERAL(1295, 27),  // "updateTransformationActions"
        QT_MOC_LITERAL(1323, 23),  // "updateRecentFileActions"
        QT_MOC_LITERAL(1347, 24),  // "tabWidget_currentChanged"
        QT_MOC_LITERAL(1372, 5),  // "index"
        QT_MOC_LITERAL(1378, 15),  // "createNewSketch"
        QT_MOC_LITERAL(1394, 8),  // "minimize"
        QT_MOC_LITERAL(1403, 13),  // "toggleToolbar"
        QT_MOC_LITERAL(1417, 6),  // "toggle"
        QT_MOC_LITERAL(1424, 17),  // "togglePartLibrary"
        QT_MOC_LITERAL(1442, 10),  // "toggleInfo"
        QT_MOC_LITERAL(1453, 17),  // "toggleUndoHistory"
        QT_MOC_LITERAL(1471, 20),  // "toggleDebuggerOutput"
        QT_MOC_LITERAL(1492, 8),  // "openHelp"
        QT_MOC_LITERAL(1501, 12),  // "openExamples"
        QT_MOC_LITERAL(1514, 18),  // "openPartsReference"
        QT_MOC_LITERAL(1533, 19),  // "visitFritzingDotOrg"
        QT_MOC_LITERAL(1553, 15),  // "partsEditorHelp"
        QT_MOC_LITERAL(1569, 16),  // "updateWindowMenu"
        QT_MOC_LITERAL(1586, 9),  // "pageSetup"
        QT_MOC_LITERAL(1596, 10),  // "sendToBack"
        QT_MOC_LITERAL(1607, 12),  // "sendBackward"
        QT_MOC_LITERAL(1620, 12),  // "bringForward"
        QT_MOC_LITERAL(1633, 12),  // "bringToFront"
        QT_MOC_LITERAL(1646, 9),  // "alignLeft"
        QT_MOC_LITERAL(1656, 10),  // "alignRight"
        QT_MOC_LITERAL(1667, 19),  // "alignVerticalCenter"
        QT_MOC_LITERAL(1687, 8),  // "alignTop"
        QT_MOC_LITERAL(1696, 21),  // "alignHorizontalCenter"
        QT_MOC_LITERAL(1718, 11),  // "alignBottom"
        QT_MOC_LITERAL(1730, 10),  // "rotate90cw"
        QT_MOC_LITERAL(1741, 11),  // "rotate90ccw"
        QT_MOC_LITERAL(1753, 9),  // "rotate180"
        QT_MOC_LITERAL(1763, 11),  // "rotate45ccw"
        QT_MOC_LITERAL(1775, 10),  // "rotate45cw"
        QT_MOC_LITERAL(1786, 12),  // "rotateIncCCW"
        QT_MOC_LITERAL(1799, 11),  // "rotateIncCW"
        QT_MOC_LITERAL(1811, 22),  // "rotateIncCCWRubberBand"
        QT_MOC_LITERAL(1834, 21),  // "rotateIncCWRubberBand"
        QT_MOC_LITERAL(1856, 14),  // "flipHorizontal"
        QT_MOC_LITERAL(1871, 12),  // "flipVertical"
        QT_MOC_LITERAL(1884, 13),  // "showAllLayers"
        QT_MOC_LITERAL(1898, 13),  // "hideAllLayers"
        QT_MOC_LITERAL(1912, 12),  // "addBendpoint"
        QT_MOC_LITERAL(1925, 12),  // "convertToVia"
        QT_MOC_LITERAL(1938, 18),  // "convertToBendpoint"
        QT_MOC_LITERAL(1957, 12),  // "flattenCurve"
        QT_MOC_LITERAL(1970, 13),  // "disconnectAll"
        QT_MOC_LITERAL(1984, 20),  // "openInPartsEditorNew"
        QT_MOC_LITERAL(2005, 18),  // "openNewPartsEditor"
        QT_MOC_LITERAL(2024, 12),  // "PaletteItem*"
        QT_MOC_LITERAL(2037, 16),  // "updateZoomSlider"
        QT_MOC_LITERAL(2054, 4),  // "zoom"
        QT_MOC_LITERAL(2059, 29),  // "updateZoomOptionsNoMatterWhat"
        QT_MOC_LITERAL(2089, 14),  // "updateViewZoom"
        QT_MOC_LITERAL(2104, 7),  // "newZoom"
        QT_MOC_LITERAL(2112, 18),  // "setInfoViewOnHover"
        QT_MOC_LITERAL(2131, 15),  // "infoViewOnHover"
        QT_MOC_LITERAL(2147, 14),  // "updateItemMenu"
        QT_MOC_LITERAL(2162, 12),  // "newAutoroute"
        QT_MOC_LITERAL(2175, 8),  // "orderFab"
        QT_MOC_LITERAL(2184, 14),  // "activeLayerTop"
        QT_MOC_LITERAL(2199, 17),  // "activeLayerBottom"
        QT_MOC_LITERAL(2217, 15),  // "activeLayerBoth"
        QT_MOC_LITERAL(2233, 17),  // "toggleActiveLayer"
        QT_MOC_LITERAL(2251, 11),  // "createTrace"
        QT_MOC_LITERAL(2263, 20),  // "excludeFromAutoroute"
        QT_MOC_LITERAL(2284, 15),  // "selectAllTraces"
        QT_MOC_LITERAL(2300, 12),  // "showUnrouted"
        QT_MOC_LITERAL(2313, 19),  // "selectAllCopperFill"
        QT_MOC_LITERAL(2333, 19),  // "updateRoutingStatus"
        QT_MOC_LITERAL(2353, 23),  // "selectAllExcludedTraces"
        QT_MOC_LITERAL(2377, 23),  // "selectAllIncludedTraces"
        QT_MOC_LITERAL(2401, 20),  // "selectAllJumperItems"
        QT_MOC_LITERAL(2422, 13),  // "selectAllVias"
        QT_MOC_LITERAL(2436, 11),  // "shareOnline"
        QT_MOC_LITERAL(2448, 15),  // "saveBundledPart"
        QT_MOC_LITERAL(2464, 8),  // "moduleId"
        QT_MOC_LITERAL(2473, 14),  // "saveBundledAux"
        QT_MOC_LITERAL(2488, 10),  // "ModelPart*"
        QT_MOC_LITERAL(2499, 2),  // "mp"
        QT_MOC_LITERAL(2502, 4),  // "QDir"
        QT_MOC_LITERAL(2507, 10),  // "destFolder"
        QT_MOC_LITERAL(2518, 8),  // "binSaved"
        QT_MOC_LITERAL(2527, 13),  // "hasAlienParts"
        QT_MOC_LITERAL(2541, 17),  // "routingStatusSlot"
        QT_MOC_LITERAL(2559, 13),  // "RoutingStatus"
        QT_MOC_LITERAL(2573, 19),  // "applyReadOnlyChange"
        QT_MOC_LITERAL(2593, 10),  // "isReadOnly"
        QT_MOC_LITERAL(2604, 16),  // "raiseAndActivate"
        QT_MOC_LITERAL(2621, 17),  // "activateWindowAux"
        QT_MOC_LITERAL(2639, 14),  // "showPartLabels"
        QT_MOC_LITERAL(2654, 7),  // "addNote"
        QT_MOC_LITERAL(2662, 9),  // "reportBug"
        QT_MOC_LITERAL(2672, 11),  // "enableDebug"
        QT_MOC_LITERAL(2684, 9),  // "tidyWires"
        QT_MOC_LITERAL(2694, 15),  // "changeWireColor"
        QT_MOC_LITERAL(2710, 7),  // "checked"
        QT_MOC_LITERAL(2718, 22),  // "startSaveInstancesSlot"
        QT_MOC_LITERAL(2741, 17),  // "QXmlStreamWriter&"
        QT_MOC_LITERAL(2759, 15),  // "loadedViewsSlot"
        QT_MOC_LITERAL(2775, 10),  // "ModelBase*"
        QT_MOC_LITERAL(2786, 12),  // "QDomElement&"
        QT_MOC_LITERAL(2799, 5),  // "views"
        QT_MOC_LITERAL(2805, 14),  // "loadedRootSlot"
        QT_MOC_LITERAL(2820, 27),  // "loadedProjectPropertiesSlot"
        QT_MOC_LITERAL(2848, 11),  // "QDomElement"
        QT_MOC_LITERAL(2860, 17),  // "projectProperties"
        QT_MOC_LITERAL(2878, 26),  // "obsoleteSMDOrientationSlot"
        QT_MOC_LITERAL(2905, 19),  // "exportNormalizedSVG"
        QT_MOC_LITERAL(2925, 28),  // "exportNormalizedFlattenedSVG"
        QT_MOC_LITERAL(2954, 12),  // "dumpAllParts"
        QT_MOC_LITERAL(2967, 14),  // "testConnectors"
        QT_MOC_LITERAL(2982, 21),  // "launchExternalProcess"
        QT_MOC_LITERAL(3004, 15),  // "externalProcess"
        QT_MOC_LITERAL(3020, 12),  // "processError"
        QT_MOC_LITERAL(3033, 22),  // "QProcess::ProcessError"
        QT_MOC_LITERAL(3056, 15),  // "processFinished"
        QT_MOC_LITERAL(3072, 8),  // "exitCode"
        QT_MOC_LITERAL(3081, 20),  // "QProcess::ExitStatus"
        QT_MOC_LITERAL(3102, 10),  // "exitStatus"
        QT_MOC_LITERAL(3113, 16),  // "processReadyRead"
        QT_MOC_LITERAL(3130, 19),  // "processStateChanged"
        QT_MOC_LITERAL(3150, 22),  // "QProcess::ProcessState"
        QT_MOC_LITERAL(3173, 8),  // "newState"
        QT_MOC_LITERAL(3182, 18),  // "throwFakeException"
        QT_MOC_LITERAL(3201, 9),  // "dropPaste"
        QT_MOC_LITERAL(3211, 17),  // "openProgramWindow"
        QT_MOC_LITERAL(3229, 17),  // "linkToProgramFile"
        QT_MOC_LITERAL(3247, 9),  // "Platform*"
        QT_MOC_LITERAL(3257, 8),  // "platform"
        QT_MOC_LITERAL(3266, 7),  // "addLink"
        QT_MOC_LITERAL(3274, 6),  // "strong"
        QT_MOC_LITERAL(3281, 19),  // "newDesignRulesCheck"
        QT_MOC_LITERAL(3301, 11),  // "subSwapSlot"
        QT_MOC_LITERAL(3313, 11),  // "newModuleID"
        QT_MOC_LITERAL(3325, 29),  // "ViewLayer::ViewLayerPlacement"
        QT_MOC_LITERAL(3355, 5),  // "long&"
        QT_MOC_LITERAL(3361, 5),  // "newID"
        QT_MOC_LITERAL(3367, 13),  // "QUndoCommand*"
        QT_MOC_LITERAL(3381, 13),  // "parentCommand"
        QT_MOC_LITERAL(3395, 19),  // "updateLayerMenuSlot"
        QT_MOC_LITERAL(3415, 4),  // "save"
        QT_MOC_LITERAL(3420, 6),  // "saveAs"
        QT_MOC_LITERAL(3427, 12),  // "backupSketch"
        QT_MOC_LITERAL(3440, 21),  // "undoStackCleanChanged"
        QT_MOC_LITERAL(3462, 7),  // "isClean"
        QT_MOC_LITERAL(3470, 14),  // "autosaveNeeded"
        QT_MOC_LITERAL(3485, 16),  // "changeTraceLayer"
        QT_MOC_LITERAL(3502, 28),  // "routingStatusLabelMousePress"
        QT_MOC_LITERAL(3531, 12),  // "QMouseEvent*"
        QT_MOC_LITERAL(3544, 30),  // "routingStatusLabelMouseRelease"
        QT_MOC_LITERAL(3575, 14),  // "selectMoveLock"
        QT_MOC_LITERAL(3590, 8),  // "moveLock"
        QT_MOC_LITERAL(3599, 9),  // "setSticky"
        QT_MOC_LITERAL(3609, 18),  // "autorouterSettings"
        QT_MOC_LITERAL(3628, 16),  // "boardDeletedSlot"
        QT_MOC_LITERAL(3645, 18),  // "cursorLocationSlot"
        QT_MOC_LITERAL(3664, 20),  // "locationLabelClicked"
        QT_MOC_LITERAL(3685, 15),  // "swapSelectedMap"
        QT_MOC_LITERAL(3701, 6),  // "family"
        QT_MOC_LITERAL(3708, 4),  // "prop"
        QT_MOC_LITERAL(3713, 22),  // "QMap<QString,QString>&"
        QT_MOC_LITERAL(3736, 12),  // "currPropsMap"
        QT_MOC_LITERAL(3749, 14),  // "filenameIfSlot"
        QT_MOC_LITERAL(3764, 7),  // "openURL"
        QT_MOC_LITERAL(3772, 13),  // "setActiveWire"
        QT_MOC_LITERAL(3786, 5),  // "Wire*"
        QT_MOC_LITERAL(3792, 22),  // "setActiveConnectorItem"
        QT_MOC_LITERAL(3815, 14),  // "ConnectorItem*"
        QT_MOC_LITERAL(3830, 9),  // "gridUnits"
        QT_MOC_LITERAL(3840, 18),  // "restoreDefaultGrid"
        QT_MOC_LITERAL(3859, 17),  // "checkLoadedTraces"
        QT_MOC_LITERAL(3877, 11),  // "keepMargins"
        QT_MOC_LITERAL(3889, 20),  // "dockChangeActivation"
        QT_MOC_LITERAL(3910, 12),  // "addToMyParts"
        QT_MOC_LITERAL(3923, 18),  // "hidePartSilkscreen"
        QT_MOC_LITERAL(3942, 8),  // "fabQuote"
        QT_MOC_LITERAL(3951, 16),  // "findPartInSketch"
        QT_MOC_LITERAL(3968, 9),  // "fireQuote"
        QT_MOC_LITERAL(3978, 22),  // "setViewFromBelowToggle"
        QT_MOC_LITERAL(4001, 16),  // "setViewFromBelow"
        QT_MOC_LITERAL(4018, 16),  // "setViewFromAbove"
        QT_MOC_LITERAL(4035, 27),  // "updateWelcomeViewRecentList"
        QT_MOC_LITERAL(4063, 8),  // "initZoom"
        QT_MOC_LITERAL(4072, 21)   // "onShareOnlineFinished"
    },
    "MainWindow",
    "alienPartsDismissed",
    "",
    "mainWindowMoved",
    "QWidget*",
    "changeActivationSignal",
    "activate",
    "originator",
    "externalProcessSignal",
    "QString&",
    "name",
    "path",
    "QStringList&",
    "args",
    "ensureClosable",
    "loadBundledPart",
    "QList<ModelPart*>",
    "fileName",
    "addToBin",
    "loadPart",
    "acceptAlienFiles",
    "statusMessage",
    "message",
    "timeout",
    "showPCBView",
    "groundFill",
    "groundFillOld",
    "removeGroundFill",
    "copperFill",
    "copperFillOld",
    "setOneGroundFillSeed",
    "setGroundFillSeeds",
    "clearGroundFillSeeds",
    "changeBoardLayers",
    "layers",
    "doEmit",
    "selectAllObsolete",
    "swapObsolete",
    "swapBoardImageSlot",
    "SketchWidget*",
    "sketchWidget",
    "ItemBase*",
    "itemBase",
    "filename",
    "moduleID",
    "addName",
    "updateTraceMenu",
    "updateExportMenu",
    "updateFileMenu",
    "showStatusMessage",
    "orderFabHoverEnter",
    "orderFabHoverLeave",
    "setGroundFillKeepout",
    "oldSchematicsSlot",
    "bool&",
    "useOldSchematics",
    "showWelcomeView",
    "putItemByModuleID",
    "postKeyEvent",
    "serializedKeys",
    "mainLoad",
    "revert",
    "openRecentOrExampleFile",
    "actionText",
    "print",
    "doExport",
    "exportEtchable",
    "about",
    "tipsAndTricks",
    "firstTimeHelp",
    "copy",
    "cut",
    "paste",
    "pasteInPlace",
    "duplicate",
    "doDelete",
    "doDeleteMinus",
    "selectAll",
    "deselect",
    "zoomIn",
    "zoomOut",
    "fitInWindow",
    "actualSize",
    "hundredPercentSize",
    "alignToGrid",
    "showGrid",
    "setGridSize",
    "setBackgroundColor",
    "colorWiresByLength",
    "showBreadboardView",
    "showSchematicView",
    "showProgramView",
    "showPartsBinIconView",
    "showPartsBinListView",
    "updateEditMenu",
    "updateLayerMenu",
    "resetLayout",
    "updatePartMenu",
    "updateWireMenu",
    "updateTransformationActions",
    "updateRecentFileActions",
    "tabWidget_currentChanged",
    "index",
    "createNewSketch",
    "minimize",
    "toggleToolbar",
    "toggle",
    "togglePartLibrary",
    "toggleInfo",
    "toggleUndoHistory",
    "toggleDebuggerOutput",
    "openHelp",
    "openExamples",
    "openPartsReference",
    "visitFritzingDotOrg",
    "partsEditorHelp",
    "updateWindowMenu",
    "pageSetup",
    "sendToBack",
    "sendBackward",
    "bringForward",
    "bringToFront",
    "alignLeft",
    "alignRight",
    "alignVerticalCenter",
    "alignTop",
    "alignHorizontalCenter",
    "alignBottom",
    "rotate90cw",
    "rotate90ccw",
    "rotate180",
    "rotate45ccw",
    "rotate45cw",
    "rotateIncCCW",
    "rotateIncCW",
    "rotateIncCCWRubberBand",
    "rotateIncCWRubberBand",
    "flipHorizontal",
    "flipVertical",
    "showAllLayers",
    "hideAllLayers",
    "addBendpoint",
    "convertToVia",
    "convertToBendpoint",
    "flattenCurve",
    "disconnectAll",
    "openInPartsEditorNew",
    "openNewPartsEditor",
    "PaletteItem*",
    "updateZoomSlider",
    "zoom",
    "updateZoomOptionsNoMatterWhat",
    "updateViewZoom",
    "newZoom",
    "setInfoViewOnHover",
    "infoViewOnHover",
    "updateItemMenu",
    "newAutoroute",
    "orderFab",
    "activeLayerTop",
    "activeLayerBottom",
    "activeLayerBoth",
    "toggleActiveLayer",
    "createTrace",
    "excludeFromAutoroute",
    "selectAllTraces",
    "showUnrouted",
    "selectAllCopperFill",
    "updateRoutingStatus",
    "selectAllExcludedTraces",
    "selectAllIncludedTraces",
    "selectAllJumperItems",
    "selectAllVias",
    "shareOnline",
    "saveBundledPart",
    "moduleId",
    "saveBundledAux",
    "ModelPart*",
    "mp",
    "QDir",
    "destFolder",
    "binSaved",
    "hasAlienParts",
    "routingStatusSlot",
    "RoutingStatus",
    "applyReadOnlyChange",
    "isReadOnly",
    "raiseAndActivate",
    "activateWindowAux",
    "showPartLabels",
    "addNote",
    "reportBug",
    "enableDebug",
    "tidyWires",
    "changeWireColor",
    "checked",
    "startSaveInstancesSlot",
    "QXmlStreamWriter&",
    "loadedViewsSlot",
    "ModelBase*",
    "QDomElement&",
    "views",
    "loadedRootSlot",
    "loadedProjectPropertiesSlot",
    "QDomElement",
    "projectProperties",
    "obsoleteSMDOrientationSlot",
    "exportNormalizedSVG",
    "exportNormalizedFlattenedSVG",
    "dumpAllParts",
    "testConnectors",
    "launchExternalProcess",
    "externalProcess",
    "processError",
    "QProcess::ProcessError",
    "processFinished",
    "exitCode",
    "QProcess::ExitStatus",
    "exitStatus",
    "processReadyRead",
    "processStateChanged",
    "QProcess::ProcessState",
    "newState",
    "throwFakeException",
    "dropPaste",
    "openProgramWindow",
    "linkToProgramFile",
    "Platform*",
    "platform",
    "addLink",
    "strong",
    "newDesignRulesCheck",
    "subSwapSlot",
    "newModuleID",
    "ViewLayer::ViewLayerPlacement",
    "long&",
    "newID",
    "QUndoCommand*",
    "parentCommand",
    "updateLayerMenuSlot",
    "save",
    "saveAs",
    "backupSketch",
    "undoStackCleanChanged",
    "isClean",
    "autosaveNeeded",
    "changeTraceLayer",
    "routingStatusLabelMousePress",
    "QMouseEvent*",
    "routingStatusLabelMouseRelease",
    "selectMoveLock",
    "moveLock",
    "setSticky",
    "autorouterSettings",
    "boardDeletedSlot",
    "cursorLocationSlot",
    "locationLabelClicked",
    "swapSelectedMap",
    "family",
    "prop",
    "QMap<QString,QString>&",
    "currPropsMap",
    "filenameIfSlot",
    "openURL",
    "setActiveWire",
    "Wire*",
    "setActiveConnectorItem",
    "ConnectorItem*",
    "gridUnits",
    "restoreDefaultGrid",
    "checkLoadedTraces",
    "keepMargins",
    "dockChangeActivation",
    "addToMyParts",
    "hidePartSilkscreen",
    "fabQuote",
    "findPartInSketch",
    "fireQuote",
    "setViewFromBelowToggle",
    "setViewFromBelow",
    "setViewFromAbove",
    "updateWelcomeViewRecentList",
    "initZoom",
    "onShareOnlineFinished"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
     217,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0, 1316,    2, 0x06,    1 /* Public */,
       3,    1, 1317,    2, 0x06,    2 /* Public */,
       5,    2, 1320,    2, 0x06,    4 /* Public */,
       8,    3, 1325,    2, 0x06,    7 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      14,    0, 1332,    2, 0x0a,   11 /* Public */,
      15,    2, 1333,    2, 0x0a,   12 /* Public */,
      19,    2, 1338,    2, 0x0a,   15 /* Public */,
      20,    0, 1343,    2, 0x0a,   18 /* Public */,
      21,    2, 1344,    2, 0x0a,   19 /* Public */,
      24,    0, 1349,    2, 0x0a,   22 /* Public */,
      25,    0, 1350,    2, 0x0a,   23 /* Public */,
      26,    0, 1351,    2, 0x0a,   24 /* Public */,
      27,    0, 1352,    2, 0x0a,   25 /* Public */,
      28,    0, 1353,    2, 0x0a,   26 /* Public */,
      29,    0, 1354,    2, 0x0a,   27 /* Public */,
      30,    0, 1355,    2, 0x0a,   28 /* Public */,
      31,    0, 1356,    2, 0x0a,   29 /* Public */,
      32,    0, 1357,    2, 0x0a,   30 /* Public */,
      33,    2, 1358,    2, 0x0a,   31 /* Public */,
      36,    0, 1363,    2, 0x0a,   34 /* Public */,
      37,    0, 1364,    2, 0x0a,   35 /* Public */,
      38,    5, 1365,    2, 0x0a,   36 /* Public */,
      46,    0, 1376,    2, 0x0a,   42 /* Public */,
      47,    0, 1377,    2, 0x0a,   43 /* Public */,
      48,    0, 1378,    2, 0x0a,   44 /* Public */,
      49,    1, 1379,    2, 0x0a,   45 /* Public */,
      50,    0, 1382,    2, 0x0a,   47 /* Public */,
      51,    0, 1383,    2, 0x0a,   48 /* Public */,
      52,    0, 1384,    2, 0x0a,   49 /* Public */,
      53,    2, 1385,    2, 0x0a,   50 /* Public */,
      56,    0, 1390,    2, 0x0a,   53 /* Public */,
      57,    1, 1391,    2, 0x0a,   54 /* Public */,
      58,    1, 1394,    2, 0x0a,   56 /* Public */,
      60,    0, 1397,    2, 0x09,   58 /* Protected */,
      61,    0, 1398,    2, 0x09,   59 /* Protected */,
      62,    0, 1399,    2, 0x09,   60 /* Protected */,
      62,    2, 1400,    2, 0x09,   61 /* Protected */,
      64,    0, 1405,    2, 0x09,   64 /* Protected */,
      65,    0, 1406,    2, 0x09,   65 /* Protected */,
      66,    0, 1407,    2, 0x09,   66 /* Protected */,
      67,    0, 1408,    2, 0x09,   67 /* Protected */,
      68,    0, 1409,    2, 0x09,   68 /* Protected */,
      69,    0, 1410,    2, 0x09,   69 /* Protected */,
      70,    0, 1411,    2, 0x09,   70 /* Protected */,
      71,    0, 1412,    2, 0x09,   71 /* Protected */,
      72,    0, 1413,    2, 0x09,   72 /* Protected */,
      73,    0, 1414,    2, 0x09,   73 /* Protected */,
      74,    0, 1415,    2, 0x09,   74 /* Protected */,
      75,    0, 1416,    2, 0x09,   75 /* Protected */,
      76,    0, 1417,    2, 0x09,   76 /* Protected */,
      77,    0, 1418,    2, 0x09,   77 /* Protected */,
      78,    0, 1419,    2, 0x09,   78 /* Protected */,
      79,    0, 1420,    2, 0x09,   79 /* Protected */,
      80,    0, 1421,    2, 0x09,   80 /* Protected */,
      81,    0, 1422,    2, 0x09,   81 /* Protected */,
      82,    0, 1423,    2, 0x09,   82 /* Protected */,
      83,    0, 1424,    2, 0x09,   83 /* Protected */,
      84,    0, 1425,    2, 0x09,   84 /* Protected */,
      85,    0, 1426,    2, 0x09,   85 /* Protected */,
      86,    0, 1427,    2, 0x09,   86 /* Protected */,
      87,    0, 1428,    2, 0x09,   87 /* Protected */,
      88,    0, 1429,    2, 0x09,   88 /* Protected */,
      89,    0, 1430,    2, 0x09,   89 /* Protected */,
      90,    0, 1431,    2, 0x09,   90 /* Protected */,
      91,    0, 1432,    2, 0x09,   91 /* Protected */,
      92,    0, 1433,    2, 0x09,   92 /* Protected */,
      93,    0, 1434,    2, 0x09,   93 /* Protected */,
      94,    0, 1435,    2, 0x09,   94 /* Protected */,
      95,    1, 1436,    2, 0x09,   95 /* Protected */,
      95,    0, 1439,    2, 0x29,   97 /* Protected | MethodCloned */,
      97,    0, 1440,    2, 0x09,   98 /* Protected */,
      98,    0, 1441,    2, 0x09,   99 /* Protected */,
      99,    0, 1442,    2, 0x09,  100 /* Protected */,
     100,    0, 1443,    2, 0x09,  101 /* Protected */,
     101,    1, 1444,    2, 0x09,  102 /* Protected */,
     103,    0, 1447,    2, 0x09,  104 /* Protected */,
     104,    0, 1448,    2, 0x09,  105 /* Protected */,
     105,    1, 1449,    2, 0x09,  106 /* Protected */,
     107,    1, 1452,    2, 0x09,  108 /* Protected */,
     108,    1, 1455,    2, 0x09,  110 /* Protected */,
     109,    1, 1458,    2, 0x09,  112 /* Protected */,
     110,    1, 1461,    2, 0x09,  114 /* Protected */,
     111,    0, 1464,    2, 0x09,  116 /* Protected */,
     112,    0, 1465,    2, 0x09,  117 /* Protected */,
     113,    0, 1466,    2, 0x09,  118 /* Protected */,
     114,    0, 1467,    2, 0x09,  119 /* Protected */,
     115,    0, 1468,    2, 0x09,  120 /* Protected */,
     116,    0, 1469,    2, 0x09,  121 /* Protected */,
     117,    0, 1470,    2, 0x09,  122 /* Protected */,
     118,    0, 1471,    2, 0x09,  123 /* Protected */,
     119,    0, 1472,    2, 0x09,  124 /* Protected */,
     120,    0, 1473,    2, 0x09,  125 /* Protected */,
     121,    0, 1474,    2, 0x09,  126 /* Protected */,
     122,    0, 1475,    2, 0x09,  127 /* Protected */,
     123,    0, 1476,    2, 0x09,  128 /* Protected */,
     124,    0, 1477,    2, 0x09,  129 /* Protected */,
     125,    0, 1478,    2, 0x09,  130 /* Protected */,
     126,    0, 1479,    2, 0x09,  131 /* Protected */,
     127,    0, 1480,    2, 0x09,  132 /* Protected */,
     128,    0, 1481,    2, 0x09,  133 /* Protected */,
     129,    0, 1482,    2, 0x09,  134 /* Protected */,
     130,    0, 1483,    2, 0x09,  135 /* Protected */,
     131,    0, 1484,    2, 0x09,  136 /* Protected */,
     132,    0, 1485,    2, 0x09,  137 /* Protected */,
     133,    0, 1486,    2, 0x09,  138 /* Protected */,
     134,    0, 1487,    2, 0x09,  139 /* Protected */,
     135,    0, 1488,    2, 0x09,  140 /* Protected */,
     136,    0, 1489,    2, 0x09,  141 /* Protected */,
     137,    0, 1490,    2, 0x09,  142 /* Protected */,
     138,    0, 1491,    2, 0x09,  143 /* Protected */,
     139,    0, 1492,    2, 0x09,  144 /* Protected */,
     140,    0, 1493,    2, 0x09,  145 /* Protected */,
     141,    0, 1494,    2, 0x09,  146 /* Protected */,
     142,    0, 1495,    2, 0x09,  147 /* Protected */,
     143,    0, 1496,    2, 0x09,  148 /* Protected */,
     144,    0, 1497,    2, 0x09,  149 /* Protected */,
     145,    0, 1498,    2, 0x09,  150 /* Protected */,
     146,    0, 1499,    2, 0x09,  151 /* Protected */,
     147,    1, 1500,    2, 0x09,  152 /* Protected */,
     149,    1, 1503,    2, 0x09,  154 /* Protected */,
     151,    1, 1506,    2, 0x09,  156 /* Protected */,
     152,    1, 1509,    2, 0x09,  158 /* Protected */,
     154,    1, 1512,    2, 0x09,  160 /* Protected */,
     156,    0, 1515,    2, 0x09,  162 /* Protected */,
     157,    0, 1516,    2, 0x09,  163 /* Protected */,
     158,    0, 1517,    2, 0x09,  164 /* Protected */,
     159,    0, 1518,    2, 0x09,  165 /* Protected */,
     160,    0, 1519,    2, 0x09,  166 /* Protected */,
     161,    0, 1520,    2, 0x09,  167 /* Protected */,
     162,    0, 1521,    2, 0x09,  168 /* Protected */,
     163,    0, 1522,    2, 0x09,  169 /* Protected */,
     164,    0, 1523,    2, 0x09,  170 /* Protected */,
     165,    0, 1524,    2, 0x09,  171 /* Protected */,
     166,    0, 1525,    2, 0x09,  172 /* Protected */,
     167,    0, 1526,    2, 0x09,  173 /* Protected */,
     168,    0, 1527,    2, 0x09,  174 /* Protected */,
     169,    0, 1528,    2, 0x09,  175 /* Protected */,
     170,    0, 1529,    2, 0x09,  176 /* Protected */,
     171,    0, 1530,    2, 0x09,  177 /* Protected */,
     172,    0, 1531,    2, 0x09,  178 /* Protected */,
     173,    0, 1532,    2, 0x09,  179 /* Protected */,
     174,    1, 1533,    2, 0x09,  180 /* Protected */,
     174,    0, 1536,    2, 0x29,  182 /* Protected | MethodCloned */,
     176,    2, 1537,    2, 0x09,  183 /* Protected */,
     181,    1, 1542,    2, 0x09,  186 /* Protected */,
     183,    2, 1545,    2, 0x09,  188 /* Protected */,
     185,    1, 1550,    2, 0x09,  191 /* Protected */,
     187,    0, 1553,    2, 0x09,  193 /* Protected */,
     188,    0, 1554,    2, 0x09,  194 /* Protected */,
     189,    0, 1555,    2, 0x09,  195 /* Protected */,
     190,    0, 1556,    2, 0x09,  196 /* Protected */,
     191,    0, 1557,    2, 0x09,  197 /* Protected */,
     192,    0, 1558,    2, 0x09,  198 /* Protected */,
     193,    0, 1559,    2, 0x09,  199 /* Protected */,
     194,    1, 1560,    2, 0x09,  200 /* Protected */,
     196,    3, 1563,    2, 0x09,  202 /* Protected */,
     198,    2, 1570,    2, 0x09,  206 /* Protected */,
     202,    3, 1575,    2, 0x09,  209 /* Protected */,
     203,    1, 1582,    2, 0x09,  213 /* Protected */,
     206,    0, 1585,    2, 0x09,  215 /* Protected */,
     207,    0, 1586,    2, 0x09,  216 /* Protected */,
     208,    0, 1587,    2, 0x09,  217 /* Protected */,
     209,    0, 1588,    2, 0x09,  218 /* Protected */,
     210,    0, 1589,    2, 0x09,  219 /* Protected */,
     211,    0, 1590,    2, 0x09,  220 /* Protected */,
     212,    3, 1591,    2, 0x09,  221 /* Protected */,
     213,    1, 1598,    2, 0x09,  225 /* Protected */,
     215,    2, 1601,    2, 0x09,  227 /* Protected */,
     219,    0, 1606,    2, 0x09,  230 /* Protected */,
     220,    1, 1607,    2, 0x09,  231 /* Protected */,
     223,    0, 1610,    2, 0x09,  233 /* Protected */,
     224,    1, 1611,    2, 0x09,  234 /* Protected */,
     225,    0, 1614,    2, 0x09,  236 /* Protected */,
     226,    4, 1615,    2, 0x09,  237 /* Protected */,
     231,    0, 1624,    2, 0x09,  242 /* Protected */,
     232,    6, 1625,    2, 0x09,  243 /* Protected */,
     239,    0, 1638,    2, 0x09,  250 /* Protected */,
     240,    0, 1639,    2, 0x09,  251 /* Protected */,
     241,    0, 1640,    2, 0x09,  252 /* Protected */,
     242,    0, 1641,    2, 0x09,  253 /* Protected */,
     243,    1, 1642,    2, 0x09,  254 /* Protected */,
     245,    1, 1645,    2, 0x09,  256 /* Protected */,
     245,    0, 1648,    2, 0x29,  258 /* Protected | MethodCloned */,
     246,    0, 1649,    2, 0x09,  259 /* Protected */,
     247,    1, 1650,    2, 0x09,  260 /* Protected */,
     249,    1, 1653,    2, 0x09,  262 /* Protected */,
     250,    0, 1656,    2, 0x09,  264 /* Protected */,
     251,    0, 1657,    2, 0x09,  265 /* Protected */,
     252,    0, 1658,    2, 0x09,  266 /* Protected */,
     253,    0, 1659,    2, 0x09,  267 /* Protected */,
     254,    0, 1660,    2, 0x09,  268 /* Protected */,
     255,    4, 1661,    2, 0x09,  269 /* Protected */,
     255,    3, 1670,    2, 0x29,  274 /* Protected | MethodCloned */,
     255,    2, 1677,    2, 0x29,  278 /* Protected | MethodCloned */,
     256,    0, 1682,    2, 0x09,  281 /* Protected */,
     257,    4, 1683,    2, 0x09,  282 /* Protected */,
     262,    1, 1692,    2, 0x09,  287 /* Protected */,
     263,    0, 1695,    2, 0x09,  289 /* Protected */,
     264,    1, 1696,    2, 0x09,  290 /* Protected */,
     266,    1, 1699,    2, 0x09,  292 /* Protected */,
     268,    1, 1702,    2, 0x09,  294 /* Protected */,
     269,    0, 1705,    2, 0x09,  296 /* Protected */,
     270,    0, 1706,    2, 0x09,  297 /* Protected */,
     271,    0, 1707,    2, 0x09,  298 /* Protected */,
     272,    2, 1708,    2, 0x09,  299 /* Protected */,
     273,    2, 1713,    2, 0x09,  302 /* Protected */,
     274,    0, 1718,    2, 0x09,  305 /* Protected */,
     275,    0, 1719,    2, 0x09,  306 /* Protected */,
     276,    0, 1720,    2, 0x09,  307 /* Protected */,
     277,    0, 1721,    2, 0x09,  308 /* Protected */,
     278,    0, 1722,    2, 0x09,  309 /* Protected */,
     279,    0, 1723,    2, 0x09,  310 /* Protected */,
     280,    0, 1724,    2, 0x09,  311 /* Protected */,
     281,    1, 1725,    2, 0x09,  312 /* Protected */,
     281,    0, 1728,    2, 0x29,  314 /* Protected | MethodCloned */,
     282,    0, 1729,    2, 0x09,  315 /* Protected */,
     283,    0, 1730,    2, 0x09,  316 /* Protected */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    2,
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 4,    6,    7,
    QMetaType::Void, 0x80000000 | 9, 0x80000000 | 9, 0x80000000 | 12,   10,   11,   13,

 // slots: parameters
    QMetaType::Void,
    0x80000000 | 16, QMetaType::QString, QMetaType::Bool,   17,   18,
    0x80000000 | 16, QMetaType::QString, QMetaType::Bool,   17,   18,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   22,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,   34,   35,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 39, 0x80000000 | 41, QMetaType::QString, QMetaType::QString, QMetaType::Bool,   40,   42,   43,   44,   45,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 54,   43,   55,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   44,
    QMetaType::Void, QMetaType::QString,   59,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   43,   63,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   96,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,  102,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,  106,
    QMetaType::Void, QMetaType::Bool,  106,
    QMetaType::Void, QMetaType::Bool,  106,
    QMetaType::Void, QMetaType::Bool,  106,
    QMetaType::Void, QMetaType::Bool,  106,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 148,    2,
    QMetaType::Void, QMetaType::Double,  150,
    QMetaType::Void, QMetaType::Double,  150,
    QMetaType::Void, QMetaType::Double,  153,
    QMetaType::Void, QMetaType::Bool,  155,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,  175,
    QMetaType::Void,
    QMetaType::QStringList, 0x80000000 | 177, 0x80000000 | 179,  178,  180,
    QMetaType::Void, QMetaType::Bool,  182,
    QMetaType::Void, 0x80000000 | 39, 0x80000000 | 184,    2,    2,
    QMetaType::Void, QMetaType::Bool,  186,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,  195,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 177, 0x80000000 | 197,   17,    2,    2,
    QMetaType::Void, 0x80000000 | 199, 0x80000000 | 200,    2,  201,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 199, 0x80000000 | 200,   43,    2,  201,
    QMetaType::Void, 0x80000000 | 204,  205,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool, 0x80000000 | 9, 0x80000000 | 9, 0x80000000 | 12,   10,   11,   13,
    QMetaType::Void, 0x80000000 | 214,  213,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 217,  216,  218,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 221,  222,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 39,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 227, QMetaType::Bool, QMetaType::Bool,   43,  228,  229,  230,
    QMetaType::QStringList,
    QMetaType::Void, 0x80000000 | 39, 0x80000000 | 41, QMetaType::QString, 0x80000000 | 234, 0x80000000 | 235, 0x80000000 | 237,    2,    2,  233,    2,  236,  238,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,  244,
    QMetaType::Void, QMetaType::Int,  102,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 248,    2,
    QMetaType::Void, 0x80000000 | 248,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double,    2,    2,    2,    2,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,    2,    2,    2,
    QMetaType::Void, QMetaType::Double, QMetaType::Double,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, 0x80000000 | 260, 0x80000000 | 41,  258,  259,  261,    2,
    QMetaType::Void, 0x80000000 | 9,   43,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 265,    2,
    QMetaType::Void, 0x80000000 | 267,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 4,    6,    7,
    QMetaType::Void, 0x80000000 | 177, QMetaType::QStringList,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   35,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<FritzingWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'alienPartsDismissed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'mainWindowMoved'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QWidget *, std::false_type>,
        // method 'changeActivationSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QWidget *, std::false_type>,
        // method 'externalProcessSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStringList &, std::false_type>,
        // method 'ensureClosable'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loadBundledPart'
        QtPrivate::TypeAndForceComplete<QList<ModelPart*>, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'loadPart'
        QtPrivate::TypeAndForceComplete<QList<ModelPart*>, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'acceptAlienFiles'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'statusMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'showPCBView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'groundFill'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'groundFillOld'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'removeGroundFill'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copperFill'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copperFillOld'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setOneGroundFillSeed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setGroundFillSeeds'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clearGroundFillSeeds'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'changeBoardLayers'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'selectAllObsolete'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'swapObsolete'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'swapBoardImageSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'updateTraceMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateExportMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateFileMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showStatusMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'orderFabHoverEnter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'orderFabHoverLeave'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setGroundFillKeepout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'oldSchematicsSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool &, std::false_type>,
        // method 'showWelcomeView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'putItemByModuleID'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'postKeyEvent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'mainLoad'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'revert'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openRecentOrExampleFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openRecentOrExampleFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'print'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'doExport'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exportEtchable'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'about'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tipsAndTricks'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'firstTimeHelp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copy'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'paste'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'pasteInPlace'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'duplicate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'doDelete'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'doDeleteMinus'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectAll'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'deselect'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'zoomIn'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'zoomOut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'fitInWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'actualSize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'hundredPercentSize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'alignToGrid'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showGrid'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setGridSize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setBackgroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'colorWiresByLength'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showBreadboardView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showSchematicView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showProgramView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showPartsBinIconView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showPartsBinListView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateEditMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateLayerMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'updateLayerMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updatePartMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateWireMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateTransformationActions'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateRecentFileActions'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tabWidget_currentChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'createNewSketch'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'minimize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toggleToolbar'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'togglePartLibrary'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'toggleInfo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'toggleUndoHistory'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'toggleDebuggerOutput'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'openHelp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openExamples'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openPartsReference'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'visitFritzingDotOrg'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'partsEditorHelp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateWindowMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'pageSetup'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sendToBack'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sendBackward'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'bringForward'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'bringToFront'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'alignLeft'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'alignRight'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'alignVerticalCenter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'alignTop'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'alignHorizontalCenter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'alignBottom'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotate90cw'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotate90ccw'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotate180'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotate45ccw'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotate45cw'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotateIncCCW'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotateIncCW'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotateIncCCWRubberBand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rotateIncCWRubberBand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'flipHorizontal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'flipVertical'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showAllLayers'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'hideAllLayers'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'addBendpoint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'convertToVia'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'convertToBendpoint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'flattenCurve'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'disconnectAll'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openInPartsEditorNew'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openNewPartsEditor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PaletteItem *, std::false_type>,
        // method 'updateZoomSlider'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'updateZoomOptionsNoMatterWhat'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'updateViewZoom'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'setInfoViewOnHover'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'updateItemMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'newAutoroute'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'orderFab'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'activeLayerTop'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'activeLayerBottom'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'activeLayerBoth'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toggleActiveLayer'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'createTrace'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'excludeFromAutoroute'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectAllTraces'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showUnrouted'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectAllCopperFill'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateRoutingStatus'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectAllExcludedTraces'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectAllIncludedTraces'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectAllJumperItems'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectAllVias'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'shareOnline'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveBundledPart'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'saveBundledPart'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveBundledAux'
        QtPrivate::TypeAndForceComplete<QStringList, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QDir &, std::false_type>,
        // method 'binSaved'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'routingStatusSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const RoutingStatus &, std::false_type>,
        // method 'applyReadOnlyChange'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'raiseAndActivate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'activateWindowAux'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showPartLabels'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'addNote'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'reportBug'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'enableDebug'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tidyWires'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'changeWireColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'startSaveInstancesSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QXmlStreamWriter &, std::false_type>,
        // method 'loadedViewsSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDomElement &, std::false_type>,
        // method 'loadedRootSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDomElement &, std::false_type>,
        // method 'loadedProjectPropertiesSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QDomElement &, std::false_type>,
        // method 'obsoleteSMDOrientationSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exportNormalizedSVG'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exportNormalizedFlattenedSVG'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dumpAllParts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'testConnectors'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'launchExternalProcess'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'externalProcess'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStringList &, std::false_type>,
        // method 'processError'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QProcess::ProcessError, std::false_type>,
        // method 'processFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<QProcess::ExitStatus, std::false_type>,
        // method 'processReadyRead'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'processStateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QProcess::ProcessState, std::false_type>,
        // method 'throwFakeException'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dropPaste'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        // method 'openProgramWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'linkToProgramFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<Platform *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'newDesignRulesCheck'
        QtPrivate::TypeAndForceComplete<QStringList, std::false_type>,
        // method 'subSwapSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement, std::false_type>,
        QtPrivate::TypeAndForceComplete<long &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'updateLayerMenuSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'save'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'saveAs'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'backupSketch'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'undoStackCleanChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'autosaveNeeded'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'autosaveNeeded'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'changeTraceLayer'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'routingStatusLabelMousePress'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QMouseEvent *, std::false_type>,
        // method 'routingStatusLabelMouseRelease'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QMouseEvent *, std::false_type>,
        // method 'selectMoveLock'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'moveLock'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setSticky'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'autorouterSettings'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'boardDeletedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cursorLocationSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'cursorLocationSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'cursorLocationSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'locationLabelClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'swapSelectedMap'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QMap<QString,QString> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        // method 'filenameIfSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        // method 'openURL'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setActiveWire'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        // method 'setActiveConnectorItem'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        // method 'gridUnits'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'restoreDefaultGrid'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'checkLoadedTraces'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'keepMargins'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dockChangeActivation'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QWidget *, std::false_type>,
        // method 'addToMyParts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QStringList &, std::false_type>,
        // method 'hidePartSilkscreen'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'fabQuote'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'findPartInSketch'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'fireQuote'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setViewFromBelowToggle'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setViewFromBelow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setViewFromAbove'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateWelcomeViewRecentList'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'updateWelcomeViewRecentList'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'initZoom'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onShareOnlineFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->alienPartsDismissed(); break;
        case 1: _t->mainWindowMoved((*reinterpret_cast< std::add_pointer_t<QWidget*>>(_a[1]))); break;
        case 2: _t->changeActivationSignal((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QWidget*>>(_a[2]))); break;
        case 3: _t->externalProcessSignal((*reinterpret_cast< std::add_pointer_t<QString&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QStringList&>>(_a[3]))); break;
        case 4: _t->ensureClosable(); break;
        case 5: { QList<ModelPart*> _r = _t->loadBundledPart((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])));
            if (_a[0]) *reinterpret_cast< QList<ModelPart*>*>(_a[0]) = std::move(_r); }  break;
        case 6: { QList<ModelPart*> _r = _t->loadPart((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])));
            if (_a[0]) *reinterpret_cast< QList<ModelPart*>*>(_a[0]) = std::move(_r); }  break;
        case 7: _t->acceptAlienFiles(); break;
        case 8: _t->statusMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 9: _t->showPCBView(); break;
        case 10: _t->groundFill(); break;
        case 11: _t->groundFillOld(); break;
        case 12: _t->removeGroundFill(); break;
        case 13: _t->copperFill(); break;
        case 14: _t->copperFillOld(); break;
        case 15: _t->setOneGroundFillSeed(); break;
        case 16: _t->setGroundFillSeeds(); break;
        case 17: _t->clearGroundFillSeeds(); break;
        case 18: _t->changeBoardLayers((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 19: _t->selectAllObsolete(); break;
        case 20: _t->swapObsolete(); break;
        case 21: _t->swapBoardImageSlot((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5]))); break;
        case 22: _t->updateTraceMenu(); break;
        case 23: _t->updateExportMenu(); break;
        case 24: _t->updateFileMenu(); break;
        case 25: _t->showStatusMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 26: _t->orderFabHoverEnter(); break;
        case 27: _t->orderFabHoverLeave(); break;
        case 28: _t->setGroundFillKeepout(); break;
        case 29: _t->oldSchematicsSlot((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool&>>(_a[2]))); break;
        case 30: _t->showWelcomeView(); break;
        case 31: _t->putItemByModuleID((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 32: _t->postKeyEvent((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 33: _t->mainLoad(); break;
        case 34: _t->revert(); break;
        case 35: _t->openRecentOrExampleFile(); break;
        case 36: _t->openRecentOrExampleFile((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 37: _t->print(); break;
        case 38: _t->doExport(); break;
        case 39: _t->exportEtchable(); break;
        case 40: _t->about(); break;
        case 41: _t->tipsAndTricks(); break;
        case 42: _t->firstTimeHelp(); break;
        case 43: _t->copy(); break;
        case 44: _t->cut(); break;
        case 45: _t->paste(); break;
        case 46: _t->pasteInPlace(); break;
        case 47: _t->duplicate(); break;
        case 48: _t->doDelete(); break;
        case 49: _t->doDeleteMinus(); break;
        case 50: _t->selectAll(); break;
        case 51: _t->deselect(); break;
        case 52: _t->zoomIn(); break;
        case 53: _t->zoomOut(); break;
        case 54: _t->fitInWindow(); break;
        case 55: _t->actualSize(); break;
        case 56: _t->hundredPercentSize(); break;
        case 57: _t->alignToGrid(); break;
        case 58: _t->showGrid(); break;
        case 59: _t->setGridSize(); break;
        case 60: _t->setBackgroundColor(); break;
        case 61: _t->colorWiresByLength(); break;
        case 62: _t->showBreadboardView(); break;
        case 63: _t->showSchematicView(); break;
        case 64: _t->showProgramView(); break;
        case 65: _t->showPartsBinIconView(); break;
        case 66: _t->showPartsBinListView(); break;
        case 67: _t->updateEditMenu(); break;
        case 68: _t->updateLayerMenu((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 69: _t->updateLayerMenu(); break;
        case 70: _t->updatePartMenu(); break;
        case 71: _t->updateWireMenu(); break;
        case 72: _t->updateTransformationActions(); break;
        case 73: _t->updateRecentFileActions(); break;
        case 74: _t->tabWidget_currentChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 75: _t->createNewSketch(); break;
        case 76: _t->minimize(); break;
        case 77: _t->toggleToolbar((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 78: _t->togglePartLibrary((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 79: _t->toggleInfo((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 80: _t->toggleUndoHistory((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 81: _t->toggleDebuggerOutput((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 82: _t->openHelp(); break;
        case 83: _t->openExamples(); break;
        case 84: _t->openPartsReference(); break;
        case 85: _t->visitFritzingDotOrg(); break;
        case 86: _t->partsEditorHelp(); break;
        case 87: _t->updateWindowMenu(); break;
        case 88: _t->pageSetup(); break;
        case 89: _t->sendToBack(); break;
        case 90: _t->sendBackward(); break;
        case 91: _t->bringForward(); break;
        case 92: _t->bringToFront(); break;
        case 93: _t->alignLeft(); break;
        case 94: _t->alignRight(); break;
        case 95: _t->alignVerticalCenter(); break;
        case 96: _t->alignTop(); break;
        case 97: _t->alignHorizontalCenter(); break;
        case 98: _t->alignBottom(); break;
        case 99: _t->rotate90cw(); break;
        case 100: _t->rotate90ccw(); break;
        case 101: _t->rotate180(); break;
        case 102: _t->rotate45ccw(); break;
        case 103: _t->rotate45cw(); break;
        case 104: _t->rotateIncCCW(); break;
        case 105: _t->rotateIncCW(); break;
        case 106: _t->rotateIncCCWRubberBand(); break;
        case 107: _t->rotateIncCWRubberBand(); break;
        case 108: _t->flipHorizontal(); break;
        case 109: _t->flipVertical(); break;
        case 110: _t->showAllLayers(); break;
        case 111: _t->hideAllLayers(); break;
        case 112: _t->addBendpoint(); break;
        case 113: _t->convertToVia(); break;
        case 114: _t->convertToBendpoint(); break;
        case 115: _t->flattenCurve(); break;
        case 116: _t->disconnectAll(); break;
        case 117: _t->openInPartsEditorNew(); break;
        case 118: _t->openNewPartsEditor((*reinterpret_cast< std::add_pointer_t<PaletteItem*>>(_a[1]))); break;
        case 119: _t->updateZoomSlider((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 120: _t->updateZoomOptionsNoMatterWhat((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 121: _t->updateViewZoom((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 122: _t->setInfoViewOnHover((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 123: _t->updateItemMenu(); break;
        case 124: _t->newAutoroute(); break;
        case 125: _t->orderFab(); break;
        case 126: _t->activeLayerTop(); break;
        case 127: _t->activeLayerBottom(); break;
        case 128: _t->activeLayerBoth(); break;
        case 129: _t->toggleActiveLayer(); break;
        case 130: _t->createTrace(); break;
        case 131: _t->excludeFromAutoroute(); break;
        case 132: _t->selectAllTraces(); break;
        case 133: _t->showUnrouted(); break;
        case 134: _t->selectAllCopperFill(); break;
        case 135: _t->updateRoutingStatus(); break;
        case 136: _t->selectAllExcludedTraces(); break;
        case 137: _t->selectAllIncludedTraces(); break;
        case 138: _t->selectAllJumperItems(); break;
        case 139: _t->selectAllVias(); break;
        case 140: _t->shareOnline(); break;
        case 141: _t->saveBundledPart((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 142: _t->saveBundledPart(); break;
        case 143: { QStringList _r = _t->saveBundledAux((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDir>>(_a[2])));
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 144: _t->binSaved((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 145: _t->routingStatusSlot((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<RoutingStatus>>(_a[2]))); break;
        case 146: _t->applyReadOnlyChange((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 147: _t->raiseAndActivate(); break;
        case 148: _t->activateWindowAux(); break;
        case 149: _t->showPartLabels(); break;
        case 150: _t->addNote(); break;
        case 151: _t->reportBug(); break;
        case 152: _t->enableDebug(); break;
        case 153: _t->tidyWires(); break;
        case 154: _t->changeWireColor((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 155: _t->startSaveInstancesSlot((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QXmlStreamWriter&>>(_a[3]))); break;
        case 156: _t->loadedViewsSlot((*reinterpret_cast< std::add_pointer_t<ModelBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDomElement&>>(_a[2]))); break;
        case 157: _t->loadedRootSlot((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ModelBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QDomElement&>>(_a[3]))); break;
        case 158: _t->loadedProjectPropertiesSlot((*reinterpret_cast< std::add_pointer_t<QDomElement>>(_a[1]))); break;
        case 159: _t->obsoleteSMDOrientationSlot(); break;
        case 160: _t->exportNormalizedSVG(); break;
        case 161: _t->exportNormalizedFlattenedSVG(); break;
        case 162: _t->dumpAllParts(); break;
        case 163: _t->testConnectors(); break;
        case 164: _t->launchExternalProcess(); break;
        case 165: { bool _r = _t->externalProcess((*reinterpret_cast< std::add_pointer_t<QString&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QStringList&>>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 166: _t->processError((*reinterpret_cast< std::add_pointer_t<QProcess::ProcessError>>(_a[1]))); break;
        case 167: _t->processFinished((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QProcess::ExitStatus>>(_a[2]))); break;
        case 168: _t->processReadyRead(); break;
        case 169: _t->processStateChanged((*reinterpret_cast< std::add_pointer_t<QProcess::ProcessState>>(_a[1]))); break;
        case 170: _t->throwFakeException(); break;
        case 171: _t->dropPaste((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1]))); break;
        case 172: _t->openProgramWindow(); break;
        case 173: _t->linkToProgramFile((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Platform*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 174: { QStringList _r = _t->newDesignRulesCheck();
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 175: _t->subSwapSlot((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<long&>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[6]))); break;
        case 176: _t->updateLayerMenuSlot(); break;
        case 177: { bool _r = _t->save();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 178: { bool _r = _t->saveAs();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 179: _t->backupSketch(); break;
        case 180: _t->undoStackCleanChanged((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 181: _t->autosaveNeeded((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 182: _t->autosaveNeeded(); break;
        case 183: _t->changeTraceLayer(); break;
        case 184: _t->routingStatusLabelMousePress((*reinterpret_cast< std::add_pointer_t<QMouseEvent*>>(_a[1]))); break;
        case 185: _t->routingStatusLabelMouseRelease((*reinterpret_cast< std::add_pointer_t<QMouseEvent*>>(_a[1]))); break;
        case 186: _t->selectMoveLock(); break;
        case 187: _t->moveLock(); break;
        case 188: _t->setSticky(); break;
        case 189: _t->autorouterSettings(); break;
        case 190: _t->boardDeletedSlot(); break;
        case 191: _t->cursorLocationSlot((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[4]))); break;
        case 192: _t->cursorLocationSlot((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[3]))); break;
        case 193: _t->cursorLocationSlot((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2]))); break;
        case 194: _t->locationLabelClicked(); break;
        case 195: _t->swapSelectedMap((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QMap<QString,QString>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[4]))); break;
        case 196: _t->filenameIfSlot((*reinterpret_cast< std::add_pointer_t<QString&>>(_a[1]))); break;
        case 197: _t->openURL(); break;
        case 198: _t->setActiveWire((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1]))); break;
        case 199: _t->setActiveConnectorItem((*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[1]))); break;
        case 200: _t->gridUnits((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 201: _t->restoreDefaultGrid(); break;
        case 202: _t->checkLoadedTraces(); break;
        case 203: _t->keepMargins(); break;
        case 204: _t->dockChangeActivation((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QWidget*>>(_a[2]))); break;
        case 205: _t->addToMyParts((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[2]))); break;
        case 206: _t->hidePartSilkscreen(); break;
        case 207: _t->fabQuote(); break;
        case 208: _t->findPartInSketch(); break;
        case 209: _t->fireQuote(); break;
        case 210: _t->setViewFromBelowToggle(); break;
        case 211: _t->setViewFromBelow(); break;
        case 212: _t->setViewFromAbove(); break;
        case 213: _t->updateWelcomeViewRecentList((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 214: _t->updateWelcomeViewRecentList(); break;
        case 215: _t->initZoom(); break;
        case 216: _t->onShareOnlineFinished(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QWidget* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QWidget* >(); break;
            }
            break;
        case 21:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 143:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            }
            break;
        case 155:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            }
            break;
        case 173:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Platform* >(); break;
            }
            break;
        case 175:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 195:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 3:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 204:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QWidget* >(); break;
            }
            break;
        case 205:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)();
            if (_t _q_method = &MainWindow::alienPartsDismissed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QWidget * );
            if (_t _q_method = &MainWindow::mainWindowMoved; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(bool , QWidget * );
            if (_t _q_method = &MainWindow::changeActivationSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QString & , QString & , QStringList & );
            if (_t _q_method = &MainWindow::externalProcessSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return FritzingWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = FritzingWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 217)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 217;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 217)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 217;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::alienPartsDismissed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void MainWindow::mainWindowMoved(QWidget * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MainWindow::changeActivationSignal(bool _t1, QWidget * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void MainWindow::externalProcessSignal(QString & _t1, QString & _t2, QStringList & _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
