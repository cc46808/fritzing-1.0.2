/****************************************************************************
** Meta object code from reading C++ file 'pemetadataview.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/partseditor/pemetadataview.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'pemetadataview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPEMetadataViewENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPEMetadataViewENDCLASS = QtMocHelpers::stringData(
    "PEMetadataView",
    "metadataChanged",
    "",
    "name",
    "value",
    "propertiesChanged",
    "QHash<QString,QString>",
    "tagsChanged",
    "titleEntry",
    "authorEntry",
    "descriptionEntry",
    "labelEntry",
    "familyEntry",
    "variantEntry",
    "dateEntry",
    "urlEntry",
    "propertiesEntry",
    "tagsEntry"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPEMetadataViewENDCLASS_t {
    uint offsetsAndSizes[36];
    char stringdata0[15];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[5];
    char stringdata4[6];
    char stringdata5[18];
    char stringdata6[23];
    char stringdata7[12];
    char stringdata8[11];
    char stringdata9[12];
    char stringdata10[17];
    char stringdata11[11];
    char stringdata12[12];
    char stringdata13[13];
    char stringdata14[10];
    char stringdata15[9];
    char stringdata16[16];
    char stringdata17[10];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPEMetadataViewENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPEMetadataViewENDCLASS_t qt_meta_stringdata_CLASSPEMetadataViewENDCLASS = {
    {
        QT_MOC_LITERAL(0, 14),  // "PEMetadataView"
        QT_MOC_LITERAL(15, 15),  // "metadataChanged"
        QT_MOC_LITERAL(31, 0),  // ""
        QT_MOC_LITERAL(32, 4),  // "name"
        QT_MOC_LITERAL(37, 5),  // "value"
        QT_MOC_LITERAL(43, 17),  // "propertiesChanged"
        QT_MOC_LITERAL(61, 22),  // "QHash<QString,QString>"
        QT_MOC_LITERAL(84, 11),  // "tagsChanged"
        QT_MOC_LITERAL(96, 10),  // "titleEntry"
        QT_MOC_LITERAL(107, 11),  // "authorEntry"
        QT_MOC_LITERAL(119, 16),  // "descriptionEntry"
        QT_MOC_LITERAL(136, 10),  // "labelEntry"
        QT_MOC_LITERAL(147, 11),  // "familyEntry"
        QT_MOC_LITERAL(159, 12),  // "variantEntry"
        QT_MOC_LITERAL(172, 9),  // "dateEntry"
        QT_MOC_LITERAL(182, 8),  // "urlEntry"
        QT_MOC_LITERAL(191, 15),  // "propertiesEntry"
        QT_MOC_LITERAL(207, 9)   // "tagsEntry"
    },
    "PEMetadataView",
    "metadataChanged",
    "",
    "name",
    "value",
    "propertiesChanged",
    "QHash<QString,QString>",
    "tagsChanged",
    "titleEntry",
    "authorEntry",
    "descriptionEntry",
    "labelEntry",
    "familyEntry",
    "variantEntry",
    "dateEntry",
    "urlEntry",
    "propertiesEntry",
    "tagsEntry"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPEMetadataViewENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   92,    2, 0x06,    1 /* Public */,
       5,    1,   97,    2, 0x06,    4 /* Public */,
       7,    1,  100,    2, 0x06,    6 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    0,  103,    2, 0x09,    8 /* Protected */,
       9,    0,  104,    2, 0x09,    9 /* Protected */,
      10,    0,  105,    2, 0x09,   10 /* Protected */,
      11,    0,  106,    2, 0x09,   11 /* Protected */,
      12,    0,  107,    2, 0x09,   12 /* Protected */,
      13,    0,  108,    2, 0x09,   13 /* Protected */,
      14,    0,  109,    2, 0x09,   14 /* Protected */,
      15,    0,  110,    2, 0x09,   15 /* Protected */,
      16,    0,  111,    2, 0x09,   16 /* Protected */,
      17,    0,  112,    2, 0x09,   17 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    3,    4,
    QMetaType::Void, 0x80000000 | 6,    2,
    QMetaType::Void, QMetaType::QStringList,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject PEMetadataView::staticMetaObject = { {
    QMetaObject::SuperData::link<QScrollArea::staticMetaObject>(),
    qt_meta_stringdata_CLASSPEMetadataViewENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPEMetadataViewENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPEMetadataViewENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PEMetadataView, std::true_type>,
        // method 'metadataChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'propertiesChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QHash<QString,QString> &, std::false_type>,
        // method 'tagsChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QStringList &, std::false_type>,
        // method 'titleEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'authorEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'descriptionEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'labelEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'familyEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'variantEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dateEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'urlEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'propertiesEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tagsEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void PEMetadataView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PEMetadataView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->metadataChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 1: _t->propertiesChanged((*reinterpret_cast< std::add_pointer_t<QHash<QString,QString>>>(_a[1]))); break;
        case 2: _t->tagsChanged((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 3: _t->titleEntry(); break;
        case 4: _t->authorEntry(); break;
        case 5: _t->descriptionEntry(); break;
        case 6: _t->labelEntry(); break;
        case 7: _t->familyEntry(); break;
        case 8: _t->variantEntry(); break;
        case 9: _t->dateEntry(); break;
        case 10: _t->urlEntry(); break;
        case 11: _t->propertiesEntry(); break;
        case 12: _t->tagsEntry(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PEMetadataView::*)(const QString & , const QString & );
            if (_t _q_method = &PEMetadataView::metadataChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PEMetadataView::*)(const QHash<QString,QString> & );
            if (_t _q_method = &PEMetadataView::propertiesChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PEMetadataView::*)(const QStringList & );
            if (_t _q_method = &PEMetadataView::tagsChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject *PEMetadataView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PEMetadataView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPEMetadataViewENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QScrollArea::qt_metacast(_clname);
}

int PEMetadataView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QScrollArea::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void PEMetadataView::metadataChanged(const QString & _t1, const QString & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void PEMetadataView::propertiesChanged(const QHash<QString,QString> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void PEMetadataView::tagsChanged(const QStringList & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSFocusOutTextEditENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSFocusOutTextEditENDCLASS = QtMocHelpers::stringData(
    "FocusOutTextEdit",
    "focusOut",
    ""
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSFocusOutTextEditENDCLASS_t {
    uint offsetsAndSizes[6];
    char stringdata0[17];
    char stringdata1[9];
    char stringdata2[1];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSFocusOutTextEditENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSFocusOutTextEditENDCLASS_t qt_meta_stringdata_CLASSFocusOutTextEditENDCLASS = {
    {
        QT_MOC_LITERAL(0, 16),  // "FocusOutTextEdit"
        QT_MOC_LITERAL(17, 8),  // "focusOut"
        QT_MOC_LITERAL(26, 0)   // ""
    },
    "FocusOutTextEdit",
    "focusOut",
    ""
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSFocusOutTextEditENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   20,    2, 0x06,    1 /* Public */,

 // signals: parameters
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject FocusOutTextEdit::staticMetaObject = { {
    QMetaObject::SuperData::link<QTextEdit::staticMetaObject>(),
    qt_meta_stringdata_CLASSFocusOutTextEditENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSFocusOutTextEditENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSFocusOutTextEditENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FocusOutTextEdit, std::true_type>,
        // method 'focusOut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void FocusOutTextEdit::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FocusOutTextEdit *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->focusOut(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FocusOutTextEdit::*)();
            if (_t _q_method = &FocusOutTextEdit::focusOut; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
    (void)_a;
}

const QMetaObject *FocusOutTextEdit::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FocusOutTextEdit::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSFocusOutTextEditENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QTextEdit::qt_metacast(_clname);
}

int FocusOutTextEdit::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTextEdit::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void FocusOutTextEdit::focusOut()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
