/****************************************************************************
** Meta object code from reading C++ file 'logoitem.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/items/logoitem.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'logoitem.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSLogoItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSLogoItemENDCLASS = QtMocHelpers::stringData(
    "LogoItem",
    "logoEntry",
    "",
    "widthEntry",
    "heightEntry"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSLogoItemENDCLASS_t {
    uint offsetsAndSizes[10];
    char stringdata0[9];
    char stringdata1[10];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[12];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSLogoItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSLogoItemENDCLASS_t qt_meta_stringdata_CLASSLogoItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8),  // "LogoItem"
        QT_MOC_LITERAL(9, 9),  // "logoEntry"
        QT_MOC_LITERAL(19, 0),  // ""
        QT_MOC_LITERAL(20, 10),  // "widthEntry"
        QT_MOC_LITERAL(31, 11)   // "heightEntry"
    },
    "LogoItem",
    "logoEntry",
    "",
    "widthEntry",
    "heightEntry"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSLogoItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   32,    2, 0x09,    1 /* Protected */,
       3,    0,   33,    2, 0x09,    2 /* Protected */,
       4,    0,   34,    2, 0x09,    3 /* Protected */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject LogoItem::staticMetaObject = { {
    QMetaObject::SuperData::link<ResizableBoard::staticMetaObject>(),
    qt_meta_stringdata_CLASSLogoItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSLogoItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSLogoItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<LogoItem, std::true_type>,
        // method 'logoEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'widthEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'heightEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void LogoItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<LogoItem *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->logoEntry(); break;
        case 1: _t->widthEntry(); break;
        case 2: _t->heightEntry(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *LogoItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LogoItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSLogoItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return ResizableBoard::qt_metacast(_clname);
}

int LogoItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ResizableBoard::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 3;
    }
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSCopperLogoItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSCopperLogoItemENDCLASS = QtMocHelpers::stringData(
    "CopperLogoItem"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSCopperLogoItemENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[15];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSCopperLogoItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSCopperLogoItemENDCLASS_t qt_meta_stringdata_CLASSCopperLogoItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 14)   // "CopperLogoItem"
    },
    "CopperLogoItem"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSCopperLogoItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject CopperLogoItem::staticMetaObject = { {
    QMetaObject::SuperData::link<LogoItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSCopperLogoItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSCopperLogoItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSCopperLogoItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<CopperLogoItem, std::true_type>
    >,
    nullptr
} };

void CopperLogoItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *CopperLogoItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CopperLogoItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSCopperLogoItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return LogoItem::qt_metacast(_clname);
}

int CopperLogoItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = LogoItem::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSSchematicLogoItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSSchematicLogoItemENDCLASS = QtMocHelpers::stringData(
    "SchematicLogoItem"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSSchematicLogoItemENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[18];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSSchematicLogoItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSSchematicLogoItemENDCLASS_t qt_meta_stringdata_CLASSSchematicLogoItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 17)   // "SchematicLogoItem"
    },
    "SchematicLogoItem"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSSchematicLogoItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject SchematicLogoItem::staticMetaObject = { {
    QMetaObject::SuperData::link<LogoItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSSchematicLogoItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSSchematicLogoItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSSchematicLogoItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<SchematicLogoItem, std::true_type>
    >,
    nullptr
} };

void SchematicLogoItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *SchematicLogoItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SchematicLogoItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSSchematicLogoItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return LogoItem::qt_metacast(_clname);
}

int SchematicLogoItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = LogoItem::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSBreadboardLogoItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSBreadboardLogoItemENDCLASS = QtMocHelpers::stringData(
    "BreadboardLogoItem",
    "changeTextColor",
    ""
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSBreadboardLogoItemENDCLASS_t {
    uint offsetsAndSizes[6];
    char stringdata0[19];
    char stringdata1[16];
    char stringdata2[1];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSBreadboardLogoItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSBreadboardLogoItemENDCLASS_t qt_meta_stringdata_CLASSBreadboardLogoItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 18),  // "BreadboardLogoItem"
        QT_MOC_LITERAL(19, 15),  // "changeTextColor"
        QT_MOC_LITERAL(35, 0)   // ""
    },
    "BreadboardLogoItem",
    "changeTextColor",
    ""
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSBreadboardLogoItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   20,    2, 0x0a,    1 /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject BreadboardLogoItem::staticMetaObject = { {
    QMetaObject::SuperData::link<LogoItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSBreadboardLogoItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSBreadboardLogoItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSBreadboardLogoItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<BreadboardLogoItem, std::true_type>,
        // method 'changeTextColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void BreadboardLogoItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<BreadboardLogoItem *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->changeTextColor(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject *BreadboardLogoItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BreadboardLogoItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSBreadboardLogoItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return LogoItem::qt_metacast(_clname);
}

int BreadboardLogoItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = LogoItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 1;
    }
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSBoardLogoItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSBoardLogoItemENDCLASS = QtMocHelpers::stringData(
    "BoardLogoItem"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSBoardLogoItemENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSBoardLogoItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSBoardLogoItemENDCLASS_t qt_meta_stringdata_CLASSBoardLogoItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 13)   // "BoardLogoItem"
    },
    "BoardLogoItem"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSBoardLogoItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject BoardLogoItem::staticMetaObject = { {
    QMetaObject::SuperData::link<LogoItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSBoardLogoItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSBoardLogoItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSBoardLogoItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<BoardLogoItem, std::true_type>
    >,
    nullptr
} };

void BoardLogoItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *BoardLogoItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BoardLogoItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSBoardLogoItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return LogoItem::qt_metacast(_clname);
}

int BoardLogoItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = LogoItem::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
