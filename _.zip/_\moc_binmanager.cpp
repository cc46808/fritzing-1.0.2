/****************************************************************************
** Meta object code from reading C++ file 'binmanager.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/partsbinpalette/binmanager/binmanager.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'binmanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSBinManagerENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSBinManagerENDCLASS = QtMocHelpers::stringData(
    "BinManager",
    "savePartAsBundled",
    "",
    "moduleId",
    "updateBinCombinedMenuCurrent",
    "toIconView",
    "toListView",
    "setAsCurrentBin",
    "PartsBinPaletteWidget*",
    "bin",
    "updateFileName",
    "newFileName",
    "oldFilename",
    "currentChanged",
    "tabCloseRequested",
    "newBinIn",
    "closeBin",
    "deleteBin",
    "editSelectedNew",
    "saveBin",
    "saveBinAs",
    "renameBin",
    "copyToSketch",
    "copyAllToSketch",
    "exportSelected",
    "removeSelected",
    "findSelected",
    "saveBundledBin",
    "mainLoad"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSBinManagerENDCLASS_t {
    uint offsetsAndSizes[58];
    char stringdata0[11];
    char stringdata1[18];
    char stringdata2[1];
    char stringdata3[9];
    char stringdata4[29];
    char stringdata5[11];
    char stringdata6[11];
    char stringdata7[16];
    char stringdata8[23];
    char stringdata9[4];
    char stringdata10[15];
    char stringdata11[12];
    char stringdata12[12];
    char stringdata13[15];
    char stringdata14[18];
    char stringdata15[9];
    char stringdata16[9];
    char stringdata17[10];
    char stringdata18[16];
    char stringdata19[8];
    char stringdata20[10];
    char stringdata21[10];
    char stringdata22[13];
    char stringdata23[16];
    char stringdata24[15];
    char stringdata25[15];
    char stringdata26[13];
    char stringdata27[15];
    char stringdata28[9];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSBinManagerENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSBinManagerENDCLASS_t qt_meta_stringdata_CLASSBinManagerENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "BinManager"
        QT_MOC_LITERAL(11, 17),  // "savePartAsBundled"
        QT_MOC_LITERAL(29, 0),  // ""
        QT_MOC_LITERAL(30, 8),  // "moduleId"
        QT_MOC_LITERAL(39, 28),  // "updateBinCombinedMenuCurrent"
        QT_MOC_LITERAL(68, 10),  // "toIconView"
        QT_MOC_LITERAL(79, 10),  // "toListView"
        QT_MOC_LITERAL(90, 15),  // "setAsCurrentBin"
        QT_MOC_LITERAL(106, 22),  // "PartsBinPaletteWidget*"
        QT_MOC_LITERAL(129, 3),  // "bin"
        QT_MOC_LITERAL(133, 14),  // "updateFileName"
        QT_MOC_LITERAL(148, 11),  // "newFileName"
        QT_MOC_LITERAL(160, 11),  // "oldFilename"
        QT_MOC_LITERAL(172, 14),  // "currentChanged"
        QT_MOC_LITERAL(187, 17),  // "tabCloseRequested"
        QT_MOC_LITERAL(205, 8),  // "newBinIn"
        QT_MOC_LITERAL(214, 8),  // "closeBin"
        QT_MOC_LITERAL(223, 9),  // "deleteBin"
        QT_MOC_LITERAL(233, 15),  // "editSelectedNew"
        QT_MOC_LITERAL(249, 7),  // "saveBin"
        QT_MOC_LITERAL(257, 9),  // "saveBinAs"
        QT_MOC_LITERAL(267, 9),  // "renameBin"
        QT_MOC_LITERAL(277, 12),  // "copyToSketch"
        QT_MOC_LITERAL(290, 15),  // "copyAllToSketch"
        QT_MOC_LITERAL(306, 14),  // "exportSelected"
        QT_MOC_LITERAL(321, 14),  // "removeSelected"
        QT_MOC_LITERAL(336, 12),  // "findSelected"
        QT_MOC_LITERAL(349, 14),  // "saveBundledBin"
        QT_MOC_LITERAL(364, 8)   // "mainLoad"
    },
    "BinManager",
    "savePartAsBundled",
    "",
    "moduleId",
    "updateBinCombinedMenuCurrent",
    "toIconView",
    "toListView",
    "setAsCurrentBin",
    "PartsBinPaletteWidget*",
    "bin",
    "updateFileName",
    "newFileName",
    "oldFilename",
    "currentChanged",
    "tabCloseRequested",
    "newBinIn",
    "closeBin",
    "deleteBin",
    "editSelectedNew",
    "saveBin",
    "saveBinAs",
    "renameBin",
    "copyToSketch",
    "copyAllToSketch",
    "exportSelected",
    "removeSelected",
    "findSelected",
    "saveBundledBin",
    "mainLoad"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSBinManagerENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  146,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    0,  149,    2, 0x0a,    3 /* Public */,
       5,    0,  150,    2, 0x0a,    4 /* Public */,
       6,    0,  151,    2, 0x0a,    5 /* Public */,
       7,    1,  152,    2, 0x0a,    6 /* Public */,
      10,    3,  155,    2, 0x09,    8 /* Protected */,
      13,    1,  162,    2, 0x09,   12 /* Protected */,
      14,    1,  165,    2, 0x09,   14 /* Protected */,
      15,    0,  168,    2, 0x09,   16 /* Protected */,
      16,    0,  169,    2, 0x09,   17 /* Protected */,
      17,    0,  170,    2, 0x09,   18 /* Protected */,
      18,    0,  171,    2, 0x09,   19 /* Protected */,
      19,    0,  172,    2, 0x09,   20 /* Protected */,
      20,    0,  173,    2, 0x09,   21 /* Protected */,
      21,    0,  174,    2, 0x09,   22 /* Protected */,
      22,    0,  175,    2, 0x09,   23 /* Protected */,
      23,    0,  176,    2, 0x09,   24 /* Protected */,
      24,    0,  177,    2, 0x09,   25 /* Protected */,
      25,    0,  178,    2, 0x09,   26 /* Protected */,
      26,    0,  179,    2, 0x09,   27 /* Protected */,
      27,    0,  180,    2, 0x09,   28 /* Protected */,
      28,    0,  181,    2, 0x09,   29 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, 0x80000000 | 8, QMetaType::QString, QMetaType::QString,    9,   11,   12,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    0x80000000 | 8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject BinManager::staticMetaObject = { {
    QMetaObject::SuperData::link<QFrame::staticMetaObject>(),
    qt_meta_stringdata_CLASSBinManagerENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSBinManagerENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSBinManagerENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<BinManager, std::true_type>,
        // method 'savePartAsBundled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'updateBinCombinedMenuCurrent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toIconView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toListView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setAsCurrentBin'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PartsBinPaletteWidget *, std::false_type>,
        // method 'updateFileName'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PartsBinPaletteWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'currentChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'tabCloseRequested'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'newBinIn'
        QtPrivate::TypeAndForceComplete<PartsBinPaletteWidget *, std::false_type>,
        // method 'closeBin'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'deleteBin'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'editSelectedNew'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveBin'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveBinAs'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'renameBin'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copyToSketch'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copyAllToSketch'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exportSelected'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'removeSelected'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'findSelected'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveBundledBin'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'mainLoad'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void BinManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<BinManager *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->savePartAsBundled((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->updateBinCombinedMenuCurrent(); break;
        case 2: _t->toIconView(); break;
        case 3: _t->toListView(); break;
        case 4: _t->setAsCurrentBin((*reinterpret_cast< std::add_pointer_t<PartsBinPaletteWidget*>>(_a[1]))); break;
        case 5: _t->updateFileName((*reinterpret_cast< std::add_pointer_t<PartsBinPaletteWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3]))); break;
        case 6: _t->currentChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->tabCloseRequested((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: { PartsBinPaletteWidget* _r = _t->newBinIn();
            if (_a[0]) *reinterpret_cast< PartsBinPaletteWidget**>(_a[0]) = std::move(_r); }  break;
        case 9: _t->closeBin(); break;
        case 10: _t->deleteBin(); break;
        case 11: _t->editSelectedNew(); break;
        case 12: _t->saveBin(); break;
        case 13: _t->saveBinAs(); break;
        case 14: _t->renameBin(); break;
        case 15: _t->copyToSketch(); break;
        case 16: _t->copyAllToSketch(); break;
        case 17: _t->exportSelected(); break;
        case 18: { bool _r = _t->removeSelected();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 19: _t->findSelected(); break;
        case 20: _t->saveBundledBin(); break;
        case 21: _t->mainLoad(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (BinManager::*)(const QString & );
            if (_t _q_method = &BinManager::savePartAsBundled; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *BinManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BinManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSBinManagerENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int BinManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
void BinManager::savePartAsBundled(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
