/****************************************************************************
** Meta object code from reading C++ file 'partsbinpalettewidget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/partsbinpalette/partsbinpalettewidget.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'partsbinpalettewidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPartsBinPaletteWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPartsBinPaletteWidgetENDCLASS = QtMocHelpers::stringData(
    "PartsBinPaletteWidget",
    "saved",
    "",
    "hasPartsFromBundled",
    "fileNameUpdated",
    "PartsBinPaletteWidget*",
    "newFileName",
    "oldFilename",
    "focused",
    "addPartCommand",
    "moduleID",
    "removeAlienParts",
    "itemMoved",
    "toIconView",
    "toListView",
    "save",
    "saveAs",
    "changeIconColor",
    "undoStackCleanChanged",
    "isClean",
    "addSketchPartToMe",
    "search",
    "searchTerm",
    "focusSearchAfter"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPartsBinPaletteWidgetENDCLASS_t {
    uint offsetsAndSizes[48];
    char stringdata0[22];
    char stringdata1[6];
    char stringdata2[1];
    char stringdata3[20];
    char stringdata4[16];
    char stringdata5[23];
    char stringdata6[12];
    char stringdata7[12];
    char stringdata8[8];
    char stringdata9[15];
    char stringdata10[9];
    char stringdata11[17];
    char stringdata12[10];
    char stringdata13[11];
    char stringdata14[11];
    char stringdata15[5];
    char stringdata16[7];
    char stringdata17[16];
    char stringdata18[22];
    char stringdata19[8];
    char stringdata20[18];
    char stringdata21[7];
    char stringdata22[11];
    char stringdata23[17];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPartsBinPaletteWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPartsBinPaletteWidgetENDCLASS_t qt_meta_stringdata_CLASSPartsBinPaletteWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 21),  // "PartsBinPaletteWidget"
        QT_MOC_LITERAL(22, 5),  // "saved"
        QT_MOC_LITERAL(28, 0),  // ""
        QT_MOC_LITERAL(29, 19),  // "hasPartsFromBundled"
        QT_MOC_LITERAL(49, 15),  // "fileNameUpdated"
        QT_MOC_LITERAL(65, 22),  // "PartsBinPaletteWidget*"
        QT_MOC_LITERAL(88, 11),  // "newFileName"
        QT_MOC_LITERAL(100, 11),  // "oldFilename"
        QT_MOC_LITERAL(112, 7),  // "focused"
        QT_MOC_LITERAL(120, 14),  // "addPartCommand"
        QT_MOC_LITERAL(135, 8),  // "moduleID"
        QT_MOC_LITERAL(144, 16),  // "removeAlienParts"
        QT_MOC_LITERAL(161, 9),  // "itemMoved"
        QT_MOC_LITERAL(171, 10),  // "toIconView"
        QT_MOC_LITERAL(182, 10),  // "toListView"
        QT_MOC_LITERAL(193, 4),  // "save"
        QT_MOC_LITERAL(198, 6),  // "saveAs"
        QT_MOC_LITERAL(205, 15),  // "changeIconColor"
        QT_MOC_LITERAL(221, 21),  // "undoStackCleanChanged"
        QT_MOC_LITERAL(243, 7),  // "isClean"
        QT_MOC_LITERAL(251, 17),  // "addSketchPartToMe"
        QT_MOC_LITERAL(269, 6),  // "search"
        QT_MOC_LITERAL(276, 10),  // "searchTerm"
        QT_MOC_LITERAL(287, 16)   // "focusSearchAfter"
    },
    "PartsBinPaletteWidget",
    "saved",
    "",
    "hasPartsFromBundled",
    "fileNameUpdated",
    "PartsBinPaletteWidget*",
    "newFileName",
    "oldFilename",
    "focused",
    "addPartCommand",
    "moduleID",
    "removeAlienParts",
    "itemMoved",
    "toIconView",
    "toListView",
    "save",
    "saveAs",
    "changeIconColor",
    "undoStackCleanChanged",
    "isClean",
    "addSketchPartToMe",
    "search",
    "searchTerm",
    "focusSearchAfter"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPartsBinPaletteWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  104,    2, 0x06,    1 /* Public */,
       4,    3,  107,    2, 0x06,    3 /* Public */,
       8,    1,  114,    2, 0x06,    7 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       9,    1,  117,    2, 0x0a,    9 /* Public */,
      11,    0,  120,    2, 0x0a,   11 /* Public */,
      12,    0,  121,    2, 0x0a,   12 /* Public */,
      13,    0,  122,    2, 0x0a,   13 /* Public */,
      14,    0,  123,    2, 0x0a,   14 /* Public */,
      15,    0,  124,    2, 0x0a,   15 /* Public */,
      16,    0,  125,    2, 0x0a,   16 /* Public */,
      17,    0,  126,    2, 0x0a,   17 /* Public */,
      18,    1,  127,    2, 0x09,   18 /* Protected */,
      20,    0,  130,    2, 0x09,   20 /* Protected */,
      21,    1,  131,    2, 0x09,   21 /* Protected */,
      23,    0,  134,    2, 0x09,   23 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, 0x80000000 | 5, QMetaType::QString, QMetaType::QString,    2,    6,    7,
    QMetaType::Void, 0x80000000 | 5,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   19,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject PartsBinPaletteWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QFrame::staticMetaObject>(),
    qt_meta_stringdata_CLASSPartsBinPaletteWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPartsBinPaletteWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPartsBinPaletteWidgetENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PartsBinPaletteWidget, std::true_type>,
        // method 'saved'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'fileNameUpdated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PartsBinPaletteWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'focused'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<PartsBinPaletteWidget *, std::false_type>,
        // method 'addPartCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'removeAlienParts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'itemMoved'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toIconView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toListView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'save'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'saveAs'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'changeIconColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'undoStackCleanChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'addSketchPartToMe'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'search'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'focusSearchAfter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void PartsBinPaletteWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PartsBinPaletteWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->saved((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 1: _t->fileNameUpdated((*reinterpret_cast< std::add_pointer_t<PartsBinPaletteWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3]))); break;
        case 2: _t->focused((*reinterpret_cast< std::add_pointer_t<PartsBinPaletteWidget*>>(_a[1]))); break;
        case 3: _t->addPartCommand((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->removeAlienParts(); break;
        case 5: _t->itemMoved(); break;
        case 6: _t->toIconView(); break;
        case 7: _t->toListView(); break;
        case 8: { bool _r = _t->save();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 9: { bool _r = _t->saveAs();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 10: _t->changeIconColor(); break;
        case 11: _t->undoStackCleanChanged((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 12: _t->addSketchPartToMe(); break;
        case 13: _t->search((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 14: _t->focusSearchAfter(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< PartsBinPaletteWidget* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< PartsBinPaletteWidget* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PartsBinPaletteWidget::*)(bool );
            if (_t _q_method = &PartsBinPaletteWidget::saved; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PartsBinPaletteWidget::*)(PartsBinPaletteWidget * , const QString & , const QString & );
            if (_t _q_method = &PartsBinPaletteWidget::fileNameUpdated; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PartsBinPaletteWidget::*)(PartsBinPaletteWidget * );
            if (_t _q_method = &PartsBinPaletteWidget::focused; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject *PartsBinPaletteWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PartsBinPaletteWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPartsBinPaletteWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "Bundler"))
        return static_cast< Bundler*>(this);
    return QFrame::qt_metacast(_clname);
}

int PartsBinPaletteWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void PartsBinPaletteWidget::saved(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void PartsBinPaletteWidget::fileNameUpdated(PartsBinPaletteWidget * _t1, const QString & _t2, const QString & _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void PartsBinPaletteWidget::focused(PartsBinPaletteWidget * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
