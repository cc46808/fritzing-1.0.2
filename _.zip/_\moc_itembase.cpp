/****************************************************************************
** Meta object code from reading C++ file 'itembase.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/items/itembase.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'itembase.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSItemBaseENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSItemBaseENDCLASS = QtMocHelpers::stringData(
    "ItemBase",
    "showPartLabel",
    "",
    "show",
    "ViewLayer*",
    "hidePartLabel",
    "partLabelChanged",
    "newText",
    "swapEntry",
    "text",
    "index",
    "showInFolder"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSItemBaseENDCLASS_t {
    uint offsetsAndSizes[24];
    char stringdata0[9];
    char stringdata1[14];
    char stringdata2[1];
    char stringdata3[5];
    char stringdata4[11];
    char stringdata5[14];
    char stringdata6[17];
    char stringdata7[8];
    char stringdata8[10];
    char stringdata9[5];
    char stringdata10[6];
    char stringdata11[13];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSItemBaseENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSItemBaseENDCLASS_t qt_meta_stringdata_CLASSItemBaseENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8),  // "ItemBase"
        QT_MOC_LITERAL(9, 13),  // "showPartLabel"
        QT_MOC_LITERAL(23, 0),  // ""
        QT_MOC_LITERAL(24, 4),  // "show"
        QT_MOC_LITERAL(29, 10),  // "ViewLayer*"
        QT_MOC_LITERAL(40, 13),  // "hidePartLabel"
        QT_MOC_LITERAL(54, 16),  // "partLabelChanged"
        QT_MOC_LITERAL(71, 7),  // "newText"
        QT_MOC_LITERAL(79, 9),  // "swapEntry"
        QT_MOC_LITERAL(89, 4),  // "text"
        QT_MOC_LITERAL(94, 5),  // "index"
        QT_MOC_LITERAL(100, 12)   // "showInFolder"
    },
    "ItemBase",
    "showPartLabel",
    "",
    "show",
    "ViewLayer*",
    "hidePartLabel",
    "partLabelChanged",
    "newText",
    "swapEntry",
    "text",
    "index",
    "showInFolder"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSItemBaseENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   50,    2, 0x0a,    1 /* Public */,
       5,    0,   55,    2, 0x0a,    4 /* Public */,
       6,    1,   56,    2, 0x0a,    5 /* Public */,
       8,    1,   59,    2, 0x0a,    7 /* Public */,
       8,    1,   62,    2, 0x0a,    9 /* Public */,
      11,    0,   65,    2, 0x0a,   11 /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 4,    3,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject ItemBase::staticMetaObject = { {
    QMetaObject::SuperData::link<QGraphicsSvgItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSItemBaseENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSItemBaseENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSItemBaseENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ItemBase, std::true_type>,
        // method 'showPartLabel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer *, std::false_type>,
        // method 'hidePartLabel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'partLabelChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'swapEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'swapEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'showInFolder'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void ItemBase::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ItemBase *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showPartLabel((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ViewLayer*>>(_a[2]))); break;
        case 1: _t->hidePartLabel(); break;
        case 2: _t->partLabelChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->swapEntry((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->swapEntry((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->showInFolder(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ViewLayer* >(); break;
            }
            break;
        }
    }
}

const QMetaObject *ItemBase::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ItemBase::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSItemBaseENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QGraphicsSvgItem::qt_metacast(_clname);
}

int ItemBase::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsSvgItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}
QT_WARNING_POP
