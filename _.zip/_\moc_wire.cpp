/****************************************************************************
** Meta object code from reading C++ file 'wire.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/items/wire.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'wire.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSWireActionENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSWireActionENDCLASS = QtMocHelpers::stringData(
    "WireAction"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSWireActionENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[11];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSWireActionENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSWireActionENDCLASS_t qt_meta_stringdata_CLASSWireActionENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10)   // "WireAction"
    },
    "WireAction"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSWireActionENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject WireAction::staticMetaObject = { {
    QMetaObject::SuperData::link<QAction::staticMetaObject>(),
    qt_meta_stringdata_CLASSWireActionENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSWireActionENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSWireActionENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<WireAction, std::true_type>
    >,
    nullptr
} };

void WireAction::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *WireAction::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *WireAction::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSWireActionENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QAction::qt_metacast(_clname);
}

int WireAction::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAction::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSWireENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSWireENDCLASS = QtMocHelpers::stringData(
    "Wire",
    "wireChangedSignal",
    "",
    "Wire*",
    "me",
    "oldLine",
    "newLine",
    "oldPos",
    "newPos",
    "ConnectorItem*",
    "from",
    "to",
    "wireChangedCurveSignal",
    "const Bezier*",
    "oldB",
    "newB",
    "triggerFirstTime",
    "wireSplitSignal",
    "wireJoinSignal",
    "clickedConnectorItem",
    "colorEntry",
    "index",
    "setBandedProp"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSWireENDCLASS_t {
    uint offsetsAndSizes[46];
    char stringdata0[5];
    char stringdata1[18];
    char stringdata2[1];
    char stringdata3[6];
    char stringdata4[3];
    char stringdata5[8];
    char stringdata6[8];
    char stringdata7[7];
    char stringdata8[7];
    char stringdata9[15];
    char stringdata10[5];
    char stringdata11[3];
    char stringdata12[23];
    char stringdata13[14];
    char stringdata14[5];
    char stringdata15[5];
    char stringdata16[17];
    char stringdata17[16];
    char stringdata18[15];
    char stringdata19[21];
    char stringdata20[11];
    char stringdata21[6];
    char stringdata22[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSWireENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSWireENDCLASS_t qt_meta_stringdata_CLASSWireENDCLASS = {
    {
        QT_MOC_LITERAL(0, 4),  // "Wire"
        QT_MOC_LITERAL(5, 17),  // "wireChangedSignal"
        QT_MOC_LITERAL(23, 0),  // ""
        QT_MOC_LITERAL(24, 5),  // "Wire*"
        QT_MOC_LITERAL(30, 2),  // "me"
        QT_MOC_LITERAL(33, 7),  // "oldLine"
        QT_MOC_LITERAL(41, 7),  // "newLine"
        QT_MOC_LITERAL(49, 6),  // "oldPos"
        QT_MOC_LITERAL(56, 6),  // "newPos"
        QT_MOC_LITERAL(63, 14),  // "ConnectorItem*"
        QT_MOC_LITERAL(78, 4),  // "from"
        QT_MOC_LITERAL(83, 2),  // "to"
        QT_MOC_LITERAL(86, 22),  // "wireChangedCurveSignal"
        QT_MOC_LITERAL(109, 13),  // "const Bezier*"
        QT_MOC_LITERAL(123, 4),  // "oldB"
        QT_MOC_LITERAL(128, 4),  // "newB"
        QT_MOC_LITERAL(133, 16),  // "triggerFirstTime"
        QT_MOC_LITERAL(150, 15),  // "wireSplitSignal"
        QT_MOC_LITERAL(166, 14),  // "wireJoinSignal"
        QT_MOC_LITERAL(181, 20),  // "clickedConnectorItem"
        QT_MOC_LITERAL(202, 10),  // "colorEntry"
        QT_MOC_LITERAL(213, 5),  // "index"
        QT_MOC_LITERAL(219, 13)   // "setBandedProp"
    },
    "Wire",
    "wireChangedSignal",
    "",
    "Wire*",
    "me",
    "oldLine",
    "newLine",
    "oldPos",
    "newPos",
    "ConnectorItem*",
    "from",
    "to",
    "wireChangedCurveSignal",
    "const Bezier*",
    "oldB",
    "newB",
    "triggerFirstTime",
    "wireSplitSignal",
    "wireJoinSignal",
    "clickedConnectorItem",
    "colorEntry",
    "index",
    "setBandedProp"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSWireENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    7,   50,    2, 0x06,    1 /* Public */,
      12,    4,   65,    2, 0x06,    9 /* Public */,
      17,    4,   74,    2, 0x06,   14 /* Public */,
      18,    2,   83,    2, 0x06,   19 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      20,    1,   88,    2, 0x09,   22 /* Protected */,
      22,    1,   91,    2, 0x09,   24 /* Protected */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::QLineF, QMetaType::QLineF, QMetaType::QPointF, QMetaType::QPointF, 0x80000000 | 9, 0x80000000 | 9,    4,    5,    6,    7,    8,   10,   11,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 13, 0x80000000 | 13, QMetaType::Bool,    4,   14,   15,   16,
    QMetaType::Void, 0x80000000 | 3, QMetaType::QPointF, QMetaType::QPointF, QMetaType::QLineF,    4,    8,    7,    5,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 9,    4,   19,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Bool,    2,

       0        // eod
};

Q_CONSTINIT const QMetaObject Wire::staticMetaObject = { {
    QMetaObject::SuperData::link<ItemBase::staticMetaObject>(),
    qt_meta_stringdata_CLASSWireENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSWireENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSWireENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<Wire, std::true_type>,
        // method 'wireChangedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QLineF &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QLineF &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        // method 'wireChangedCurveSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Bezier *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Bezier *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'wireSplitSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QLineF &, std::false_type>,
        // method 'wireJoinSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        // method 'colorEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setBandedProp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>
    >,
    nullptr
} };

void Wire::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Wire *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->wireChangedSignal((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QLineF>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QLineF>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[7]))); break;
        case 1: _t->wireChangedCurveSignal((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<const Bezier*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<const Bezier*>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 2: _t->wireSplitSignal((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QLineF>>(_a[4]))); break;
        case 3: _t->wireJoinSignal((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[2]))); break;
        case 4: _t->colorEntry((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->setBandedProp((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Wire* >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Wire* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Wire* >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< Wire* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Wire::*)(Wire * , const QLineF & , const QLineF & , QPointF , QPointF , ConnectorItem * , ConnectorItem * );
            if (_t _q_method = &Wire::wireChangedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Wire::*)(Wire * , const Bezier * , const Bezier * , bool );
            if (_t _q_method = &Wire::wireChangedCurveSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Wire::*)(Wire * , QPointF , QPointF , const QLineF & );
            if (_t _q_method = &Wire::wireSplitSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Wire::*)(Wire * , ConnectorItem * );
            if (_t _q_method = &Wire::wireJoinSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
    }
}

const QMetaObject *Wire::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Wire::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSWireENDCLASS.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "CursorKeyListener"))
        return static_cast< CursorKeyListener*>(this);
    return ItemBase::qt_metacast(_clname);
}

int Wire::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ItemBase::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void Wire::wireChangedSignal(Wire * _t1, const QLineF & _t2, const QLineF & _t3, QPointF _t4, QPointF _t5, ConnectorItem * _t6, ConnectorItem * _t7)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Wire::wireChangedCurveSignal(Wire * _t1, const Bezier * _t2, const Bezier * _t3, bool _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void Wire::wireSplitSignal(Wire * _t1, QPointF _t2, QPointF _t3, const QLineF & _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Wire::wireJoinSignal(Wire * _t1, ConnectorItem * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
