/****************************************************************************
** Meta object code from reading C++ file 'peconnectorsview.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/partseditor/peconnectorsview.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'peconnectorsview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSPEConnectorsViewENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSPEConnectorsViewENDCLASS = QtMocHelpers::stringData(
    "PEConnectorsView",
    "connectorMetadataChanged",
    "",
    "ConnectorMetadata*",
    "removedConnectors",
    "QList<ConnectorMetadata*>&",
    "connectorCountChanged",
    "connectorsTypeChanged",
    "Connector::ConnectorType",
    "smdChanged",
    "nameEntry",
    "descriptionEntry",
    "typeEntry",
    "connectorCountEntry",
    "removeConnector",
    "allTypeEntry",
    "smdEntry",
    "uncheckRadios"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSPEConnectorsViewENDCLASS_t {
    uint offsetsAndSizes[36];
    char stringdata0[17];
    char stringdata1[25];
    char stringdata2[1];
    char stringdata3[19];
    char stringdata4[18];
    char stringdata5[27];
    char stringdata6[22];
    char stringdata7[22];
    char stringdata8[25];
    char stringdata9[11];
    char stringdata10[10];
    char stringdata11[17];
    char stringdata12[10];
    char stringdata13[20];
    char stringdata14[16];
    char stringdata15[13];
    char stringdata16[9];
    char stringdata17[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSPEConnectorsViewENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSPEConnectorsViewENDCLASS_t qt_meta_stringdata_CLASSPEConnectorsViewENDCLASS = {
    {
        QT_MOC_LITERAL(0, 16),  // "PEConnectorsView"
        QT_MOC_LITERAL(17, 24),  // "connectorMetadataChanged"
        QT_MOC_LITERAL(42, 0),  // ""
        QT_MOC_LITERAL(43, 18),  // "ConnectorMetadata*"
        QT_MOC_LITERAL(62, 17),  // "removedConnectors"
        QT_MOC_LITERAL(80, 26),  // "QList<ConnectorMetadata*>&"
        QT_MOC_LITERAL(107, 21),  // "connectorCountChanged"
        QT_MOC_LITERAL(129, 21),  // "connectorsTypeChanged"
        QT_MOC_LITERAL(151, 24),  // "Connector::ConnectorType"
        QT_MOC_LITERAL(176, 10),  // "smdChanged"
        QT_MOC_LITERAL(187, 9),  // "nameEntry"
        QT_MOC_LITERAL(197, 16),  // "descriptionEntry"
        QT_MOC_LITERAL(214, 9),  // "typeEntry"
        QT_MOC_LITERAL(224, 19),  // "connectorCountEntry"
        QT_MOC_LITERAL(244, 15),  // "removeConnector"
        QT_MOC_LITERAL(260, 12),  // "allTypeEntry"
        QT_MOC_LITERAL(273, 8),  // "smdEntry"
        QT_MOC_LITERAL(282, 13)   // "uncheckRadios"
    },
    "PEConnectorsView",
    "connectorMetadataChanged",
    "",
    "ConnectorMetadata*",
    "removedConnectors",
    "QList<ConnectorMetadata*>&",
    "connectorCountChanged",
    "connectorsTypeChanged",
    "Connector::ConnectorType",
    "smdChanged",
    "nameEntry",
    "descriptionEntry",
    "typeEntry",
    "connectorCountEntry",
    "removeConnector",
    "allTypeEntry",
    "smdEntry",
    "uncheckRadios"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSPEConnectorsViewENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   92,    2, 0x06,    1 /* Public */,
       4,    1,   95,    2, 0x06,    3 /* Public */,
       6,    1,   98,    2, 0x06,    5 /* Public */,
       7,    1,  101,    2, 0x06,    7 /* Public */,
       9,    1,  104,    2, 0x06,    9 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      10,    0,  107,    2, 0x09,   11 /* Protected */,
      11,    0,  108,    2, 0x09,   12 /* Protected */,
      12,    0,  109,    2, 0x09,   13 /* Protected */,
      13,    0,  110,    2, 0x09,   14 /* Protected */,
      14,    0,  111,    2, 0x09,   15 /* Protected */,
      15,    0,  112,    2, 0x09,   16 /* Protected */,
      16,    0,  113,    2, 0x09,   17 /* Protected */,
      17,    0,  114,    2, 0x09,   18 /* Protected */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    2,
    QMetaType::Void, 0x80000000 | 5,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, 0x80000000 | 8,    2,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject PEConnectorsView::staticMetaObject = { {
    QMetaObject::SuperData::link<QFrame::staticMetaObject>(),
    qt_meta_stringdata_CLASSPEConnectorsViewENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSPEConnectorsViewENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSPEConnectorsViewENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<PEConnectorsView, std::true_type>,
        // method 'connectorMetadataChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorMetadata *, std::false_type>,
        // method 'removedConnectors'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<struct ConnectorMetadata*> &, std::false_type>,
        // method 'connectorCountChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'connectorsTypeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Connector::ConnectorType, std::false_type>,
        // method 'smdChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'nameEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'descriptionEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'typeEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'connectorCountEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'removeConnector'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'allTypeEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'smdEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'uncheckRadios'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void PEConnectorsView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<PEConnectorsView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->connectorMetadataChanged((*reinterpret_cast< std::add_pointer_t<ConnectorMetadata*>>(_a[1]))); break;
        case 1: _t->removedConnectors((*reinterpret_cast< std::add_pointer_t<QList<ConnectorMetadata*>&>>(_a[1]))); break;
        case 2: _t->connectorCountChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->connectorsTypeChanged((*reinterpret_cast< std::add_pointer_t<Connector::ConnectorType>>(_a[1]))); break;
        case 4: _t->smdChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->nameEntry(); break;
        case 6: _t->descriptionEntry(); break;
        case 7: _t->typeEntry(); break;
        case 8: _t->connectorCountEntry(); break;
        case 9: _t->removeConnector(); break;
        case 10: _t->allTypeEntry(); break;
        case 11: _t->smdEntry(); break;
        case 12: _t->uncheckRadios(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (PEConnectorsView::*)(ConnectorMetadata * );
            if (_t _q_method = &PEConnectorsView::connectorMetadataChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (PEConnectorsView::*)(QList<struct ConnectorMetadata*> & );
            if (_t _q_method = &PEConnectorsView::removedConnectors; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (PEConnectorsView::*)(int );
            if (_t _q_method = &PEConnectorsView::connectorCountChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (PEConnectorsView::*)(Connector::ConnectorType );
            if (_t _q_method = &PEConnectorsView::connectorsTypeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (PEConnectorsView::*)(const QString & );
            if (_t _q_method = &PEConnectorsView::smdChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
    }
}

const QMetaObject *PEConnectorsView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PEConnectorsView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSPEConnectorsViewENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int PEConnectorsView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void PEConnectorsView::connectorMetadataChanged(ConnectorMetadata * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void PEConnectorsView::removedConnectors(QList<struct ConnectorMetadata*> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void PEConnectorsView::connectorCountChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void PEConnectorsView::connectorsTypeChanged(Connector::ConnectorType _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void PEConnectorsView::smdChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_WARNING_POP
