/****************************************************************************
** Meta object code from reading C++ file 'modelbase.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/model/modelbase.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'modelbase.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSModelBaseENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSModelBaseENDCLASS = QtMocHelpers::stringData(
    "ModelBase",
    "loadedViews",
    "",
    "ModelBase*",
    "QDomElement&",
    "views",
    "loadedProjectProperties",
    "QDomElement",
    "projectProperties",
    "loadedRoot",
    "fileName",
    "root",
    "loadingInstances",
    "instances",
    "loadingInstance",
    "instance",
    "obsoleteSMDOrientationSignal",
    "migratePartLabelOffset",
    "fritzingVersion",
    "oldSchematicsSignal",
    "filename",
    "bool&",
    "useOldSchematics"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSModelBaseENDCLASS_t {
    uint offsetsAndSizes[46];
    char stringdata0[10];
    char stringdata1[12];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[13];
    char stringdata5[6];
    char stringdata6[24];
    char stringdata7[12];
    char stringdata8[18];
    char stringdata9[11];
    char stringdata10[9];
    char stringdata11[5];
    char stringdata12[17];
    char stringdata13[10];
    char stringdata14[16];
    char stringdata15[9];
    char stringdata16[29];
    char stringdata17[23];
    char stringdata18[16];
    char stringdata19[20];
    char stringdata20[9];
    char stringdata21[6];
    char stringdata22[17];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSModelBaseENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSModelBaseENDCLASS_t qt_meta_stringdata_CLASSModelBaseENDCLASS = {
    {
        QT_MOC_LITERAL(0, 9),  // "ModelBase"
        QT_MOC_LITERAL(10, 11),  // "loadedViews"
        QT_MOC_LITERAL(22, 0),  // ""
        QT_MOC_LITERAL(23, 10),  // "ModelBase*"
        QT_MOC_LITERAL(34, 12),  // "QDomElement&"
        QT_MOC_LITERAL(47, 5),  // "views"
        QT_MOC_LITERAL(53, 23),  // "loadedProjectProperties"
        QT_MOC_LITERAL(77, 11),  // "QDomElement"
        QT_MOC_LITERAL(89, 17),  // "projectProperties"
        QT_MOC_LITERAL(107, 10),  // "loadedRoot"
        QT_MOC_LITERAL(118, 8),  // "fileName"
        QT_MOC_LITERAL(127, 4),  // "root"
        QT_MOC_LITERAL(132, 16),  // "loadingInstances"
        QT_MOC_LITERAL(149, 9),  // "instances"
        QT_MOC_LITERAL(159, 15),  // "loadingInstance"
        QT_MOC_LITERAL(175, 8),  // "instance"
        QT_MOC_LITERAL(184, 28),  // "obsoleteSMDOrientationSignal"
        QT_MOC_LITERAL(213, 22),  // "migratePartLabelOffset"
        QT_MOC_LITERAL(236, 15),  // "fritzingVersion"
        QT_MOC_LITERAL(252, 19),  // "oldSchematicsSignal"
        QT_MOC_LITERAL(272, 8),  // "filename"
        QT_MOC_LITERAL(281, 5),  // "bool&"
        QT_MOC_LITERAL(287, 16)   // "useOldSchematics"
    },
    "ModelBase",
    "loadedViews",
    "",
    "ModelBase*",
    "QDomElement&",
    "views",
    "loadedProjectProperties",
    "QDomElement",
    "projectProperties",
    "loadedRoot",
    "fileName",
    "root",
    "loadingInstances",
    "instances",
    "loadingInstance",
    "instance",
    "obsoleteSMDOrientationSignal",
    "migratePartLabelOffset",
    "fritzingVersion",
    "oldSchematicsSignal",
    "filename",
    "bool&",
    "useOldSchematics"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSModelBaseENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   62,    2, 0x06,    1 /* Public */,
       6,    1,   67,    2, 0x06,    4 /* Public */,
       9,    3,   70,    2, 0x06,    6 /* Public */,
      12,    2,   77,    2, 0x06,   10 /* Public */,
      14,    2,   82,    2, 0x06,   13 /* Public */,
      16,    0,   87,    2, 0x06,   16 /* Public */,
      17,    1,   88,    2, 0x06,   17 /* Public */,
      19,    2,   91,    2, 0x06,   19 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 4,    2,    5,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 3, 0x80000000 | 4,   10,    2,   11,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 4,    2,   13,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 4,    2,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 21,   20,   22,

       0        // eod
};

Q_CONSTINIT const QMetaObject ModelBase::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSModelBaseENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSModelBaseENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSModelBaseENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ModelBase, std::true_type>,
        // method 'loadedViews'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDomElement &, std::false_type>,
        // method 'loadedProjectProperties'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QDomElement &, std::false_type>,
        // method 'loadedRoot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDomElement &, std::false_type>,
        // method 'loadingInstances'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDomElement &, std::false_type>,
        // method 'loadingInstance'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDomElement &, std::false_type>,
        // method 'obsoleteSMDOrientationSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'migratePartLabelOffset'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'oldSchematicsSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool &, std::false_type>
    >,
    nullptr
} };

void ModelBase::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ModelBase *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->loadedViews((*reinterpret_cast< std::add_pointer_t<ModelBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDomElement&>>(_a[2]))); break;
        case 1: _t->loadedProjectProperties((*reinterpret_cast< std::add_pointer_t<QDomElement>>(_a[1]))); break;
        case 2: _t->loadedRoot((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ModelBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QDomElement&>>(_a[3]))); break;
        case 3: _t->loadingInstances((*reinterpret_cast< std::add_pointer_t<ModelBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDomElement&>>(_a[2]))); break;
        case 4: _t->loadingInstance((*reinterpret_cast< std::add_pointer_t<ModelBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDomElement&>>(_a[2]))); break;
        case 5: _t->obsoleteSMDOrientationSignal(); break;
        case 6: _t->migratePartLabelOffset((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->oldSchematicsSignal((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool&>>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelBase* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelBase* >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelBase* >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelBase* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ModelBase::*)(ModelBase * , QDomElement & );
            if (_t _q_method = &ModelBase::loadedViews; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ModelBase::*)(const QDomElement & );
            if (_t _q_method = &ModelBase::loadedProjectProperties; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (ModelBase::*)(const QString & , ModelBase * , QDomElement & );
            if (_t _q_method = &ModelBase::loadedRoot; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (ModelBase::*)(ModelBase * , QDomElement & );
            if (_t _q_method = &ModelBase::loadingInstances; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (ModelBase::*)(ModelBase * , QDomElement & );
            if (_t _q_method = &ModelBase::loadingInstance; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (ModelBase::*)();
            if (_t _q_method = &ModelBase::obsoleteSMDOrientationSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (ModelBase::*)(const QString & );
            if (_t _q_method = &ModelBase::migratePartLabelOffset; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (ModelBase::*)(const QString & , bool & );
            if (_t _q_method = &ModelBase::oldSchematicsSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
    }
}

const QMetaObject *ModelBase::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ModelBase::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSModelBaseENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int ModelBase::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void ModelBase::loadedViews(ModelBase * _t1, QDomElement & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ModelBase::loadedProjectProperties(const QDomElement & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void ModelBase::loadedRoot(const QString & _t1, ModelBase * _t2, QDomElement & _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void ModelBase::loadingInstances(ModelBase * _t1, QDomElement & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void ModelBase::loadingInstance(ModelBase * _t1, QDomElement & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void ModelBase::obsoleteSMDOrientationSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void ModelBase::migratePartLabelOffset(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void ModelBase::oldSchematicsSignal(const QString & _t1, bool & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_WARNING_POP
