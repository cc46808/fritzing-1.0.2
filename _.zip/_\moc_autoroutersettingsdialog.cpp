/****************************************************************************
** Meta object code from reading C++ file 'autoroutersettingsdialog.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/autoroute/autoroutersettingsdialog.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'autoroutersettingsdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSAutorouterSettingsDialogENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSAutorouterSettingsDialogENDCLASS = QtMocHelpers::stringData(
    "AutorouterSettingsDialog",
    "production",
    "",
    "widthEntry",
    "index",
    "changeUnits",
    "changeHoleSize",
    "changeDiameter",
    "changeThickness",
    "toInches",
    "toMM",
    "keepoutEntry"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSAutorouterSettingsDialogENDCLASS_t {
    uint offsetsAndSizes[24];
    char stringdata0[25];
    char stringdata1[11];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[6];
    char stringdata5[12];
    char stringdata6[15];
    char stringdata7[15];
    char stringdata8[16];
    char stringdata9[9];
    char stringdata10[5];
    char stringdata11[13];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSAutorouterSettingsDialogENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSAutorouterSettingsDialogENDCLASS_t qt_meta_stringdata_CLASSAutorouterSettingsDialogENDCLASS = {
    {
        QT_MOC_LITERAL(0, 24),  // "AutorouterSettingsDialog"
        QT_MOC_LITERAL(25, 10),  // "production"
        QT_MOC_LITERAL(36, 0),  // ""
        QT_MOC_LITERAL(37, 10),  // "widthEntry"
        QT_MOC_LITERAL(48, 5),  // "index"
        QT_MOC_LITERAL(54, 11),  // "changeUnits"
        QT_MOC_LITERAL(66, 14),  // "changeHoleSize"
        QT_MOC_LITERAL(81, 14),  // "changeDiameter"
        QT_MOC_LITERAL(96, 15),  // "changeThickness"
        QT_MOC_LITERAL(112, 8),  // "toInches"
        QT_MOC_LITERAL(121, 4),  // "toMM"
        QT_MOC_LITERAL(126, 12)   // "keepoutEntry"
    },
    "AutorouterSettingsDialog",
    "production",
    "",
    "widthEntry",
    "index",
    "changeUnits",
    "changeHoleSize",
    "changeDiameter",
    "changeThickness",
    "toInches",
    "toMM",
    "keepoutEntry"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSAutorouterSettingsDialogENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   68,    2, 0x09,    1 /* Protected */,
       3,    1,   71,    2, 0x09,    3 /* Protected */,
       5,    1,   74,    2, 0x09,    5 /* Protected */,
       6,    1,   77,    2, 0x09,    7 /* Protected */,
       7,    0,   80,    2, 0x09,    9 /* Protected */,
       8,    0,   81,    2, 0x09,   10 /* Protected */,
       9,    0,   82,    2, 0x09,   11 /* Protected */,
      10,    0,   83,    2, 0x09,   12 /* Protected */,
      11,    0,   84,    2, 0x09,   13 /* Protected */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject AutorouterSettingsDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSAutorouterSettingsDialogENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSAutorouterSettingsDialogENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSAutorouterSettingsDialogENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<AutorouterSettingsDialog, std::true_type>,
        // method 'production'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'widthEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'changeUnits'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'changeHoleSize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'changeDiameter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'changeThickness'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toInches'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toMM'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'keepoutEntry'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void AutorouterSettingsDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<AutorouterSettingsDialog *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->production((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 1: _t->widthEntry((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->changeUnits((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 3: _t->changeHoleSize((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 4: _t->changeDiameter(); break;
        case 5: _t->changeThickness(); break;
        case 6: _t->toInches(); break;
        case 7: _t->toMM(); break;
        case 8: _t->keepoutEntry(); break;
        default: ;
        }
    }
}

const QMetaObject *AutorouterSettingsDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AutorouterSettingsDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSAutorouterSettingsDialogENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int AutorouterSettingsDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
