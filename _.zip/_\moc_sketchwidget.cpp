/****************************************************************************
** Meta object code from reading C++ file 'sketchwidget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/sketch/sketchwidget.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#include <QtCore/QSet>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sketchwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSSizeItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSSizeItemENDCLASS = QtMocHelpers::stringData(
    "SizeItem"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSSizeItemENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[9];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSSizeItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSSizeItemENDCLASS_t qt_meta_stringdata_CLASSSizeItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 8)   // "SizeItem"
    },
    "SizeItem"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSSizeItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject SizeItem::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSSizeItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSSizeItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSSizeItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<SizeItem, std::true_type>
    >,
    nullptr
} };

void SizeItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *SizeItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SizeItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSSizeItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QGraphicsLineItem"))
        return static_cast< QGraphicsLineItem*>(this);
    return QObject::qt_metacast(_clname);
}

int SizeItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSSketchWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSSketchWidgetENDCLASS = QtMocHelpers::stringData(
    "SketchWidget",
    "itemAddedSignal",
    "",
    "ModelPart*",
    "ItemBase*",
    "ViewLayer::ViewLayerPlacement",
    "ViewGeometry",
    "id",
    "SketchWidget*",
    "dropOrigin",
    "itemDeletedSignal",
    "clearSelectionSignal",
    "itemSelectedSignal",
    "state",
    "itemMovedSignal",
    "wireDisconnectedSignal",
    "fromID",
    "fromConnectorID",
    "wireConnectedSignal",
    "toID",
    "toConnectorID",
    "changeConnectionSignal",
    "connect",
    "updateConnections",
    "copyBoundingRectsSignal",
    "QHash<QString,QRectF>&",
    "cleanUpWiresSignal",
    "CleanUpWiresCommand*",
    "selectionChangedSignal",
    "resizeSignal",
    "dropSignal",
    "pos",
    "routingStatusSignal",
    "RoutingStatus",
    "movingSignal",
    "QUndoCommand*",
    "parentCommand",
    "selectAllItemsSignal",
    "doEmit",
    "checkStickySignal",
    "checkCurrent",
    "CheckStickyCommand*",
    "disconnectAllSignal",
    "QList<ConnectorItem*>",
    "QHash<ItemBase*,SketchWidget*>&",
    "itemsToDelete",
    "setResistanceSignal",
    "itemID",
    "resistance",
    "pinSpacing",
    "setPropSignal",
    "prop",
    "value",
    "doRedraw",
    "setInstanceTitleSignal",
    "oldTitle",
    "newTitle",
    "isUndoable",
    "statusMessageSignal",
    "timeout",
    "showLabelFirstTimeSignal",
    "show",
    "dropPasteSignal",
    "changeBoardLayersSignal",
    "deleteTracesSignal",
    "QSet<ItemBase*>&",
    "deletedItems",
    "otherDeletedItems",
    "QList<long>&",
    "deletedIDs",
    "isForeign",
    "makeDeleteItemCommandPrepSignal",
    "itemBase",
    "foreign",
    "makeDeleteItemCommandFinalSignal",
    "cursorLocationSignal",
    "xinches",
    "yinches",
    "width",
    "height",
    "ratsnestConnectSignal",
    "connectorID",
    "updatePartLabelInstanceTitleSignal",
    "filenameIfSignal",
    "QString&",
    "filename",
    "collectRatsnestSignal",
    "QList<SketchWidget*>&",
    "foreignSketchWidgets",
    "removeRatsnestSignal",
    "QList<ConnectorEdge*>&",
    "cutSet",
    "updateLayerMenuSignal",
    "swapBoardImageSignal",
    "sketchWidget",
    "moduleID",
    "addName",
    "canConnectSignal",
    "Wire*",
    "from",
    "to",
    "bool&",
    "swapStartSignal",
    "SwapThing&",
    "swapThing",
    "master",
    "showing",
    "clickedItemCandidateSignal",
    "QGraphicsItem*",
    "ok",
    "resizedSignal",
    "cleanupRatsnestsSignal",
    "addSubpartSignal",
    "subpartID",
    "getDroppedItemViewLayerPlacementSignal",
    "modelPart",
    "ViewLayer::ViewLayerPlacement&",
    "packItemsSignal",
    "columns",
    "QList<long>",
    "ids",
    "parent",
    "routingCheckSignal",
    "itemAddedSlot",
    "itemDeletedSlot",
    "clearSelectionSlot",
    "itemSelectedSlot",
    "selectionChangedSlot",
    "wireChangedSlot",
    "oldLine",
    "newLine",
    "oldPos",
    "newPos",
    "ConnectorItem*",
    "wireChangedCurveSlot",
    "const Bezier*",
    "oldB",
    "newB",
    "triggerFirstTime",
    "wireSplitSlot",
    "wireJoinSlot",
    "clickedConnectorItem",
    "toggleLayerVisibility",
    "wireConnectedSlot",
    "wireDisconnectedSlot",
    "changeConnectionSlot",
    "restartPasteCount",
    "dragIsDoneSlot",
    "ItemDrag*",
    "statusMessage",
    "message",
    "cleanUpWiresSlot",
    "updateInfoViewSlot",
    "spaceBarIsPressedSlot",
    "autoScrollTimeout",
    "dragAutoScrollTimeout",
    "moveAutoScrollTimeout",
    "rememberSticky",
    "copyBoundingRectsSlot",
    "deleteRatsnest",
    "deleteTracesSlot",
    "vScrollToZero",
    "arrowTimerTimeout",
    "makeDeleteItemCommandPrepSlot",
    "makeDeleteItemCommandFinalSlot",
    "updatePartLabelInstanceTitleSlot",
    "changePinLabelsSlot",
    "changePinLabels",
    "collectRatsnestSlot",
    "removeRatsnestSlot",
    "deleteTemporary",
    "canConnect",
    "swapStart",
    "getDroppedItemViewLayerPlacement",
    "changeWireColor",
    "newColor",
    "changeWireWidthMils",
    "newWidth",
    "selectAllItems",
    "setInstanceTitleForCommand",
    "checkStickyForCommand",
    "resizeBoard",
    "w",
    "h",
    "disconnectAllSlot",
    "setResistance",
    "setProp",
    "redraw",
    "propName",
    "translatedPropName",
    "oldValue",
    "newValue",
    "setHoleSize",
    "QRectF&",
    "oldRect",
    "newRect",
    "showLabelFirstTimeForCommand",
    "changeBoardLayers",
    "layers",
    "updateConnectors",
    "ratsnestConnectForCommand",
    "cleanupRatsnestsForCommand",
    "addSubpartForCommand",
    "subpartid",
    "packItemsForCommand",
    "gridColor",
    "ratsnestWidth",
    "ratsnestOpacity"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSSketchWidgetENDCLASS_t {
    uint offsetsAndSizes[416];
    char stringdata0[13];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[10];
    char stringdata5[30];
    char stringdata6[13];
    char stringdata7[3];
    char stringdata8[14];
    char stringdata9[11];
    char stringdata10[18];
    char stringdata11[21];
    char stringdata12[19];
    char stringdata13[6];
    char stringdata14[16];
    char stringdata15[23];
    char stringdata16[7];
    char stringdata17[16];
    char stringdata18[20];
    char stringdata19[5];
    char stringdata20[14];
    char stringdata21[23];
    char stringdata22[8];
    char stringdata23[18];
    char stringdata24[24];
    char stringdata25[23];
    char stringdata26[19];
    char stringdata27[21];
    char stringdata28[23];
    char stringdata29[13];
    char stringdata30[11];
    char stringdata31[4];
    char stringdata32[20];
    char stringdata33[14];
    char stringdata34[13];
    char stringdata35[14];
    char stringdata36[14];
    char stringdata37[21];
    char stringdata38[7];
    char stringdata39[18];
    char stringdata40[13];
    char stringdata41[20];
    char stringdata42[20];
    char stringdata43[22];
    char stringdata44[32];
    char stringdata45[14];
    char stringdata46[20];
    char stringdata47[7];
    char stringdata48[11];
    char stringdata49[11];
    char stringdata50[14];
    char stringdata51[5];
    char stringdata52[6];
    char stringdata53[9];
    char stringdata54[23];
    char stringdata55[9];
    char stringdata56[9];
    char stringdata57[11];
    char stringdata58[20];
    char stringdata59[8];
    char stringdata60[25];
    char stringdata61[5];
    char stringdata62[16];
    char stringdata63[24];
    char stringdata64[19];
    char stringdata65[17];
    char stringdata66[13];
    char stringdata67[18];
    char stringdata68[13];
    char stringdata69[11];
    char stringdata70[10];
    char stringdata71[32];
    char stringdata72[9];
    char stringdata73[8];
    char stringdata74[33];
    char stringdata75[21];
    char stringdata76[8];
    char stringdata77[8];
    char stringdata78[6];
    char stringdata79[7];
    char stringdata80[22];
    char stringdata81[12];
    char stringdata82[35];
    char stringdata83[17];
    char stringdata84[9];
    char stringdata85[9];
    char stringdata86[22];
    char stringdata87[22];
    char stringdata88[21];
    char stringdata89[21];
    char stringdata90[23];
    char stringdata91[7];
    char stringdata92[22];
    char stringdata93[21];
    char stringdata94[13];
    char stringdata95[9];
    char stringdata96[8];
    char stringdata97[17];
    char stringdata98[6];
    char stringdata99[5];
    char stringdata100[3];
    char stringdata101[6];
    char stringdata102[16];
    char stringdata103[11];
    char stringdata104[10];
    char stringdata105[7];
    char stringdata106[8];
    char stringdata107[27];
    char stringdata108[15];
    char stringdata109[3];
    char stringdata110[14];
    char stringdata111[23];
    char stringdata112[17];
    char stringdata113[10];
    char stringdata114[39];
    char stringdata115[10];
    char stringdata116[31];
    char stringdata117[16];
    char stringdata118[8];
    char stringdata119[12];
    char stringdata120[4];
    char stringdata121[7];
    char stringdata122[19];
    char stringdata123[14];
    char stringdata124[16];
    char stringdata125[19];
    char stringdata126[17];
    char stringdata127[21];
    char stringdata128[16];
    char stringdata129[8];
    char stringdata130[8];
    char stringdata131[7];
    char stringdata132[7];
    char stringdata133[15];
    char stringdata134[21];
    char stringdata135[14];
    char stringdata136[5];
    char stringdata137[5];
    char stringdata138[17];
    char stringdata139[14];
    char stringdata140[13];
    char stringdata141[21];
    char stringdata142[22];
    char stringdata143[18];
    char stringdata144[21];
    char stringdata145[21];
    char stringdata146[18];
    char stringdata147[15];
    char stringdata148[10];
    char stringdata149[14];
    char stringdata150[8];
    char stringdata151[17];
    char stringdata152[19];
    char stringdata153[22];
    char stringdata154[18];
    char stringdata155[22];
    char stringdata156[22];
    char stringdata157[15];
    char stringdata158[22];
    char stringdata159[15];
    char stringdata160[17];
    char stringdata161[14];
    char stringdata162[18];
    char stringdata163[30];
    char stringdata164[31];
    char stringdata165[33];
    char stringdata166[20];
    char stringdata167[16];
    char stringdata168[20];
    char stringdata169[19];
    char stringdata170[16];
    char stringdata171[11];
    char stringdata172[10];
    char stringdata173[33];
    char stringdata174[16];
    char stringdata175[9];
    char stringdata176[20];
    char stringdata177[9];
    char stringdata178[15];
    char stringdata179[27];
    char stringdata180[22];
    char stringdata181[12];
    char stringdata182[2];
    char stringdata183[2];
    char stringdata184[18];
    char stringdata185[14];
    char stringdata186[8];
    char stringdata187[7];
    char stringdata188[9];
    char stringdata189[19];
    char stringdata190[9];
    char stringdata191[9];
    char stringdata192[12];
    char stringdata193[8];
    char stringdata194[8];
    char stringdata195[8];
    char stringdata196[29];
    char stringdata197[18];
    char stringdata198[7];
    char stringdata199[17];
    char stringdata200[26];
    char stringdata201[27];
    char stringdata202[21];
    char stringdata203[10];
    char stringdata204[20];
    char stringdata205[10];
    char stringdata206[14];
    char stringdata207[16];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSSketchWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSSketchWidgetENDCLASS_t qt_meta_stringdata_CLASSSketchWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 12),  // "SketchWidget"
        QT_MOC_LITERAL(13, 15),  // "itemAddedSignal"
        QT_MOC_LITERAL(29, 0),  // ""
        QT_MOC_LITERAL(30, 10),  // "ModelPart*"
        QT_MOC_LITERAL(41, 9),  // "ItemBase*"
        QT_MOC_LITERAL(51, 29),  // "ViewLayer::ViewLayerPlacement"
        QT_MOC_LITERAL(81, 12),  // "ViewGeometry"
        QT_MOC_LITERAL(94, 2),  // "id"
        QT_MOC_LITERAL(97, 13),  // "SketchWidget*"
        QT_MOC_LITERAL(111, 10),  // "dropOrigin"
        QT_MOC_LITERAL(122, 17),  // "itemDeletedSignal"
        QT_MOC_LITERAL(140, 20),  // "clearSelectionSignal"
        QT_MOC_LITERAL(161, 18),  // "itemSelectedSignal"
        QT_MOC_LITERAL(180, 5),  // "state"
        QT_MOC_LITERAL(186, 15),  // "itemMovedSignal"
        QT_MOC_LITERAL(202, 22),  // "wireDisconnectedSignal"
        QT_MOC_LITERAL(225, 6),  // "fromID"
        QT_MOC_LITERAL(232, 15),  // "fromConnectorID"
        QT_MOC_LITERAL(248, 19),  // "wireConnectedSignal"
        QT_MOC_LITERAL(268, 4),  // "toID"
        QT_MOC_LITERAL(273, 13),  // "toConnectorID"
        QT_MOC_LITERAL(287, 22),  // "changeConnectionSignal"
        QT_MOC_LITERAL(310, 7),  // "connect"
        QT_MOC_LITERAL(318, 17),  // "updateConnections"
        QT_MOC_LITERAL(336, 23),  // "copyBoundingRectsSignal"
        QT_MOC_LITERAL(360, 22),  // "QHash<QString,QRectF>&"
        QT_MOC_LITERAL(383, 18),  // "cleanUpWiresSignal"
        QT_MOC_LITERAL(402, 20),  // "CleanUpWiresCommand*"
        QT_MOC_LITERAL(423, 22),  // "selectionChangedSignal"
        QT_MOC_LITERAL(446, 12),  // "resizeSignal"
        QT_MOC_LITERAL(459, 10),  // "dropSignal"
        QT_MOC_LITERAL(470, 3),  // "pos"
        QT_MOC_LITERAL(474, 19),  // "routingStatusSignal"
        QT_MOC_LITERAL(494, 13),  // "RoutingStatus"
        QT_MOC_LITERAL(508, 12),  // "movingSignal"
        QT_MOC_LITERAL(521, 13),  // "QUndoCommand*"
        QT_MOC_LITERAL(535, 13),  // "parentCommand"
        QT_MOC_LITERAL(549, 20),  // "selectAllItemsSignal"
        QT_MOC_LITERAL(570, 6),  // "doEmit"
        QT_MOC_LITERAL(577, 17),  // "checkStickySignal"
        QT_MOC_LITERAL(595, 12),  // "checkCurrent"
        QT_MOC_LITERAL(608, 19),  // "CheckStickyCommand*"
        QT_MOC_LITERAL(628, 19),  // "disconnectAllSignal"
        QT_MOC_LITERAL(648, 21),  // "QList<ConnectorItem*>"
        QT_MOC_LITERAL(670, 31),  // "QHash<ItemBase*,SketchWidget*>&"
        QT_MOC_LITERAL(702, 13),  // "itemsToDelete"
        QT_MOC_LITERAL(716, 19),  // "setResistanceSignal"
        QT_MOC_LITERAL(736, 6),  // "itemID"
        QT_MOC_LITERAL(743, 10),  // "resistance"
        QT_MOC_LITERAL(754, 10),  // "pinSpacing"
        QT_MOC_LITERAL(765, 13),  // "setPropSignal"
        QT_MOC_LITERAL(779, 4),  // "prop"
        QT_MOC_LITERAL(784, 5),  // "value"
        QT_MOC_LITERAL(790, 8),  // "doRedraw"
        QT_MOC_LITERAL(799, 22),  // "setInstanceTitleSignal"
        QT_MOC_LITERAL(822, 8),  // "oldTitle"
        QT_MOC_LITERAL(831, 8),  // "newTitle"
        QT_MOC_LITERAL(840, 10),  // "isUndoable"
        QT_MOC_LITERAL(851, 19),  // "statusMessageSignal"
        QT_MOC_LITERAL(871, 7),  // "timeout"
        QT_MOC_LITERAL(879, 24),  // "showLabelFirstTimeSignal"
        QT_MOC_LITERAL(904, 4),  // "show"
        QT_MOC_LITERAL(909, 15),  // "dropPasteSignal"
        QT_MOC_LITERAL(925, 23),  // "changeBoardLayersSignal"
        QT_MOC_LITERAL(949, 18),  // "deleteTracesSignal"
        QT_MOC_LITERAL(968, 16),  // "QSet<ItemBase*>&"
        QT_MOC_LITERAL(985, 12),  // "deletedItems"
        QT_MOC_LITERAL(998, 17),  // "otherDeletedItems"
        QT_MOC_LITERAL(1016, 12),  // "QList<long>&"
        QT_MOC_LITERAL(1029, 10),  // "deletedIDs"
        QT_MOC_LITERAL(1040, 9),  // "isForeign"
        QT_MOC_LITERAL(1050, 31),  // "makeDeleteItemCommandPrepSignal"
        QT_MOC_LITERAL(1082, 8),  // "itemBase"
        QT_MOC_LITERAL(1091, 7),  // "foreign"
        QT_MOC_LITERAL(1099, 32),  // "makeDeleteItemCommandFinalSignal"
        QT_MOC_LITERAL(1132, 20),  // "cursorLocationSignal"
        QT_MOC_LITERAL(1153, 7),  // "xinches"
        QT_MOC_LITERAL(1161, 7),  // "yinches"
        QT_MOC_LITERAL(1169, 5),  // "width"
        QT_MOC_LITERAL(1175, 6),  // "height"
        QT_MOC_LITERAL(1182, 21),  // "ratsnestConnectSignal"
        QT_MOC_LITERAL(1204, 11),  // "connectorID"
        QT_MOC_LITERAL(1216, 34),  // "updatePartLabelInstanceTitleS..."
        QT_MOC_LITERAL(1251, 16),  // "filenameIfSignal"
        QT_MOC_LITERAL(1268, 8),  // "QString&"
        QT_MOC_LITERAL(1277, 8),  // "filename"
        QT_MOC_LITERAL(1286, 21),  // "collectRatsnestSignal"
        QT_MOC_LITERAL(1308, 21),  // "QList<SketchWidget*>&"
        QT_MOC_LITERAL(1330, 20),  // "foreignSketchWidgets"
        QT_MOC_LITERAL(1351, 20),  // "removeRatsnestSignal"
        QT_MOC_LITERAL(1372, 22),  // "QList<ConnectorEdge*>&"
        QT_MOC_LITERAL(1395, 6),  // "cutSet"
        QT_MOC_LITERAL(1402, 21),  // "updateLayerMenuSignal"
        QT_MOC_LITERAL(1424, 20),  // "swapBoardImageSignal"
        QT_MOC_LITERAL(1445, 12),  // "sketchWidget"
        QT_MOC_LITERAL(1458, 8),  // "moduleID"
        QT_MOC_LITERAL(1467, 7),  // "addName"
        QT_MOC_LITERAL(1475, 16),  // "canConnectSignal"
        QT_MOC_LITERAL(1492, 5),  // "Wire*"
        QT_MOC_LITERAL(1498, 4),  // "from"
        QT_MOC_LITERAL(1503, 2),  // "to"
        QT_MOC_LITERAL(1506, 5),  // "bool&"
        QT_MOC_LITERAL(1512, 15),  // "swapStartSignal"
        QT_MOC_LITERAL(1528, 10),  // "SwapThing&"
        QT_MOC_LITERAL(1539, 9),  // "swapThing"
        QT_MOC_LITERAL(1549, 6),  // "master"
        QT_MOC_LITERAL(1556, 7),  // "showing"
        QT_MOC_LITERAL(1564, 26),  // "clickedItemCandidateSignal"
        QT_MOC_LITERAL(1591, 14),  // "QGraphicsItem*"
        QT_MOC_LITERAL(1606, 2),  // "ok"
        QT_MOC_LITERAL(1609, 13),  // "resizedSignal"
        QT_MOC_LITERAL(1623, 22),  // "cleanupRatsnestsSignal"
        QT_MOC_LITERAL(1646, 16),  // "addSubpartSignal"
        QT_MOC_LITERAL(1663, 9),  // "subpartID"
        QT_MOC_LITERAL(1673, 38),  // "getDroppedItemViewLayerPlacem..."
        QT_MOC_LITERAL(1712, 9),  // "modelPart"
        QT_MOC_LITERAL(1722, 30),  // "ViewLayer::ViewLayerPlacement&"
        QT_MOC_LITERAL(1753, 15),  // "packItemsSignal"
        QT_MOC_LITERAL(1769, 7),  // "columns"
        QT_MOC_LITERAL(1777, 11),  // "QList<long>"
        QT_MOC_LITERAL(1789, 3),  // "ids"
        QT_MOC_LITERAL(1793, 6),  // "parent"
        QT_MOC_LITERAL(1800, 18),  // "routingCheckSignal"
        QT_MOC_LITERAL(1819, 13),  // "itemAddedSlot"
        QT_MOC_LITERAL(1833, 15),  // "itemDeletedSlot"
        QT_MOC_LITERAL(1849, 18),  // "clearSelectionSlot"
        QT_MOC_LITERAL(1868, 16),  // "itemSelectedSlot"
        QT_MOC_LITERAL(1885, 20),  // "selectionChangedSlot"
        QT_MOC_LITERAL(1906, 15),  // "wireChangedSlot"
        QT_MOC_LITERAL(1922, 7),  // "oldLine"
        QT_MOC_LITERAL(1930, 7),  // "newLine"
        QT_MOC_LITERAL(1938, 6),  // "oldPos"
        QT_MOC_LITERAL(1945, 6),  // "newPos"
        QT_MOC_LITERAL(1952, 14),  // "ConnectorItem*"
        QT_MOC_LITERAL(1967, 20),  // "wireChangedCurveSlot"
        QT_MOC_LITERAL(1988, 13),  // "const Bezier*"
        QT_MOC_LITERAL(2002, 4),  // "oldB"
        QT_MOC_LITERAL(2007, 4),  // "newB"
        QT_MOC_LITERAL(2012, 16),  // "triggerFirstTime"
        QT_MOC_LITERAL(2029, 13),  // "wireSplitSlot"
        QT_MOC_LITERAL(2043, 12),  // "wireJoinSlot"
        QT_MOC_LITERAL(2056, 20),  // "clickedConnectorItem"
        QT_MOC_LITERAL(2077, 21),  // "toggleLayerVisibility"
        QT_MOC_LITERAL(2099, 17),  // "wireConnectedSlot"
        QT_MOC_LITERAL(2117, 20),  // "wireDisconnectedSlot"
        QT_MOC_LITERAL(2138, 20),  // "changeConnectionSlot"
        QT_MOC_LITERAL(2159, 17),  // "restartPasteCount"
        QT_MOC_LITERAL(2177, 14),  // "dragIsDoneSlot"
        QT_MOC_LITERAL(2192, 9),  // "ItemDrag*"
        QT_MOC_LITERAL(2202, 13),  // "statusMessage"
        QT_MOC_LITERAL(2216, 7),  // "message"
        QT_MOC_LITERAL(2224, 16),  // "cleanUpWiresSlot"
        QT_MOC_LITERAL(2241, 18),  // "updateInfoViewSlot"
        QT_MOC_LITERAL(2260, 21),  // "spaceBarIsPressedSlot"
        QT_MOC_LITERAL(2282, 17),  // "autoScrollTimeout"
        QT_MOC_LITERAL(2300, 21),  // "dragAutoScrollTimeout"
        QT_MOC_LITERAL(2322, 21),  // "moveAutoScrollTimeout"
        QT_MOC_LITERAL(2344, 14),  // "rememberSticky"
        QT_MOC_LITERAL(2359, 21),  // "copyBoundingRectsSlot"
        QT_MOC_LITERAL(2381, 14),  // "deleteRatsnest"
        QT_MOC_LITERAL(2396, 16),  // "deleteTracesSlot"
        QT_MOC_LITERAL(2413, 13),  // "vScrollToZero"
        QT_MOC_LITERAL(2427, 17),  // "arrowTimerTimeout"
        QT_MOC_LITERAL(2445, 29),  // "makeDeleteItemCommandPrepSlot"
        QT_MOC_LITERAL(2475, 30),  // "makeDeleteItemCommandFinalSlot"
        QT_MOC_LITERAL(2506, 32),  // "updatePartLabelInstanceTitleSlot"
        QT_MOC_LITERAL(2539, 19),  // "changePinLabelsSlot"
        QT_MOC_LITERAL(2559, 15),  // "changePinLabels"
        QT_MOC_LITERAL(2575, 19),  // "collectRatsnestSlot"
        QT_MOC_LITERAL(2595, 18),  // "removeRatsnestSlot"
        QT_MOC_LITERAL(2614, 15),  // "deleteTemporary"
        QT_MOC_LITERAL(2630, 10),  // "canConnect"
        QT_MOC_LITERAL(2641, 9),  // "swapStart"
        QT_MOC_LITERAL(2651, 32),  // "getDroppedItemViewLayerPlacement"
        QT_MOC_LITERAL(2684, 15),  // "changeWireColor"
        QT_MOC_LITERAL(2700, 8),  // "newColor"
        QT_MOC_LITERAL(2709, 19),  // "changeWireWidthMils"
        QT_MOC_LITERAL(2729, 8),  // "newWidth"
        QT_MOC_LITERAL(2738, 14),  // "selectAllItems"
        QT_MOC_LITERAL(2753, 26),  // "setInstanceTitleForCommand"
        QT_MOC_LITERAL(2780, 21),  // "checkStickyForCommand"
        QT_MOC_LITERAL(2802, 11),  // "resizeBoard"
        QT_MOC_LITERAL(2814, 1),  // "w"
        QT_MOC_LITERAL(2816, 1),  // "h"
        QT_MOC_LITERAL(2818, 17),  // "disconnectAllSlot"
        QT_MOC_LITERAL(2836, 13),  // "setResistance"
        QT_MOC_LITERAL(2850, 7),  // "setProp"
        QT_MOC_LITERAL(2858, 6),  // "redraw"
        QT_MOC_LITERAL(2865, 8),  // "propName"
        QT_MOC_LITERAL(2874, 18),  // "translatedPropName"
        QT_MOC_LITERAL(2893, 8),  // "oldValue"
        QT_MOC_LITERAL(2902, 8),  // "newValue"
        QT_MOC_LITERAL(2911, 11),  // "setHoleSize"
        QT_MOC_LITERAL(2923, 7),  // "QRectF&"
        QT_MOC_LITERAL(2931, 7),  // "oldRect"
        QT_MOC_LITERAL(2939, 7),  // "newRect"
        QT_MOC_LITERAL(2947, 28),  // "showLabelFirstTimeForCommand"
        QT_MOC_LITERAL(2976, 17),  // "changeBoardLayers"
        QT_MOC_LITERAL(2994, 6),  // "layers"
        QT_MOC_LITERAL(3001, 16),  // "updateConnectors"
        QT_MOC_LITERAL(3018, 25),  // "ratsnestConnectForCommand"
        QT_MOC_LITERAL(3044, 26),  // "cleanupRatsnestsForCommand"
        QT_MOC_LITERAL(3071, 20),  // "addSubpartForCommand"
        QT_MOC_LITERAL(3092, 9),  // "subpartid"
        QT_MOC_LITERAL(3102, 19),  // "packItemsForCommand"
        QT_MOC_LITERAL(3122, 9),  // "gridColor"
        QT_MOC_LITERAL(3132, 13),  // "ratsnestWidth"
        QT_MOC_LITERAL(3146, 15)   // "ratsnestOpacity"
    },
    "SketchWidget",
    "itemAddedSignal",
    "",
    "ModelPart*",
    "ItemBase*",
    "ViewLayer::ViewLayerPlacement",
    "ViewGeometry",
    "id",
    "SketchWidget*",
    "dropOrigin",
    "itemDeletedSignal",
    "clearSelectionSignal",
    "itemSelectedSignal",
    "state",
    "itemMovedSignal",
    "wireDisconnectedSignal",
    "fromID",
    "fromConnectorID",
    "wireConnectedSignal",
    "toID",
    "toConnectorID",
    "changeConnectionSignal",
    "connect",
    "updateConnections",
    "copyBoundingRectsSignal",
    "QHash<QString,QRectF>&",
    "cleanUpWiresSignal",
    "CleanUpWiresCommand*",
    "selectionChangedSignal",
    "resizeSignal",
    "dropSignal",
    "pos",
    "routingStatusSignal",
    "RoutingStatus",
    "movingSignal",
    "QUndoCommand*",
    "parentCommand",
    "selectAllItemsSignal",
    "doEmit",
    "checkStickySignal",
    "checkCurrent",
    "CheckStickyCommand*",
    "disconnectAllSignal",
    "QList<ConnectorItem*>",
    "QHash<ItemBase*,SketchWidget*>&",
    "itemsToDelete",
    "setResistanceSignal",
    "itemID",
    "resistance",
    "pinSpacing",
    "setPropSignal",
    "prop",
    "value",
    "doRedraw",
    "setInstanceTitleSignal",
    "oldTitle",
    "newTitle",
    "isUndoable",
    "statusMessageSignal",
    "timeout",
    "showLabelFirstTimeSignal",
    "show",
    "dropPasteSignal",
    "changeBoardLayersSignal",
    "deleteTracesSignal",
    "QSet<ItemBase*>&",
    "deletedItems",
    "otherDeletedItems",
    "QList<long>&",
    "deletedIDs",
    "isForeign",
    "makeDeleteItemCommandPrepSignal",
    "itemBase",
    "foreign",
    "makeDeleteItemCommandFinalSignal",
    "cursorLocationSignal",
    "xinches",
    "yinches",
    "width",
    "height",
    "ratsnestConnectSignal",
    "connectorID",
    "updatePartLabelInstanceTitleSignal",
    "filenameIfSignal",
    "QString&",
    "filename",
    "collectRatsnestSignal",
    "QList<SketchWidget*>&",
    "foreignSketchWidgets",
    "removeRatsnestSignal",
    "QList<ConnectorEdge*>&",
    "cutSet",
    "updateLayerMenuSignal",
    "swapBoardImageSignal",
    "sketchWidget",
    "moduleID",
    "addName",
    "canConnectSignal",
    "Wire*",
    "from",
    "to",
    "bool&",
    "swapStartSignal",
    "SwapThing&",
    "swapThing",
    "master",
    "showing",
    "clickedItemCandidateSignal",
    "QGraphicsItem*",
    "ok",
    "resizedSignal",
    "cleanupRatsnestsSignal",
    "addSubpartSignal",
    "subpartID",
    "getDroppedItemViewLayerPlacementSignal",
    "modelPart",
    "ViewLayer::ViewLayerPlacement&",
    "packItemsSignal",
    "columns",
    "QList<long>",
    "ids",
    "parent",
    "routingCheckSignal",
    "itemAddedSlot",
    "itemDeletedSlot",
    "clearSelectionSlot",
    "itemSelectedSlot",
    "selectionChangedSlot",
    "wireChangedSlot",
    "oldLine",
    "newLine",
    "oldPos",
    "newPos",
    "ConnectorItem*",
    "wireChangedCurveSlot",
    "const Bezier*",
    "oldB",
    "newB",
    "triggerFirstTime",
    "wireSplitSlot",
    "wireJoinSlot",
    "clickedConnectorItem",
    "toggleLayerVisibility",
    "wireConnectedSlot",
    "wireDisconnectedSlot",
    "changeConnectionSlot",
    "restartPasteCount",
    "dragIsDoneSlot",
    "ItemDrag*",
    "statusMessage",
    "message",
    "cleanUpWiresSlot",
    "updateInfoViewSlot",
    "spaceBarIsPressedSlot",
    "autoScrollTimeout",
    "dragAutoScrollTimeout",
    "moveAutoScrollTimeout",
    "rememberSticky",
    "copyBoundingRectsSlot",
    "deleteRatsnest",
    "deleteTracesSlot",
    "vScrollToZero",
    "arrowTimerTimeout",
    "makeDeleteItemCommandPrepSlot",
    "makeDeleteItemCommandFinalSlot",
    "updatePartLabelInstanceTitleSlot",
    "changePinLabelsSlot",
    "changePinLabels",
    "collectRatsnestSlot",
    "removeRatsnestSlot",
    "deleteTemporary",
    "canConnect",
    "swapStart",
    "getDroppedItemViewLayerPlacement",
    "changeWireColor",
    "newColor",
    "changeWireWidthMils",
    "newWidth",
    "selectAllItems",
    "setInstanceTitleForCommand",
    "checkStickyForCommand",
    "resizeBoard",
    "w",
    "h",
    "disconnectAllSlot",
    "setResistance",
    "setProp",
    "redraw",
    "propName",
    "translatedPropName",
    "oldValue",
    "newValue",
    "setHoleSize",
    "QRectF&",
    "oldRect",
    "newRect",
    "showLabelFirstTimeForCommand",
    "changeBoardLayers",
    "layers",
    "updateConnectors",
    "ratsnestConnectForCommand",
    "cleanupRatsnestsForCommand",
    "addSubpartForCommand",
    "subpartid",
    "packItemsForCommand",
    "gridColor",
    "ratsnestWidth",
    "ratsnestOpacity"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSSketchWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
     109,   14, // methods
       3, 1285, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      48,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    6,  668,    2, 0x06,    4 /* Public */,
      10,    1,  681,    2, 0x06,   11 /* Public */,
      11,    0,  684,    2, 0x06,   13 /* Public */,
      12,    2,  685,    2, 0x06,   14 /* Public */,
      14,    1,  690,    2, 0x06,   17 /* Public */,
      15,    2,  693,    2, 0x06,   19 /* Public */,
      18,    4,  698,    2, 0x06,   22 /* Public */,
      21,    7,  707,    2, 0x06,   27 /* Public */,
      24,    1,  722,    2, 0x06,   35 /* Public */,
      26,    1,  725,    2, 0x06,   37 /* Public */,
      28,    0,  728,    2, 0x06,   39 /* Public */,
      29,    0,  729,    2, 0x06,   40 /* Public */,
      30,    1,  730,    2, 0x06,   41 /* Public */,
      32,    2,  733,    2, 0x06,   43 /* Public */,
      34,    2,  738,    2, 0x06,   46 /* Public */,
      37,    2,  743,    2, 0x06,   49 /* Public */,
      39,    4,  748,    2, 0x06,   52 /* Public */,
      42,    3,  757,    2, 0x06,   57 /* Public */,
      46,    4,  764,    2, 0x06,   61 /* Public */,
      50,    5,  773,    2, 0x06,   66 /* Public */,
      54,    5,  784,    2, 0x06,   72 /* Public */,
      58,    2,  795,    2, 0x06,   78 /* Public */,
      60,    3,  800,    2, 0x06,   81 /* Public */,
      62,    1,  807,    2, 0x06,   85 /* Public */,
      63,    2,  810,    2, 0x06,   87 /* Public */,
      64,    5,  815,    2, 0x06,   90 /* Public */,
      71,    3,  826,    2, 0x06,   96 /* Public */,
      74,    3,  833,    2, 0x06,  100 /* Public */,
      75,    4,  840,    2, 0x06,  104 /* Public */,
      75,    3,  849,    2, 0x26,  109 /* Public | MethodCloned */,
      75,    2,  856,    2, 0x26,  113 /* Public | MethodCloned */,
      80,    4,  861,    2, 0x06,  116 /* Public */,
      82,    1,  870,    2, 0x06,  121 /* Public */,
      83,    1,  873,    2, 0x06,  123 /* Public */,
      86,    1,  876,    2, 0x06,  125 /* Public */,
      89,    2,  879,    2, 0x06,  127 /* Public */,
      92,    0,  884,    2, 0x06,  130 /* Public */,
      93,    5,  885,    2, 0x06,  131 /* Public */,
      97,    3,  896,    2, 0x06,  137 /* Public */,
     102,    2,  903,    2, 0x06,  141 /* Public */,
     106,    1,  908,    2, 0x06,  144 /* Public */,
     107,    2,  911,    2, 0x06,  146 /* Public */,
     110,    1,  916,    2, 0x06,  149 /* Public */,
     111,    1,  919,    2, 0x06,  151 /* Public */,
     112,    3,  922,    2, 0x06,  153 /* Public */,
     114,    2,  929,    2, 0x06,  157 /* Public */,
     117,    4,  934,    2, 0x06,  160 /* Public */,
     122,    0,  943,    2, 0x06,  165 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
     123,    6,  944,    2, 0x09,  166 /* Protected */,
     124,    1,  957,    2, 0x09,  173 /* Protected */,
     125,    0,  960,    2, 0x09,  175 /* Protected */,
     126,    2,  961,    2, 0x09,  176 /* Protected */,
     127,    0,  966,    2, 0x09,  179 /* Protected */,
     128,    7,  967,    2, 0x09,  180 /* Protected */,
     134,    4,  982,    2, 0x09,  188 /* Protected */,
     139,    4,  991,    2, 0x09,  193 /* Protected */,
     140,    2, 1000,    2, 0x09,  198 /* Protected */,
     142,    0, 1005,    2, 0x09,  201 /* Protected */,
     143,    4, 1006,    2, 0x09,  202 /* Protected */,
     144,    2, 1015,    2, 0x09,  207 /* Protected */,
     145,    7, 1020,    2, 0x09,  210 /* Protected */,
     146,    0, 1035,    2, 0x09,  218 /* Protected */,
     147,    1, 1036,    2, 0x09,  219 /* Protected */,
     149,    2, 1039,    2, 0x09,  221 /* Protected */,
     149,    1, 1044,    2, 0x29,  224 /* Protected | MethodCloned */,
     151,    1, 1047,    2, 0x09,  226 /* Protected */,
     152,    0, 1050,    2, 0x09,  228 /* Protected */,
     153,    1, 1051,    2, 0x09,  229 /* Protected */,
     154,    0, 1054,    2, 0x09,  231 /* Protected */,
     155,    0, 1055,    2, 0x09,  232 /* Protected */,
     156,    0, 1056,    2, 0x09,  233 /* Protected */,
     157,    2, 1057,    2, 0x09,  234 /* Protected */,
     157,    2, 1062,    2, 0x09,  237 /* Protected */,
     158,    1, 1067,    2, 0x09,  240 /* Protected */,
     159,    2, 1070,    2, 0x09,  242 /* Protected */,
     160,    5, 1075,    2, 0x09,  245 /* Protected */,
     161,    0, 1086,    2, 0x09,  251 /* Protected */,
     162,    0, 1087,    2, 0x09,  252 /* Protected */,
     163,    3, 1088,    2, 0x09,  253 /* Protected */,
     164,    3, 1095,    2, 0x09,  257 /* Protected */,
     165,    1, 1102,    2, 0x09,  261 /* Protected */,
     166,    1, 1105,    2, 0x09,  263 /* Protected */,
     167,    1, 1108,    2, 0x09,  265 /* Protected */,
     168,    1, 1111,    2, 0x09,  267 /* Protected */,
     169,    2, 1114,    2, 0x09,  269 /* Protected */,
     170,    0, 1119,    2, 0x09,  272 /* Protected */,
     171,    3, 1120,    2, 0x09,  273 /* Protected */,
     172,    2, 1127,    2, 0x09,  277 /* Protected */,
     173,    2, 1132,    2, 0x09,  280 /* Protected */,
     174,    1, 1137,    2, 0x0a,  283 /* Public */,
     176,    1, 1140,    2, 0x0a,  285 /* Public */,
     178,    2, 1143,    2, 0x0a,  287 /* Public */,
     179,    5, 1148,    2, 0x0a,  290 /* Public */,
     180,    4, 1159,    2, 0x0a,  296 /* Public */,
     181,    3, 1168,    2, 0x0a,  301 /* Public */,
     184,    3, 1175,    2, 0x0a,  305 /* Public */,
     185,    4, 1182,    2, 0x0a,  309 /* Public */,
     185,    2, 1191,    2, 0x0a,  314 /* Public */,
     186,    5, 1196,    2, 0x0a,  317 /* Public */,
     186,    6, 1207,    2, 0x0a,  323 /* Public */,
     192,    8, 1220,    2, 0x0a,  330 /* Public */,
     196,    3, 1237,    2, 0x0a,  339 /* Public */,
     181,    3, 1244,    2, 0x0a,  343 /* Public */,
     197,    2, 1251,    2, 0x0a,  347 /* Public */,
     199,    0, 1256,    2, 0x0a,  350 /* Public */,
     200,    4, 1257,    2, 0x0a,  351 /* Public */,
     201,    1, 1266,    2, 0x0a,  356 /* Public */,
     202,    3, 1269,    2, 0x0a,  358 /* Public */,
     204,    4, 1276,    2, 0x0a,  362 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 4, 0x80000000 | 5, 0x80000000 | 6, QMetaType::Long, 0x80000000 | 8,    2,    2,    2,    2,    7,    9,
    QMetaType::Void, QMetaType::Long,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Long, QMetaType::Bool,    7,   13,
    QMetaType::Void, 0x80000000 | 4,    2,
    QMetaType::Void, QMetaType::Long, QMetaType::QString,   16,   17,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::Long, QMetaType::QString,   16,   17,   19,   20,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::Long, QMetaType::QString, 0x80000000 | 5, QMetaType::Bool, QMetaType::Bool,   16,   17,   19,   20,    2,   22,   23,
    QMetaType::Void, 0x80000000 | 25,    2,
    QMetaType::Void, 0x80000000 | 27,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   31,
    QMetaType::Void, 0x80000000 | 8, 0x80000000 | 33,    2,    2,
    QMetaType::Void, 0x80000000 | 8, 0x80000000 | 35,    2,   36,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,   13,   38,
    QMetaType::Void, QMetaType::Long, QMetaType::Bool, QMetaType::Bool, 0x80000000 | 41,    7,   38,   40,    2,
    QMetaType::Void, 0x80000000 | 43, 0x80000000 | 44, 0x80000000 | 35,    2,   45,   36,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::QString, QMetaType::Bool,   47,   48,   49,   38,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::QString, QMetaType::Bool, QMetaType::Bool,   47,   51,   52,   53,   38,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::QString, QMetaType::Bool, QMetaType::Bool,    7,   55,   56,   57,   38,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,   59,
    QMetaType::Void, QMetaType::Long, QMetaType::Bool, QMetaType::Bool,   47,   61,   38,
    QMetaType::Void, 0x80000000 | 8,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,    2,   38,
    QMetaType::Void, 0x80000000 | 65, 0x80000000 | 44, 0x80000000 | 68, QMetaType::Bool, 0x80000000 | 35,   66,   67,   69,   70,   36,
    QMetaType::Void, 0x80000000 | 4, QMetaType::Bool, 0x80000000 | 35,   72,   73,   36,
    QMetaType::Void, 0x80000000 | 4, QMetaType::Bool, 0x80000000 | 35,   72,   73,   36,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double,   76,   77,   78,   79,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,   76,   77,   78,
    QMetaType::Void, QMetaType::Double, QMetaType::Double,   76,   77,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::Bool, QMetaType::Bool,    7,   81,   22,   38,
    QMetaType::Void, QMetaType::Long,   47,
    QMetaType::Void, 0x80000000 | 84,   85,
    QMetaType::Void, 0x80000000 | 87,   88,
    QMetaType::Void, 0x80000000 | 90, 0x80000000 | 35,   91,   36,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8, 0x80000000 | 4, QMetaType::QString, QMetaType::QString, QMetaType::Bool,   94,   72,   85,   95,   96,
    QMetaType::Void, 0x80000000 | 98, 0x80000000 | 4, 0x80000000 | 101,   99,  100,   22,
    QMetaType::Void, 0x80000000 | 103, QMetaType::Bool,  104,  105,
    QMetaType::Void, 0x80000000 | 8,    2,
    QMetaType::Void, 0x80000000 | 108, 0x80000000 | 101,    2,  109,
    QMetaType::Void, 0x80000000 | 4,    2,
    QMetaType::Void, QMetaType::Bool,   38,
    QMetaType::Void, QMetaType::Long, QMetaType::Long, QMetaType::Bool,    7,  113,   38,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 116,  115,    2,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 119, 0x80000000 | 35, QMetaType::Bool,  118,  120,  121,   38,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 4, 0x80000000 | 5, 0x80000000 | 6, QMetaType::Long, 0x80000000 | 8,    2,    2,    2,    2,    7,    9,
    QMetaType::Void, QMetaType::Long,    7,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Long, QMetaType::Bool,    7,   13,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 98, QMetaType::QLineF, QMetaType::QLineF, QMetaType::QPointF, QMetaType::QPointF, 0x80000000 | 133, 0x80000000 | 133,    2,  129,  130,  131,  132,   99,  100,
    QMetaType::Void, 0x80000000 | 98, 0x80000000 | 135, 0x80000000 | 135, QMetaType::Bool,    2,  136,  137,  138,
    QMetaType::Void, 0x80000000 | 98, QMetaType::QPointF, QMetaType::QPointF, QMetaType::QLineF,    2,  132,  131,  129,
    QMetaType::Void, 0x80000000 | 98, 0x80000000 | 133,    2,  141,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::Long, QMetaType::QString,   16,   17,   19,   20,
    QMetaType::Void, QMetaType::Long, QMetaType::QString,   16,   17,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::Long, QMetaType::QString, 0x80000000 | 5, QMetaType::Bool, QMetaType::Bool,   16,   17,   19,   20,    2,   22,   23,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 148,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,  150,   59,
    QMetaType::Void, QMetaType::QString,  150,
    QMetaType::Void, 0x80000000 | 27,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Long, 0x80000000 | 35,    7,   36,
    QMetaType::Void, 0x80000000 | 4, 0x80000000 | 35,    2,   36,
    QMetaType::Void, 0x80000000 | 25,    2,
    QMetaType::Void, 0x80000000 | 98, 0x80000000 | 35,    2,   36,
    QMetaType::Void, 0x80000000 | 65, 0x80000000 | 44, 0x80000000 | 68, QMetaType::Bool, 0x80000000 | 35,   66,   67,   69,   70,   36,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4, QMetaType::Bool, 0x80000000 | 35,   72,   73,   36,
    QMetaType::Void, 0x80000000 | 4, QMetaType::Bool, 0x80000000 | 35,   72,   73,   36,
    QMetaType::Void, QMetaType::Long,   47,
    QMetaType::Void, 0x80000000 | 4,   72,
    QMetaType::Void, 0x80000000 | 4,    2,
    QMetaType::Void, 0x80000000 | 87,   88,
    QMetaType::Void, 0x80000000 | 90, 0x80000000 | 35,   91,   36,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 98, 0x80000000 | 4, 0x80000000 | 101,   99,  100,   22,
    QMetaType::Long, 0x80000000 | 103, QMetaType::Bool,  104,  105,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 116,  115,    2,
    QMetaType::Void, QMetaType::QString,  175,
    QMetaType::Void, QMetaType::QString,  177,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool,   13,   38,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::QString, QMetaType::Bool, QMetaType::Bool,    7,   55,   56,   57,   38,
    QMetaType::Void, QMetaType::Long, QMetaType::Bool, QMetaType::Bool, 0x80000000 | 41,    7,   38,   40,    2,
    0x80000000 | 4, QMetaType::Long, QMetaType::Double, QMetaType::Double,    7,  182,  183,
    QMetaType::Void, 0x80000000 | 43, 0x80000000 | 44, 0x80000000 | 35,    2,   45,   36,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::QString, QMetaType::Bool,   47,   48,   49,   38,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   48,   49,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::QString, QMetaType::Bool, QMetaType::Bool,   47,   51,   52,  187,   38,
    QMetaType::Void, 0x80000000 | 4, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    2,  188,  189,  190,  191,  187,
    QMetaType::Void, 0x80000000 | 4, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::QString, 0x80000000 | 193, 0x80000000 | 193, QMetaType::Bool,    2,  188,  189,  190,  191,  194,  195,  187,
    QMetaType::Void, QMetaType::Long, QMetaType::Bool, QMetaType::Bool,   47,   61,   38,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Bool,  182,  183,   38,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,  198,   38,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::Bool, QMetaType::Bool,    7,   81,   22,   38,
    QMetaType::Void, QMetaType::Bool,   38,
    QMetaType::Void, QMetaType::Long, QMetaType::Long, QMetaType::Bool,    7,  203,   38,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 119, 0x80000000 | 35, QMetaType::Bool,  118,  120,  121,   38,

 // properties: name, type, flags
     205, QMetaType::QColor, 0x00015103, uint(-1), 0,
     206, QMetaType::Double, 0x00015103, uint(-1), 0,
     207, QMetaType::Double, 0x00015103, uint(-1), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject SketchWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<InfoGraphicsView::staticMetaObject>(),
    qt_meta_stringdata_CLASSSketchWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSSketchWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSSketchWidgetENDCLASS_t,
        // property 'gridColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'ratsnestWidth'
        QtPrivate::TypeAndForceComplete<double, std::true_type>,
        // property 'ratsnestOpacity'
        QtPrivate::TypeAndForceComplete<double, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<SketchWidget, std::true_type>,
        // method 'itemAddedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement, std::false_type>,
        QtPrivate::TypeAndForceComplete<const ViewGeometry &, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        // method 'itemDeletedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        // method 'clearSelectionSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'itemSelectedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'itemMovedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        // method 'wireDisconnectedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'wireConnectedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'changeConnectionSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'copyBoundingRectsSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QHash<QString,QRectF> &, std::false_type>,
        // method 'cleanUpWiresSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<CleanUpWiresCommand *, std::false_type>,
        // method 'selectionChangedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'resizeSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dropSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>,
        // method 'routingStatusSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const RoutingStatus &, std::false_type>,
        // method 'movingSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'selectAllItemsSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'checkStickySignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<CheckStickyCommand *, std::false_type>,
        // method 'disconnectAllSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<ConnectorItem*>, std::false_type>,
        QtPrivate::TypeAndForceComplete<QHash<ItemBase*,SketchWidget*> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'setResistanceSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setPropSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setInstanceTitleSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'statusMessageSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'showLabelFirstTimeSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'dropPasteSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        // method 'changeBoardLayersSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'deleteTracesSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QSet<ItemBase*> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QHash<ItemBase*,SketchWidget*> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<long> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'makeDeleteItemCommandPrepSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'makeDeleteItemCommandFinalSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'cursorLocationSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'cursorLocationSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'cursorLocationSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'ratsnestConnectSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'updatePartLabelInstanceTitleSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        // method 'filenameIfSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        // method 'collectRatsnestSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<SketchWidget*> &, std::false_type>,
        // method 'removeRatsnestSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<struct ConnectorEdge*> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'updateLayerMenuSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'swapBoardImageSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'canConnectSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool &, std::false_type>,
        // method 'swapStartSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SwapThing &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'showing'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        // method 'clickedItemCandidateSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QGraphicsItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool &, std::false_type>,
        // method 'resizedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        // method 'cleanupRatsnestsSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'addSubpartSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'getDroppedItemViewLayerPlacementSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement &, std::false_type>,
        // method 'packItemsSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QList<long> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'routingCheckSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'itemAddedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement, std::false_type>,
        QtPrivate::TypeAndForceComplete<const ViewGeometry &, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<SketchWidget *, std::false_type>,
        // method 'itemDeletedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        // method 'clearSelectionSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'itemSelectedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'selectionChangedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'wireChangedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QLineF &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QLineF &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        // method 'wireChangedCurveSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Bezier *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Bezier *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'wireSplitSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPointF, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QLineF &, std::false_type>,
        // method 'wireJoinSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        // method 'toggleLayerVisibility'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'wireConnectedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'wireDisconnectedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'changeConnectionSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'restartPasteCount'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dragIsDoneSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemDrag *, std::false_type>,
        // method 'statusMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'statusMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'cleanUpWiresSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<CleanUpWiresCommand *, std::false_type>,
        // method 'updateInfoViewSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'spaceBarIsPressedSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'autoScrollTimeout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dragAutoScrollTimeout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'moveAutoScrollTimeout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rememberSticky'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'rememberSticky'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'copyBoundingRectsSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QHash<QString,QRectF> &, std::false_type>,
        // method 'deleteRatsnest'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'deleteTracesSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QSet<ItemBase*> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QHash<ItemBase*,SketchWidget*> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<long> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'vScrollToZero'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'arrowTimerTimeout'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'makeDeleteItemCommandPrepSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'makeDeleteItemCommandFinalSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'updatePartLabelInstanceTitleSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        // method 'changePinLabelsSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        // method 'changePinLabels'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        // method 'collectRatsnestSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<SketchWidget*> &, std::false_type>,
        // method 'removeRatsnestSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<struct ConnectorEdge*> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'deleteTemporary'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'canConnect'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool &, std::false_type>,
        // method 'swapStart'
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<SwapThing &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'getDroppedItemViewLayerPlacement'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelPart *, std::false_type>,
        QtPrivate::TypeAndForceComplete<ViewLayer::ViewLayerPlacement &, std::false_type>,
        // method 'changeWireColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString, std::false_type>,
        // method 'changeWireWidthMils'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString, std::false_type>,
        // method 'selectAllItems'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setInstanceTitleForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'checkStickyForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<CheckStickyCommand *, std::false_type>,
        // method 'resizeBoard'
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        // method 'disconnectAllSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QList<ConnectorItem*>, std::false_type>,
        QtPrivate::TypeAndForceComplete<QHash<ItemBase*,SketchWidget*> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        // method 'setResistance'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setResistance'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'setProp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setProp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setHoleSize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QRectF &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QRectF &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'showLabelFirstTimeForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'resizeBoard'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'changeBoardLayers'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'updateConnectors'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'ratsnestConnectForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'cleanupRatsnestsForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'addSubpartForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'packItemsForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QList<long> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QUndoCommand *, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>
    >,
    nullptr
} };

void SketchWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SketchWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->itemAddedSignal((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<ViewGeometry>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<long>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[6]))); break;
        case 1: _t->itemDeletedSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1]))); break;
        case 2: _t->clearSelectionSignal(); break;
        case 3: _t->itemSelectedSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 4: _t->itemMovedSignal((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1]))); break;
        case 5: _t->wireDisconnectedSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 6: _t->wireConnectedSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<long>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4]))); break;
        case 7: _t->changeConnectionSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<long>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[7]))); break;
        case 8: _t->copyBoundingRectsSignal((*reinterpret_cast< std::add_pointer_t<QHash<QString,QRectF>&>>(_a[1]))); break;
        case 9: _t->cleanUpWiresSignal((*reinterpret_cast< std::add_pointer_t<CleanUpWiresCommand*>>(_a[1]))); break;
        case 10: _t->selectionChangedSignal(); break;
        case 11: _t->resizeSignal(); break;
        case 12: _t->dropSignal((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 13: _t->routingStatusSignal((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<RoutingStatus>>(_a[2]))); break;
        case 14: _t->movingSignal((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[2]))); break;
        case 15: _t->selectAllItemsSignal((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 16: _t->checkStickySignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<CheckStickyCommand*>>(_a[4]))); break;
        case 17: _t->disconnectAllSignal((*reinterpret_cast< std::add_pointer_t<QList<ConnectorItem*>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QHash<ItemBase*,SketchWidget*>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[3]))); break;
        case 18: _t->setResistanceSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 19: _t->setPropSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5]))); break;
        case 20: _t->setInstanceTitleSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5]))); break;
        case 21: _t->statusMessageSignal((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 22: _t->showLabelFirstTimeSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 23: _t->dropPasteSignal((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1]))); break;
        case 24: _t->changeBoardLayersSignal((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 25: _t->deleteTracesSignal((*reinterpret_cast< std::add_pointer_t<QSet<ItemBase*>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QHash<ItemBase*,SketchWidget*>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QList<long>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[5]))); break;
        case 26: _t->makeDeleteItemCommandPrepSignal((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[3]))); break;
        case 27: _t->makeDeleteItemCommandFinalSignal((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[3]))); break;
        case 28: _t->cursorLocationSignal((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[4]))); break;
        case 29: _t->cursorLocationSignal((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[3]))); break;
        case 30: _t->cursorLocationSignal((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2]))); break;
        case 31: _t->ratsnestConnectSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 32: _t->updatePartLabelInstanceTitleSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1]))); break;
        case 33: _t->filenameIfSignal((*reinterpret_cast< std::add_pointer_t<QString&>>(_a[1]))); break;
        case 34: _t->collectRatsnestSignal((*reinterpret_cast< std::add_pointer_t<QList<SketchWidget*>&>>(_a[1]))); break;
        case 35: _t->removeRatsnestSignal((*reinterpret_cast< std::add_pointer_t<QList<ConnectorEdge*>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[2]))); break;
        case 36: _t->updateLayerMenuSignal(); break;
        case 37: _t->swapBoardImageSignal((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5]))); break;
        case 38: _t->canConnectSignal((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool&>>(_a[3]))); break;
        case 39: _t->swapStartSignal((*reinterpret_cast< std::add_pointer_t<SwapThing&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 40: _t->showing((*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[1]))); break;
        case 41: _t->clickedItemCandidateSignal((*reinterpret_cast< std::add_pointer_t<QGraphicsItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool&>>(_a[2]))); break;
        case 42: _t->resizedSignal((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1]))); break;
        case 43: _t->cleanupRatsnestsSignal((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 44: _t->addSubpartSignal((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<long>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 45: _t->getDroppedItemViewLayerPlacementSignal((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement&>>(_a[2]))); break;
        case 46: _t->packItemsSignal((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<long>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 47: _t->routingCheckSignal(); break;
        case 48: _t->itemAddedSlot((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<ViewGeometry>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<long>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<SketchWidget*>>(_a[6]))); break;
        case 49: _t->itemDeletedSlot((*reinterpret_cast< std::add_pointer_t<long>>(_a[1]))); break;
        case 50: _t->clearSelectionSlot(); break;
        case 51: _t->itemSelectedSlot((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 52: _t->selectionChangedSlot(); break;
        case 53: _t->wireChangedSlot((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QLineF>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QLineF>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[7]))); break;
        case 54: _t->wireChangedCurveSlot((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<const Bezier*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<const Bezier*>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 55: _t->wireSplitSlot((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QPointF>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QLineF>>(_a[4]))); break;
        case 56: _t->wireJoinSlot((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[2]))); break;
        case 57: _t->toggleLayerVisibility(); break;
        case 58: _t->wireConnectedSlot((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<long>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4]))); break;
        case 59: _t->wireDisconnectedSlot((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 60: _t->changeConnectionSlot((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<long>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[7]))); break;
        case 61: _t->restartPasteCount(); break;
        case 62: _t->dragIsDoneSlot((*reinterpret_cast< std::add_pointer_t<ItemDrag*>>(_a[1]))); break;
        case 63: _t->statusMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 64: _t->statusMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 65: _t->cleanUpWiresSlot((*reinterpret_cast< std::add_pointer_t<CleanUpWiresCommand*>>(_a[1]))); break;
        case 66: _t->updateInfoViewSlot(); break;
        case 67: _t->spaceBarIsPressedSlot((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 68: _t->autoScrollTimeout(); break;
        case 69: _t->dragAutoScrollTimeout(); break;
        case 70: _t->moveAutoScrollTimeout(); break;
        case 71: _t->rememberSticky((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[2]))); break;
        case 72: _t->rememberSticky((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[2]))); break;
        case 73: _t->copyBoundingRectsSlot((*reinterpret_cast< std::add_pointer_t<QHash<QString,QRectF>&>>(_a[1]))); break;
        case 74: _t->deleteRatsnest((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[2]))); break;
        case 75: _t->deleteTracesSlot((*reinterpret_cast< std::add_pointer_t<QSet<ItemBase*>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QHash<ItemBase*,SketchWidget*>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QList<long>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[5]))); break;
        case 76: _t->vScrollToZero(); break;
        case 77: _t->arrowTimerTimeout(); break;
        case 78: _t->makeDeleteItemCommandPrepSlot((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[3]))); break;
        case 79: _t->makeDeleteItemCommandFinalSlot((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[3]))); break;
        case 80: _t->updatePartLabelInstanceTitleSlot((*reinterpret_cast< std::add_pointer_t<long>>(_a[1]))); break;
        case 81: _t->changePinLabelsSlot((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1]))); break;
        case 82: _t->changePinLabels((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1]))); break;
        case 83: _t->collectRatsnestSlot((*reinterpret_cast< std::add_pointer_t<QList<SketchWidget*>&>>(_a[1]))); break;
        case 84: _t->removeRatsnestSlot((*reinterpret_cast< std::add_pointer_t<QList<ConnectorEdge*>&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[2]))); break;
        case 85: _t->deleteTemporary(); break;
        case 86: _t->canConnect((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool&>>(_a[3]))); break;
        case 87: { long _r = _t->swapStart((*reinterpret_cast< std::add_pointer_t<SwapThing&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])));
            if (_a[0]) *reinterpret_cast< long*>(_a[0]) = std::move(_r); }  break;
        case 88: _t->getDroppedItemViewLayerPlacement((*reinterpret_cast< std::add_pointer_t<ModelPart*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<ViewLayer::ViewLayerPlacement&>>(_a[2]))); break;
        case 89: _t->changeWireColor((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 90: _t->changeWireWidthMils((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 91: _t->selectAllItems((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 92: _t->setInstanceTitleForCommand((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5]))); break;
        case 93: _t->checkStickyForCommand((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<CheckStickyCommand*>>(_a[4]))); break;
        case 94: { ItemBase* _r = _t->resizeBoard((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[3])));
            if (_a[0]) *reinterpret_cast< ItemBase**>(_a[0]) = std::move(_r); }  break;
        case 95: _t->disconnectAllSlot((*reinterpret_cast< std::add_pointer_t<QList<ConnectorItem*>>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QHash<ItemBase*,SketchWidget*>&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[3]))); break;
        case 96: _t->setResistance((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 97: _t->setResistance((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 98: _t->setProp((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5]))); break;
        case 99: _t->setProp((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[6]))); break;
        case 100: _t->setHoleSize((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[5])),(*reinterpret_cast< std::add_pointer_t<QRectF&>>(_a[6])),(*reinterpret_cast< std::add_pointer_t<QRectF&>>(_a[7])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[8]))); break;
        case 101: _t->showLabelFirstTimeForCommand((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 102: _t->resizeBoard((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 103: _t->changeBoardLayers((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 104: _t->updateConnectors(); break;
        case 105: _t->ratsnestConnectForCommand((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 106: _t->cleanupRatsnestsForCommand((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 107: _t->addSubpartForCommand((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<long>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 108: _t->packItemsForCommand((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QList<long>>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QUndoCommand*>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            case 5:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 13:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 14:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 17:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<ConnectorItem*> >(); break;
            }
            break;
        case 23:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 26:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 27:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 37:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 38:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 40:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 41:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QGraphicsItem* >(); break;
            }
            break;
        case 42:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 45:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            }
            break;
        case 46:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<long> >(); break;
            }
            break;
        case 48:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            case 5:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< SketchWidget* >(); break;
            }
            break;
        case 53:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 6:
            case 5:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ConnectorItem* >(); break;
            }
            break;
        case 56:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ConnectorItem* >(); break;
            }
            break;
        case 72:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 78:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 79:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 81:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 82:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 86:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 88:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ModelPart* >(); break;
            }
            break;
        case 95:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<ConnectorItem*> >(); break;
            }
            break;
        case 99:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 100:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 108:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<long> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SketchWidget::*)(ModelPart * , ItemBase * , ViewLayer::ViewLayerPlacement , const ViewGeometry & , long , SketchWidget * );
            if (_t _q_method = &SketchWidget::itemAddedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long );
            if (_t _q_method = &SketchWidget::itemDeletedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)();
            if (_t _q_method = &SketchWidget::clearSelectionSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , bool );
            if (_t _q_method = &SketchWidget::itemSelectedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(ItemBase * );
            if (_t _q_method = &SketchWidget::itemMovedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , QString );
            if (_t _q_method = &SketchWidget::wireDisconnectedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , QString , long , QString );
            if (_t _q_method = &SketchWidget::wireConnectedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , QString , long , QString , ViewLayer::ViewLayerPlacement , bool , bool );
            if (_t _q_method = &SketchWidget::changeConnectionSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(QHash<QString,QRectF> & );
            if (_t _q_method = &SketchWidget::copyBoundingRectsSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(CleanUpWiresCommand * );
            if (_t _q_method = &SketchWidget::cleanUpWiresSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)();
            if (_t _q_method = &SketchWidget::selectionChangedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)();
            if (_t _q_method = &SketchWidget::resizeSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(const QPoint & );
            if (_t _q_method = &SketchWidget::dropSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(SketchWidget * , const RoutingStatus & );
            if (_t _q_method = &SketchWidget::routingStatusSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(SketchWidget * , QUndoCommand * );
            if (_t _q_method = &SketchWidget::movingSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(bool , bool );
            if (_t _q_method = &SketchWidget::selectAllItemsSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , bool , bool , CheckStickyCommand * );
            if (_t _q_method = &SketchWidget::checkStickySignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(QList<ConnectorItem*> , QHash<ItemBase*,SketchWidget*> & , QUndoCommand * );
            if (_t _q_method = &SketchWidget::disconnectAllSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , QString , QString , bool );
            if (_t _q_method = &SketchWidget::setResistanceSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , const QString & , const QString & , bool , bool );
            if (_t _q_method = &SketchWidget::setPropSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , const QString & , const QString & , bool , bool );
            if (_t _q_method = &SketchWidget::setInstanceTitleSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(QString , int );
            if (_t _q_method = &SketchWidget::statusMessageSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , bool , bool );
            if (_t _q_method = &SketchWidget::showLabelFirstTimeSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(SketchWidget * );
            if (_t _q_method = &SketchWidget::dropPasteSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 23;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(int , bool );
            if (_t _q_method = &SketchWidget::changeBoardLayersSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 24;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(QSet<ItemBase*> & , QHash<ItemBase*,SketchWidget*> & , QList<long> & , bool , QUndoCommand * );
            if (_t _q_method = &SketchWidget::deleteTracesSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 25;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(ItemBase * , bool , QUndoCommand * );
            if (_t _q_method = &SketchWidget::makeDeleteItemCommandPrepSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 26;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(ItemBase * , bool , QUndoCommand * );
            if (_t _q_method = &SketchWidget::makeDeleteItemCommandFinalSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 27;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(double , double , double , double );
            if (_t _q_method = &SketchWidget::cursorLocationSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 28;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , const QString & , bool , bool );
            if (_t _q_method = &SketchWidget::ratsnestConnectSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 31;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long );
            if (_t _q_method = &SketchWidget::updatePartLabelInstanceTitleSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 32;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(QString & );
            if (_t _q_method = &SketchWidget::filenameIfSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 33;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(QList<SketchWidget*> & );
            if (_t _q_method = &SketchWidget::collectRatsnestSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 34;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(QList<struct ConnectorEdge*> & , QUndoCommand * );
            if (_t _q_method = &SketchWidget::removeRatsnestSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 35;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)();
            if (_t _q_method = &SketchWidget::updateLayerMenuSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 36;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(SketchWidget * , ItemBase * , const QString & , const QString & , bool );
            if (_t _q_method = &SketchWidget::swapBoardImageSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 37;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(Wire * , ItemBase * , bool & );
            if (_t _q_method = &SketchWidget::canConnectSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 38;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(SwapThing & , bool );
            if (_t _q_method = &SketchWidget::swapStartSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 39;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(SketchWidget * );
            if (_t _q_method = &SketchWidget::showing; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 40;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(QGraphicsItem * , bool & );
            if (_t _q_method = &SketchWidget::clickedItemCandidateSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 41;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(ItemBase * );
            if (_t _q_method = &SketchWidget::resizedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 42;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(bool );
            if (_t _q_method = &SketchWidget::cleanupRatsnestsSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 43;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(long , long , bool );
            if (_t _q_method = &SketchWidget::addSubpartSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 44;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(ModelPart * , ViewLayer::ViewLayerPlacement & );
            if (_t _q_method = &SketchWidget::getDroppedItemViewLayerPlacementSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 45;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)(int , const QList<long> & , QUndoCommand * , bool );
            if (_t _q_method = &SketchWidget::packItemsSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 46;
                return;
            }
        }
        {
            using _t = void (SketchWidget::*)();
            if (_t _q_method = &SketchWidget::routingCheckSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 47;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<SketchWidget *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->gridColor(); break;
        case 1: *reinterpret_cast< double*>(_v) = _t->ratsnestWidth(); break;
        case 2: *reinterpret_cast< double*>(_v) = _t->ratsnestOpacity(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<SketchWidget *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setGridColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setRatsnestWidth(*reinterpret_cast< double*>(_v)); break;
        case 2: _t->setRatsnestOpacity(*reinterpret_cast< double*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *SketchWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SketchWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSSketchWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return InfoGraphicsView::qt_metacast(_clname);
}

int SketchWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = InfoGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 109)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 109;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 109)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 109;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void SketchWidget::itemAddedSignal(ModelPart * _t1, ItemBase * _t2, ViewLayer::ViewLayerPlacement _t3, const ViewGeometry & _t4, long _t5, SketchWidget * _t6)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SketchWidget::itemDeletedSignal(long _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SketchWidget::clearSelectionSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void SketchWidget::itemSelectedSignal(long _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void SketchWidget::itemMovedSignal(ItemBase * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SketchWidget::wireDisconnectedSignal(long _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void SketchWidget::wireConnectedSignal(long _t1, QString _t2, long _t3, QString _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void SketchWidget::changeConnectionSignal(long _t1, QString _t2, long _t3, QString _t4, ViewLayer::ViewLayerPlacement _t5, bool _t6, bool _t7)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t6))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t7))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void SketchWidget::copyBoundingRectsSignal(QHash<QString,QRectF> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void SketchWidget::cleanUpWiresSignal(CleanUpWiresCommand * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void SketchWidget::selectionChangedSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void SketchWidget::resizeSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void SketchWidget::dropSignal(const QPoint & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void SketchWidget::routingStatusSignal(SketchWidget * _t1, const RoutingStatus & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void SketchWidget::movingSignal(SketchWidget * _t1, QUndoCommand * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void SketchWidget::selectAllItemsSignal(bool _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void SketchWidget::checkStickySignal(long _t1, bool _t2, bool _t3, CheckStickyCommand * _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void SketchWidget::disconnectAllSignal(QList<ConnectorItem*> _t1, QHash<ItemBase*,SketchWidget*> & _t2, QUndoCommand * _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void SketchWidget::setResistanceSignal(long _t1, QString _t2, QString _t3, bool _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void SketchWidget::setPropSignal(long _t1, const QString & _t2, const QString & _t3, bool _t4, bool _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void SketchWidget::setInstanceTitleSignal(long _t1, const QString & _t2, const QString & _t3, bool _t4, bool _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void SketchWidget::statusMessageSignal(QString _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 21, _a);
}

// SIGNAL 22
void SketchWidget::showLabelFirstTimeSignal(long _t1, bool _t2, bool _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 22, _a);
}

// SIGNAL 23
void SketchWidget::dropPasteSignal(SketchWidget * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 23, _a);
}

// SIGNAL 24
void SketchWidget::changeBoardLayersSignal(int _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 24, _a);
}

// SIGNAL 25
void SketchWidget::deleteTracesSignal(QSet<ItemBase*> & _t1, QHash<ItemBase*,SketchWidget*> & _t2, QList<long> & _t3, bool _t4, QUndoCommand * _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 25, _a);
}

// SIGNAL 26
void SketchWidget::makeDeleteItemCommandPrepSignal(ItemBase * _t1, bool _t2, QUndoCommand * _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 26, _a);
}

// SIGNAL 27
void SketchWidget::makeDeleteItemCommandFinalSignal(ItemBase * _t1, bool _t2, QUndoCommand * _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 27, _a);
}

// SIGNAL 28
void SketchWidget::cursorLocationSignal(double _t1, double _t2, double _t3, double _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 28, _a);
}

// SIGNAL 31
void SketchWidget::ratsnestConnectSignal(long _t1, const QString & _t2, bool _t3, bool _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 31, _a);
}

// SIGNAL 32
void SketchWidget::updatePartLabelInstanceTitleSignal(long _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 32, _a);
}

// SIGNAL 33
void SketchWidget::filenameIfSignal(QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 33, _a);
}

// SIGNAL 34
void SketchWidget::collectRatsnestSignal(QList<SketchWidget*> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 34, _a);
}

// SIGNAL 35
void SketchWidget::removeRatsnestSignal(QList<struct ConnectorEdge*> & _t1, QUndoCommand * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 35, _a);
}

// SIGNAL 36
void SketchWidget::updateLayerMenuSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 36, nullptr);
}

// SIGNAL 37
void SketchWidget::swapBoardImageSignal(SketchWidget * _t1, ItemBase * _t2, const QString & _t3, const QString & _t4, bool _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t5))) };
    QMetaObject::activate(this, &staticMetaObject, 37, _a);
}

// SIGNAL 38
void SketchWidget::canConnectSignal(Wire * _t1, ItemBase * _t2, bool & _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 38, _a);
}

// SIGNAL 39
void SketchWidget::swapStartSignal(SwapThing & _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 39, _a);
}

// SIGNAL 40
void SketchWidget::showing(SketchWidget * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 40, _a);
}

// SIGNAL 41
void SketchWidget::clickedItemCandidateSignal(QGraphicsItem * _t1, bool & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 41, _a);
}

// SIGNAL 42
void SketchWidget::resizedSignal(ItemBase * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 42, _a);
}

// SIGNAL 43
void SketchWidget::cleanupRatsnestsSignal(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 43, _a);
}

// SIGNAL 44
void SketchWidget::addSubpartSignal(long _t1, long _t2, bool _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 44, _a);
}

// SIGNAL 45
void SketchWidget::getDroppedItemViewLayerPlacementSignal(ModelPart * _t1, ViewLayer::ViewLayerPlacement & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 45, _a);
}

// SIGNAL 46
void SketchWidget::packItemsSignal(int _t1, const QList<long> & _t2, QUndoCommand * _t3, bool _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 46, _a);
}

// SIGNAL 47
void SketchWidget::routingCheckSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 47, nullptr);
}
QT_WARNING_POP
