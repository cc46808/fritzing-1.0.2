/****************************************************************************
** Meta object code from reading C++ file 'fapplication.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/fapplication.h"
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fapplication.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSFServerENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSFServerENDCLASS = QtMocHelpers::stringData(
    "FServer",
    "newConnection",
    "",
    "qintptr",
    "socketDescriptor"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSFServerENDCLASS_t {
    uint offsetsAndSizes[10];
    char stringdata0[8];
    char stringdata1[14];
    char stringdata2[1];
    char stringdata3[8];
    char stringdata4[17];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSFServerENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSFServerENDCLASS_t qt_meta_stringdata_CLASSFServerENDCLASS = {
    {
        QT_MOC_LITERAL(0, 7),  // "FServer"
        QT_MOC_LITERAL(8, 13),  // "newConnection"
        QT_MOC_LITERAL(22, 0),  // ""
        QT_MOC_LITERAL(23, 7),  // "qintptr"
        QT_MOC_LITERAL(31, 16)   // "socketDescriptor"
    },
    "FServer",
    "newConnection",
    "",
    "qintptr",
    "socketDescriptor"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSFServerENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   20,    2, 0x06,    1 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

       0        // eod
};

Q_CONSTINIT const QMetaObject FServer::staticMetaObject = { {
    QMetaObject::SuperData::link<QTcpServer::staticMetaObject>(),
    qt_meta_stringdata_CLASSFServerENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSFServerENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSFServerENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FServer, std::true_type>,
        // method 'newConnection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<qintptr, std::false_type>
    >,
    nullptr
} };

void FServer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FServer *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->newConnection((*reinterpret_cast< std::add_pointer_t<qintptr>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FServer::*)(qintptr );
            if (_t _q_method = &FServer::newConnection; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *FServer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FServer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSFServerENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QTcpServer::qt_metacast(_clname);
}

int FServer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTcpServer::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void FServer::newConnection(qintptr _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSFServerThreadENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSFServerThreadENDCLASS = QtMocHelpers::stringData(
    "FServerThread",
    "error",
    "",
    "QTcpSocket::SocketError",
    "socketError",
    "doCommand",
    "command",
    "params",
    "QString&",
    "result",
    "int&",
    "status"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSFServerThreadENDCLASS_t {
    uint offsetsAndSizes[24];
    char stringdata0[14];
    char stringdata1[6];
    char stringdata2[1];
    char stringdata3[24];
    char stringdata4[12];
    char stringdata5[10];
    char stringdata6[8];
    char stringdata7[7];
    char stringdata8[9];
    char stringdata9[7];
    char stringdata10[5];
    char stringdata11[7];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSFServerThreadENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSFServerThreadENDCLASS_t qt_meta_stringdata_CLASSFServerThreadENDCLASS = {
    {
        QT_MOC_LITERAL(0, 13),  // "FServerThread"
        QT_MOC_LITERAL(14, 5),  // "error"
        QT_MOC_LITERAL(20, 0),  // ""
        QT_MOC_LITERAL(21, 23),  // "QTcpSocket::SocketError"
        QT_MOC_LITERAL(45, 11),  // "socketError"
        QT_MOC_LITERAL(57, 9),  // "doCommand"
        QT_MOC_LITERAL(67, 7),  // "command"
        QT_MOC_LITERAL(75, 6),  // "params"
        QT_MOC_LITERAL(82, 8),  // "QString&"
        QT_MOC_LITERAL(91, 6),  // "result"
        QT_MOC_LITERAL(98, 4),  // "int&"
        QT_MOC_LITERAL(103, 6)   // "status"
    },
    "FServerThread",
    "error",
    "",
    "QTcpSocket::SocketError",
    "socketError",
    "doCommand",
    "command",
    "params",
    "QString&",
    "result",
    "int&",
    "status"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSFServerThreadENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   26,    2, 0x06,    1 /* Public */,
       5,    4,   29,    2, 0x06,    3 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, 0x80000000 | 8, 0x80000000 | 10,    6,    7,    9,   11,

       0        // eod
};

Q_CONSTINIT const QMetaObject FServerThread::staticMetaObject = { {
    QMetaObject::SuperData::link<QThread::staticMetaObject>(),
    qt_meta_stringdata_CLASSFServerThreadENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSFServerThreadENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSFServerThreadENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FServerThread, std::true_type>,
        // method 'error'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTcpSocket::SocketError, std::false_type>,
        // method 'doCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<int &, std::false_type>
    >,
    nullptr
} };

void FServerThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FServerThread *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->error((*reinterpret_cast< std::add_pointer_t<QTcpSocket::SocketError>>(_a[1]))); break;
        case 1: _t->doCommand((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<int&>>(_a[4]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FServerThread::*)(QTcpSocket::SocketError );
            if (_t _q_method = &FServerThread::error; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FServerThread::*)(const QString & , const QString & , QString & , int & );
            if (_t _q_method = &FServerThread::doCommand; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject *FServerThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FServerThread::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSFServerThreadENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QThread::qt_metacast(_clname);
}

int FServerThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void FServerThread::error(QTcpSocket::SocketError _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void FServerThread::doCommand(const QString & _t1, const QString & _t2, QString & _t3, int & _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSRegenerateDatabaseThreadENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSRegenerateDatabaseThreadENDCLASS = QtMocHelpers::stringData(
    "RegenerateDatabaseThread"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSRegenerateDatabaseThreadENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[25];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSRegenerateDatabaseThreadENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSRegenerateDatabaseThreadENDCLASS_t qt_meta_stringdata_CLASSRegenerateDatabaseThreadENDCLASS = {
    {
        QT_MOC_LITERAL(0, 24)   // "RegenerateDatabaseThread"
    },
    "RegenerateDatabaseThread"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSRegenerateDatabaseThreadENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject RegenerateDatabaseThread::staticMetaObject = { {
    QMetaObject::SuperData::link<QThread::staticMetaObject>(),
    qt_meta_stringdata_CLASSRegenerateDatabaseThreadENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSRegenerateDatabaseThreadENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSRegenerateDatabaseThreadENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<RegenerateDatabaseThread, std::true_type>
    >,
    nullptr
} };

void RegenerateDatabaseThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *RegenerateDatabaseThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RegenerateDatabaseThread::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSRegenerateDatabaseThreadENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QThread::qt_metacast(_clname);
}

int RegenerateDatabaseThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSFApplicationENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSFApplicationENDCLASS = QtMocHelpers::stringData(
    "FApplication",
    "spaceBarIsPressedSignal",
    "",
    "preferences",
    "preferencesAfter",
    "checkForUpdates",
    "atUserRequest",
    "enableCheckUpdates",
    "enabled",
    "createUserDataStoreFolderStructures",
    "changeActivation",
    "activate",
    "QWidget*",
    "originator",
    "updateActivation",
    "topLevelWidgetDestroyed",
    "closeAllWindows2",
    "loadedPart",
    "loaded",
    "total",
    "externalProcessSlot",
    "QString&",
    "name",
    "path",
    "QStringList&",
    "args",
    "gotOrderFab",
    "QNetworkReply*",
    "newConnection",
    "qintptr",
    "socketDescriptor",
    "doCommand",
    "command",
    "params",
    "result",
    "int&",
    "status",
    "regeneratePartsDatabase",
    "regenerateDatabaseFinished",
    "installNewParts"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSFApplicationENDCLASS_t {
    uint offsetsAndSizes[80];
    char stringdata0[13];
    char stringdata1[24];
    char stringdata2[1];
    char stringdata3[12];
    char stringdata4[17];
    char stringdata5[16];
    char stringdata6[14];
    char stringdata7[19];
    char stringdata8[8];
    char stringdata9[36];
    char stringdata10[17];
    char stringdata11[9];
    char stringdata12[9];
    char stringdata13[11];
    char stringdata14[17];
    char stringdata15[24];
    char stringdata16[17];
    char stringdata17[11];
    char stringdata18[7];
    char stringdata19[6];
    char stringdata20[20];
    char stringdata21[9];
    char stringdata22[5];
    char stringdata23[5];
    char stringdata24[13];
    char stringdata25[5];
    char stringdata26[12];
    char stringdata27[15];
    char stringdata28[14];
    char stringdata29[8];
    char stringdata30[17];
    char stringdata31[10];
    char stringdata32[8];
    char stringdata33[7];
    char stringdata34[7];
    char stringdata35[5];
    char stringdata36[7];
    char stringdata37[24];
    char stringdata38[27];
    char stringdata39[16];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSFApplicationENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSFApplicationENDCLASS_t qt_meta_stringdata_CLASSFApplicationENDCLASS = {
    {
        QT_MOC_LITERAL(0, 12),  // "FApplication"
        QT_MOC_LITERAL(13, 23),  // "spaceBarIsPressedSignal"
        QT_MOC_LITERAL(37, 0),  // ""
        QT_MOC_LITERAL(38, 11),  // "preferences"
        QT_MOC_LITERAL(50, 16),  // "preferencesAfter"
        QT_MOC_LITERAL(67, 15),  // "checkForUpdates"
        QT_MOC_LITERAL(83, 13),  // "atUserRequest"
        QT_MOC_LITERAL(97, 18),  // "enableCheckUpdates"
        QT_MOC_LITERAL(116, 7),  // "enabled"
        QT_MOC_LITERAL(124, 35),  // "createUserDataStoreFolderStru..."
        QT_MOC_LITERAL(160, 16),  // "changeActivation"
        QT_MOC_LITERAL(177, 8),  // "activate"
        QT_MOC_LITERAL(186, 8),  // "QWidget*"
        QT_MOC_LITERAL(195, 10),  // "originator"
        QT_MOC_LITERAL(206, 16),  // "updateActivation"
        QT_MOC_LITERAL(223, 23),  // "topLevelWidgetDestroyed"
        QT_MOC_LITERAL(247, 16),  // "closeAllWindows2"
        QT_MOC_LITERAL(264, 10),  // "loadedPart"
        QT_MOC_LITERAL(275, 6),  // "loaded"
        QT_MOC_LITERAL(282, 5),  // "total"
        QT_MOC_LITERAL(288, 19),  // "externalProcessSlot"
        QT_MOC_LITERAL(308, 8),  // "QString&"
        QT_MOC_LITERAL(317, 4),  // "name"
        QT_MOC_LITERAL(322, 4),  // "path"
        QT_MOC_LITERAL(327, 12),  // "QStringList&"
        QT_MOC_LITERAL(340, 4),  // "args"
        QT_MOC_LITERAL(345, 11),  // "gotOrderFab"
        QT_MOC_LITERAL(357, 14),  // "QNetworkReply*"
        QT_MOC_LITERAL(372, 13),  // "newConnection"
        QT_MOC_LITERAL(386, 7),  // "qintptr"
        QT_MOC_LITERAL(394, 16),  // "socketDescriptor"
        QT_MOC_LITERAL(411, 9),  // "doCommand"
        QT_MOC_LITERAL(421, 7),  // "command"
        QT_MOC_LITERAL(429, 6),  // "params"
        QT_MOC_LITERAL(436, 6),  // "result"
        QT_MOC_LITERAL(443, 4),  // "int&"
        QT_MOC_LITERAL(448, 6),  // "status"
        QT_MOC_LITERAL(455, 23),  // "regeneratePartsDatabase"
        QT_MOC_LITERAL(479, 26),  // "regenerateDatabaseFinished"
        QT_MOC_LITERAL(506, 15)   // "installNewParts"
    },
    "FApplication",
    "spaceBarIsPressedSignal",
    "",
    "preferences",
    "preferencesAfter",
    "checkForUpdates",
    "atUserRequest",
    "enableCheckUpdates",
    "enabled",
    "createUserDataStoreFolderStructures",
    "changeActivation",
    "activate",
    "QWidget*",
    "originator",
    "updateActivation",
    "topLevelWidgetDestroyed",
    "closeAllWindows2",
    "loadedPart",
    "loaded",
    "total",
    "externalProcessSlot",
    "QString&",
    "name",
    "path",
    "QStringList&",
    "args",
    "gotOrderFab",
    "QNetworkReply*",
    "newConnection",
    "qintptr",
    "socketDescriptor",
    "doCommand",
    "command",
    "params",
    "result",
    "int&",
    "status",
    "regeneratePartsDatabase",
    "regenerateDatabaseFinished",
    "installNewParts"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSFApplicationENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  128,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,  131,    2, 0x0a,    3 /* Public */,
       4,    0,  132,    2, 0x0a,    4 /* Public */,
       5,    0,  133,    2, 0x0a,    5 /* Public */,
       5,    1,  134,    2, 0x0a,    6 /* Public */,
       7,    1,  137,    2, 0x0a,    8 /* Public */,
       9,    0,  140,    2, 0x0a,   10 /* Public */,
      10,    2,  141,    2, 0x0a,   11 /* Public */,
      14,    0,  146,    2, 0x0a,   14 /* Public */,
      15,    1,  147,    2, 0x0a,   15 /* Public */,
      16,    0,  150,    2, 0x0a,   17 /* Public */,
      17,    2,  151,    2, 0x0a,   18 /* Public */,
      20,    3,  156,    2, 0x0a,   21 /* Public */,
      26,    1,  163,    2, 0x0a,   25 /* Public */,
      28,    1,  166,    2, 0x0a,   27 /* Public */,
      31,    4,  169,    2, 0x0a,   29 /* Public */,
      37,    0,  178,    2, 0x0a,   34 /* Public */,
      38,    0,  179,    2, 0x0a,   35 /* Public */,
      39,    0,  180,    2, 0x0a,   36 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    6,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 12,   11,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QObjectStar,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   18,   19,
    QMetaType::Void, 0x80000000 | 21, 0x80000000 | 21, 0x80000000 | 24,   22,   23,   25,
    QMetaType::Void, 0x80000000 | 27,    2,
    QMetaType::Void, 0x80000000 | 29,   30,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, 0x80000000 | 21, 0x80000000 | 35,   32,   33,   34,   36,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject FApplication::staticMetaObject = { {
    QMetaObject::SuperData::link<QApplication::staticMetaObject>(),
    qt_meta_stringdata_CLASSFApplicationENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSFApplicationENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSFApplicationENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FApplication, std::true_type>,
        // method 'spaceBarIsPressedSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'preferences'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'preferencesAfter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'checkForUpdates'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'checkForUpdates'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'enableCheckUpdates'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'createUserDataStoreFolderStructures'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'changeActivation'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QWidget *, std::false_type>,
        // method 'updateActivation'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'topLevelWidgetDestroyed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QObject *, std::false_type>,
        // method 'closeAllWindows2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loadedPart'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'externalProcessSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStringList &, std::false_type>,
        // method 'gotOrderFab'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QNetworkReply *, std::false_type>,
        // method 'newConnection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<qintptr, std::false_type>,
        // method 'doCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<int &, std::false_type>,
        // method 'regeneratePartsDatabase'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'regenerateDatabaseFinished'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'installNewParts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void FApplication::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FApplication *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->spaceBarIsPressedSignal((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 1: _t->preferences(); break;
        case 2: _t->preferencesAfter(); break;
        case 3: _t->checkForUpdates(); break;
        case 4: _t->checkForUpdates((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 5: _t->enableCheckUpdates((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 6: _t->createUserDataStoreFolderStructures(); break;
        case 7: _t->changeActivation((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QWidget*>>(_a[2]))); break;
        case 8: _t->updateActivation(); break;
        case 9: _t->topLevelWidgetDestroyed((*reinterpret_cast< std::add_pointer_t<QObject*>>(_a[1]))); break;
        case 10: _t->closeAllWindows2(); break;
        case 11: _t->loadedPart((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 12: _t->externalProcessSlot((*reinterpret_cast< std::add_pointer_t<QString&>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString&>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QStringList&>>(_a[3]))); break;
        case 13: _t->gotOrderFab((*reinterpret_cast< std::add_pointer_t<QNetworkReply*>>(_a[1]))); break;
        case 14: _t->newConnection((*reinterpret_cast< std::add_pointer_t<qintptr>>(_a[1]))); break;
        case 15: _t->doCommand((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<int&>>(_a[4]))); break;
        case 16: _t->regeneratePartsDatabase(); break;
        case 17: _t->regenerateDatabaseFinished(); break;
        case 18: _t->installNewParts(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 1:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QWidget* >(); break;
            }
            break;
        case 13:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QNetworkReply* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FApplication::*)(bool );
            if (_t _q_method = &FApplication::spaceBarIsPressedSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *FApplication::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FApplication::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSFApplicationENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QApplication::qt_metacast(_clname);
}

int FApplication::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QApplication::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    }
    return _id;
}

// SIGNAL 0
void FApplication::spaceBarIsPressedSignal(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
