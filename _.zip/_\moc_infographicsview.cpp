/****************************************************************************
** Meta object code from reading C++ file 'infographicsview.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/sketch/infographicsview.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'infographicsview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSInfoGraphicsViewENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSInfoGraphicsViewENDCLASS = QtMocHelpers::stringData(
    "InfoGraphicsView",
    "setVoltageSignal",
    "",
    "doEmit",
    "swapSignal",
    "family",
    "prop",
    "QMap<QString,QString>&",
    "propsMap",
    "ItemBase*",
    "changePinLabelsSignal",
    "setActiveWireSignal",
    "Wire*",
    "setActiveConnectorItemSignal",
    "ConnectorItem*",
    "newWireSignal",
    "setVoltage",
    "resizeBoard",
    "w",
    "h",
    "setInstanceTitleForCommand",
    "id",
    "oldTitle",
    "newTitle",
    "isUndoable"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSInfoGraphicsViewENDCLASS_t {
    uint offsetsAndSizes[50];
    char stringdata0[17];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[7];
    char stringdata4[11];
    char stringdata5[7];
    char stringdata6[5];
    char stringdata7[23];
    char stringdata8[9];
    char stringdata9[10];
    char stringdata10[22];
    char stringdata11[20];
    char stringdata12[6];
    char stringdata13[29];
    char stringdata14[15];
    char stringdata15[14];
    char stringdata16[11];
    char stringdata17[12];
    char stringdata18[2];
    char stringdata19[2];
    char stringdata20[27];
    char stringdata21[3];
    char stringdata22[9];
    char stringdata23[9];
    char stringdata24[11];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSInfoGraphicsViewENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSInfoGraphicsViewENDCLASS_t qt_meta_stringdata_CLASSInfoGraphicsViewENDCLASS = {
    {
        QT_MOC_LITERAL(0, 16),  // "InfoGraphicsView"
        QT_MOC_LITERAL(17, 16),  // "setVoltageSignal"
        QT_MOC_LITERAL(34, 0),  // ""
        QT_MOC_LITERAL(35, 6),  // "doEmit"
        QT_MOC_LITERAL(42, 10),  // "swapSignal"
        QT_MOC_LITERAL(53, 6),  // "family"
        QT_MOC_LITERAL(60, 4),  // "prop"
        QT_MOC_LITERAL(65, 22),  // "QMap<QString,QString>&"
        QT_MOC_LITERAL(88, 8),  // "propsMap"
        QT_MOC_LITERAL(97, 9),  // "ItemBase*"
        QT_MOC_LITERAL(107, 21),  // "changePinLabelsSignal"
        QT_MOC_LITERAL(129, 19),  // "setActiveWireSignal"
        QT_MOC_LITERAL(149, 5),  // "Wire*"
        QT_MOC_LITERAL(155, 28),  // "setActiveConnectorItemSignal"
        QT_MOC_LITERAL(184, 14),  // "ConnectorItem*"
        QT_MOC_LITERAL(199, 13),  // "newWireSignal"
        QT_MOC_LITERAL(213, 10),  // "setVoltage"
        QT_MOC_LITERAL(224, 11),  // "resizeBoard"
        QT_MOC_LITERAL(236, 1),  // "w"
        QT_MOC_LITERAL(238, 1),  // "h"
        QT_MOC_LITERAL(240, 26),  // "setInstanceTitleForCommand"
        QT_MOC_LITERAL(267, 2),  // "id"
        QT_MOC_LITERAL(270, 8),  // "oldTitle"
        QT_MOC_LITERAL(279, 8),  // "newTitle"
        QT_MOC_LITERAL(288, 10)   // "isUndoable"
    },
    "InfoGraphicsView",
    "setVoltageSignal",
    "",
    "doEmit",
    "swapSignal",
    "family",
    "prop",
    "QMap<QString,QString>&",
    "propsMap",
    "ItemBase*",
    "changePinLabelsSignal",
    "setActiveWireSignal",
    "Wire*",
    "setActiveConnectorItemSignal",
    "ConnectorItem*",
    "newWireSignal",
    "setVoltage",
    "resizeBoard",
    "w",
    "h",
    "setInstanceTitleForCommand",
    "id",
    "oldTitle",
    "newTitle",
    "isUndoable"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSInfoGraphicsViewENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   68,    2, 0x06,    1 /* Public */,
       4,    4,   73,    2, 0x06,    4 /* Public */,
      10,    1,   82,    2, 0x06,    9 /* Public */,
      11,    1,   85,    2, 0x06,   11 /* Public */,
      13,    1,   88,    2, 0x06,   13 /* Public */,
      15,    1,   91,    2, 0x06,   15 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      16,    2,   94,    2, 0x0a,   17 /* Public */,
      17,    3,   99,    2, 0x0a,   20 /* Public */,
      20,    5,  106,    2, 0x0a,   24 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::Bool,    2,    3,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, 0x80000000 | 7, 0x80000000 | 9,    5,    6,    8,    2,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void, 0x80000000 | 12,    2,
    QMetaType::Void, 0x80000000 | 14,    2,
    QMetaType::Void, 0x80000000 | 12,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Double, QMetaType::Bool,    2,    3,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Bool,   18,   19,    3,
    QMetaType::Void, QMetaType::Long, QMetaType::QString, QMetaType::QString, QMetaType::Bool, QMetaType::Bool,   21,   22,   23,   24,    3,

       0        // eod
};

Q_CONSTINIT const QMetaObject InfoGraphicsView::staticMetaObject = { {
    QMetaObject::SuperData::link<ZoomableGraphicsView::staticMetaObject>(),
    qt_meta_stringdata_CLASSInfoGraphicsViewENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSInfoGraphicsViewENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSInfoGraphicsViewENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<InfoGraphicsView, std::true_type>,
        // method 'setVoltageSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'swapSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<QMap<QString,QString> &, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        // method 'changePinLabelsSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ItemBase *, std::false_type>,
        // method 'setActiveWireSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        // method 'setActiveConnectorItemSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ConnectorItem *, std::false_type>,
        // method 'newWireSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<Wire *, std::false_type>,
        // method 'setVoltage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'resizeBoard'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<double, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'setInstanceTitleForCommand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<long, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>
    >,
    nullptr
} };

void InfoGraphicsView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<InfoGraphicsView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->setVoltageSignal((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 1: _t->swapSignal((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QMap<QString,QString>&>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[4]))); break;
        case 2: _t->changePinLabelsSignal((*reinterpret_cast< std::add_pointer_t<ItemBase*>>(_a[1]))); break;
        case 3: _t->setActiveWireSignal((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1]))); break;
        case 4: _t->setActiveConnectorItemSignal((*reinterpret_cast< std::add_pointer_t<ConnectorItem*>>(_a[1]))); break;
        case 5: _t->newWireSignal((*reinterpret_cast< std::add_pointer_t<Wire*>>(_a[1]))); break;
        case 6: _t->setVoltage((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 7: _t->resizeBoard((*reinterpret_cast< std::add_pointer_t<double>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<double>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 8: _t->setInstanceTitleForCommand((*reinterpret_cast< std::add_pointer_t<long>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[5]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 3:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< ItemBase* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (InfoGraphicsView::*)(double , bool );
            if (_t _q_method = &InfoGraphicsView::setVoltageSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (InfoGraphicsView::*)(const QString & , const QString & , QMap<QString,QString> & , ItemBase * );
            if (_t _q_method = &InfoGraphicsView::swapSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (InfoGraphicsView::*)(ItemBase * );
            if (_t _q_method = &InfoGraphicsView::changePinLabelsSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (InfoGraphicsView::*)(Wire * );
            if (_t _q_method = &InfoGraphicsView::setActiveWireSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (InfoGraphicsView::*)(ConnectorItem * );
            if (_t _q_method = &InfoGraphicsView::setActiveConnectorItemSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (InfoGraphicsView::*)(Wire * );
            if (_t _q_method = &InfoGraphicsView::newWireSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    }
}

const QMetaObject *InfoGraphicsView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *InfoGraphicsView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSInfoGraphicsViewENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return ZoomableGraphicsView::qt_metacast(_clname);
}

int InfoGraphicsView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ZoomableGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void InfoGraphicsView::setVoltageSignal(double _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void InfoGraphicsView::swapSignal(const QString & _t1, const QString & _t2, QMap<QString,QString> & _t3, ItemBase * _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void InfoGraphicsView::changePinLabelsSignal(ItemBase * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void InfoGraphicsView::setActiveWireSignal(Wire * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void InfoGraphicsView::setActiveConnectorItemSignal(ConnectorItem * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void InfoGraphicsView::newWireSignal(Wire * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_WARNING_POP
