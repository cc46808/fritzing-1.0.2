/****************************************************************************
** Meta object code from reading C++ file 'updatedialog.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/version/updatedialog.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'updatedialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSUpdateDialogENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSUpdateDialogENDCLASS = QtMocHelpers::stringData(
    "UpdateDialog",
    "enableAgainSignal",
    "",
    "enable",
    "installNewParts",
    "releasesAvailableSlot",
    "partsAvailableSlot",
    "xmlErrorSlot",
    "QXmlStreamReader::Error",
    "errorCode",
    "httpErrorSlot",
    "QNetworkReply::NetworkError",
    "jsonPartsErrorSlot",
    "error",
    "httpPartsErrorSlot",
    "stopClose",
    "updateParts",
    "onCleanRepo",
    "ModFileDialog*",
    "modFileDialog",
    "openInBrowser"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSUpdateDialogENDCLASS_t {
    uint offsetsAndSizes[42];
    char stringdata0[13];
    char stringdata1[18];
    char stringdata2[1];
    char stringdata3[7];
    char stringdata4[16];
    char stringdata5[22];
    char stringdata6[19];
    char stringdata7[13];
    char stringdata8[24];
    char stringdata9[10];
    char stringdata10[14];
    char stringdata11[28];
    char stringdata12[19];
    char stringdata13[6];
    char stringdata14[19];
    char stringdata15[10];
    char stringdata16[12];
    char stringdata17[12];
    char stringdata18[15];
    char stringdata19[14];
    char stringdata20[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSUpdateDialogENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSUpdateDialogENDCLASS_t qt_meta_stringdata_CLASSUpdateDialogENDCLASS = {
    {
        QT_MOC_LITERAL(0, 12),  // "UpdateDialog"
        QT_MOC_LITERAL(13, 17),  // "enableAgainSignal"
        QT_MOC_LITERAL(31, 0),  // ""
        QT_MOC_LITERAL(32, 6),  // "enable"
        QT_MOC_LITERAL(39, 15),  // "installNewParts"
        QT_MOC_LITERAL(55, 21),  // "releasesAvailableSlot"
        QT_MOC_LITERAL(77, 18),  // "partsAvailableSlot"
        QT_MOC_LITERAL(96, 12),  // "xmlErrorSlot"
        QT_MOC_LITERAL(109, 23),  // "QXmlStreamReader::Error"
        QT_MOC_LITERAL(133, 9),  // "errorCode"
        QT_MOC_LITERAL(143, 13),  // "httpErrorSlot"
        QT_MOC_LITERAL(157, 27),  // "QNetworkReply::NetworkError"
        QT_MOC_LITERAL(185, 18),  // "jsonPartsErrorSlot"
        QT_MOC_LITERAL(204, 5),  // "error"
        QT_MOC_LITERAL(210, 18),  // "httpPartsErrorSlot"
        QT_MOC_LITERAL(229, 9),  // "stopClose"
        QT_MOC_LITERAL(239, 11),  // "updateParts"
        QT_MOC_LITERAL(251, 11),  // "onCleanRepo"
        QT_MOC_LITERAL(263, 14),  // "ModFileDialog*"
        QT_MOC_LITERAL(278, 13),  // "modFileDialog"
        QT_MOC_LITERAL(292, 13)   // "openInBrowser"
    },
    "UpdateDialog",
    "enableAgainSignal",
    "",
    "enable",
    "installNewParts",
    "releasesAvailableSlot",
    "partsAvailableSlot",
    "xmlErrorSlot",
    "QXmlStreamReader::Error",
    "errorCode",
    "httpErrorSlot",
    "QNetworkReply::NetworkError",
    "jsonPartsErrorSlot",
    "error",
    "httpPartsErrorSlot",
    "stopClose",
    "updateParts",
    "onCleanRepo",
    "ModFileDialog*",
    "modFileDialog",
    "openInBrowser"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSUpdateDialogENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   86,    2, 0x06,    1 /* Public */,
       4,    0,   89,    2, 0x06,    3 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       5,    0,   90,    2, 0x09,    4 /* Protected */,
       6,    0,   91,    2, 0x09,    5 /* Protected */,
       7,    1,   92,    2, 0x09,    6 /* Protected */,
      10,    1,   95,    2, 0x09,    8 /* Protected */,
      12,    1,   98,    2, 0x09,   10 /* Protected */,
      14,    1,  101,    2, 0x09,   12 /* Protected */,
      15,    0,  104,    2, 0x09,   14 /* Protected */,
      16,    0,  105,    2, 0x09,   15 /* Protected */,
      17,    1,  106,    2, 0x09,   16 /* Protected */,
      20,    0,  109,    2, 0x09,   18 /* Protected */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 8,    9,
    QMetaType::Void, 0x80000000 | 11,    2,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 18,   19,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject UpdateDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSUpdateDialogENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSUpdateDialogENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSUpdateDialogENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<UpdateDialog, std::true_type>,
        // method 'enableAgainSignal'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'installNewParts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'releasesAvailableSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'partsAvailableSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'xmlErrorSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QXmlStreamReader::Error, std::false_type>,
        // method 'httpErrorSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QNetworkReply::NetworkError, std::false_type>,
        // method 'jsonPartsErrorSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'httpPartsErrorSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'stopClose'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateParts'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onCleanRepo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModFileDialog *, std::false_type>,
        // method 'openInBrowser'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void UpdateDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<UpdateDialog *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->enableAgainSignal((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 1: _t->installNewParts(); break;
        case 2: _t->releasesAvailableSlot(); break;
        case 3: _t->partsAvailableSlot(); break;
        case 4: _t->xmlErrorSlot((*reinterpret_cast< std::add_pointer_t<QXmlStreamReader::Error>>(_a[1]))); break;
        case 5: _t->httpErrorSlot((*reinterpret_cast< std::add_pointer_t<QNetworkReply::NetworkError>>(_a[1]))); break;
        case 6: _t->jsonPartsErrorSlot((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->httpPartsErrorSlot((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->stopClose(); break;
        case 9: _t->updateParts(); break;
        case 10: _t->onCleanRepo((*reinterpret_cast< std::add_pointer_t<ModFileDialog*>>(_a[1]))); break;
        case 11: _t->openInBrowser(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QNetworkReply::NetworkError >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (UpdateDialog::*)(bool );
            if (_t _q_method = &UpdateDialog::enableAgainSignal; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (UpdateDialog::*)();
            if (_t _q_method = &UpdateDialog::installNewParts; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject *UpdateDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *UpdateDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSUpdateDialogENDCLASS.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "PartsCheckerUpdateInterface"))
        return static_cast< PartsCheckerUpdateInterface*>(this);
    return QDialog::qt_metacast(_clname);
}

int UpdateDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void UpdateDialog::enableAgainSignal(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void UpdateDialog::installNewParts()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
