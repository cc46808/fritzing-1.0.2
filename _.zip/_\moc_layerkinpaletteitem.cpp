/****************************************************************************
** Meta object code from reading C++ file 'layerkinpaletteitem.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/items/layerkinpaletteitem.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'layerkinpaletteitem.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSLayerKinPaletteItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSLayerKinPaletteItemENDCLASS = QtMocHelpers::stringData(
    "LayerKinPaletteItem"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSLayerKinPaletteItemENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSLayerKinPaletteItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSLayerKinPaletteItemENDCLASS_t qt_meta_stringdata_CLASSLayerKinPaletteItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 19)   // "LayerKinPaletteItem"
    },
    "LayerKinPaletteItem"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSLayerKinPaletteItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject LayerKinPaletteItem::staticMetaObject = { {
    QMetaObject::SuperData::link<PaletteItemBase::staticMetaObject>(),
    qt_meta_stringdata_CLASSLayerKinPaletteItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSLayerKinPaletteItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSLayerKinPaletteItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<LayerKinPaletteItem, std::true_type>
    >,
    nullptr
} };

void LayerKinPaletteItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *LayerKinPaletteItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LayerKinPaletteItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSLayerKinPaletteItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return PaletteItemBase::qt_metacast(_clname);
}

int LayerKinPaletteItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = PaletteItemBase::qt_metacall(_c, _id, _a);
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSSchematicTextLayerKinPaletteItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSSchematicTextLayerKinPaletteItemENDCLASS = QtMocHelpers::stringData(
    "SchematicTextLayerKinPaletteItem"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSSchematicTextLayerKinPaletteItemENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[33];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSSchematicTextLayerKinPaletteItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSSchematicTextLayerKinPaletteItemENDCLASS_t qt_meta_stringdata_CLASSSchematicTextLayerKinPaletteItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 32)   // "SchematicTextLayerKinPaletteItem"
    },
    "SchematicTextLayerKinPaletteItem"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSSchematicTextLayerKinPaletteItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject SchematicTextLayerKinPaletteItem::staticMetaObject = { {
    QMetaObject::SuperData::link<LayerKinPaletteItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSSchematicTextLayerKinPaletteItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSSchematicTextLayerKinPaletteItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSSchematicTextLayerKinPaletteItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<SchematicTextLayerKinPaletteItem, std::true_type>
    >,
    nullptr
} };

void SchematicTextLayerKinPaletteItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *SchematicTextLayerKinPaletteItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SchematicTextLayerKinPaletteItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSSchematicTextLayerKinPaletteItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return LayerKinPaletteItem::qt_metacast(_clname);
}

int SchematicTextLayerKinPaletteItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = LayerKinPaletteItem::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
