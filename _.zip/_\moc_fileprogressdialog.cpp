/****************************************************************************
** Meta object code from reading C++ file 'fileprogressdialog.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/utils/fileprogressdialog.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fileprogressdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSFileProgressDialogENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSFileProgressDialogENDCLASS = QtMocHelpers::stringData(
    "FileProgressDialog",
    "cancel",
    "",
    "setMinimum",
    "setMaximum",
    "addMaximum",
    "setValue",
    "incValue",
    "setMessage",
    "message",
    "sendCancel",
    "loadingInstancesSlot",
    "ModelBase*",
    "QDomElement&",
    "instances",
    "loadingInstanceSlot",
    "instance",
    "settingItemSlot",
    "updateIndeterminate"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSFileProgressDialogENDCLASS_t {
    uint offsetsAndSizes[38];
    char stringdata0[19];
    char stringdata1[7];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[11];
    char stringdata5[11];
    char stringdata6[9];
    char stringdata7[9];
    char stringdata8[11];
    char stringdata9[8];
    char stringdata10[11];
    char stringdata11[21];
    char stringdata12[11];
    char stringdata13[13];
    char stringdata14[10];
    char stringdata15[20];
    char stringdata16[9];
    char stringdata17[16];
    char stringdata18[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSFileProgressDialogENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSFileProgressDialogENDCLASS_t qt_meta_stringdata_CLASSFileProgressDialogENDCLASS = {
    {
        QT_MOC_LITERAL(0, 18),  // "FileProgressDialog"
        QT_MOC_LITERAL(19, 6),  // "cancel"
        QT_MOC_LITERAL(26, 0),  // ""
        QT_MOC_LITERAL(27, 10),  // "setMinimum"
        QT_MOC_LITERAL(38, 10),  // "setMaximum"
        QT_MOC_LITERAL(49, 10),  // "addMaximum"
        QT_MOC_LITERAL(60, 8),  // "setValue"
        QT_MOC_LITERAL(69, 8),  // "incValue"
        QT_MOC_LITERAL(78, 10),  // "setMessage"
        QT_MOC_LITERAL(89, 7),  // "message"
        QT_MOC_LITERAL(97, 10),  // "sendCancel"
        QT_MOC_LITERAL(108, 20),  // "loadingInstancesSlot"
        QT_MOC_LITERAL(129, 10),  // "ModelBase*"
        QT_MOC_LITERAL(140, 12),  // "QDomElement&"
        QT_MOC_LITERAL(153, 9),  // "instances"
        QT_MOC_LITERAL(163, 19),  // "loadingInstanceSlot"
        QT_MOC_LITERAL(183, 8),  // "instance"
        QT_MOC_LITERAL(192, 15),  // "settingItemSlot"
        QT_MOC_LITERAL(208, 19)   // "updateIndeterminate"
    },
    "FileProgressDialog",
    "cancel",
    "",
    "setMinimum",
    "setMaximum",
    "addMaximum",
    "setValue",
    "incValue",
    "setMessage",
    "message",
    "sendCancel",
    "loadingInstancesSlot",
    "ModelBase*",
    "QDomElement&",
    "instances",
    "loadingInstanceSlot",
    "instance",
    "settingItemSlot",
    "updateIndeterminate"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSFileProgressDialogENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   86,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       3,    1,   87,    2, 0x0a,    2 /* Public */,
       4,    1,   90,    2, 0x0a,    4 /* Public */,
       5,    1,   93,    2, 0x0a,    6 /* Public */,
       6,    1,   96,    2, 0x0a,    8 /* Public */,
       7,    0,   99,    2, 0x0a,   10 /* Public */,
       8,    1,  100,    2, 0x0a,   11 /* Public */,
      10,    0,  103,    2, 0x0a,   13 /* Public */,
      11,    2,  104,    2, 0x0a,   14 /* Public */,
      15,    2,  109,    2, 0x0a,   17 /* Public */,
      17,    0,  114,    2, 0x0a,   20 /* Public */,
      18,    0,  115,    2, 0x09,   21 /* Protected */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 13,    2,   14,
    QMetaType::Void, 0x80000000 | 12, 0x80000000 | 13,    2,   16,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject FileProgressDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSFileProgressDialogENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSFileProgressDialogENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSFileProgressDialogENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FileProgressDialog, std::true_type>,
        // method 'cancel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setMinimum'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setMaximum'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'addMaximum'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setValue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'incValue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'sendCancel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loadingInstancesSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDomElement &, std::false_type>,
        // method 'loadingInstanceSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<ModelBase *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QDomElement &, std::false_type>,
        // method 'settingItemSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateIndeterminate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void FileProgressDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FileProgressDialog *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->cancel(); break;
        case 1: _t->setMinimum((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->setMaximum((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->addMaximum((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 4: _t->setValue((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->incValue(); break;
        case 6: _t->setMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->sendCancel(); break;
        case 8: _t->loadingInstancesSlot((*reinterpret_cast< std::add_pointer_t<ModelBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDomElement&>>(_a[2]))); break;
        case 9: _t->loadingInstanceSlot((*reinterpret_cast< std::add_pointer_t<ModelBase*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QDomElement&>>(_a[2]))); break;
        case 10: _t->settingItemSlot(); break;
        case 11: _t->updateIndeterminate(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FileProgressDialog::*)();
            if (_t _q_method = &FileProgressDialog::cancel; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject *FileProgressDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FileProgressDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSFileProgressDialogENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int FileProgressDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void FileProgressDialog::cancel()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
