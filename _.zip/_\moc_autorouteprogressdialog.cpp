/****************************************************************************
** Meta object code from reading C++ file 'autorouteprogressdialog.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/autoroute/autorouteprogressdialog.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'autorouteprogressdialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSAutorouteProgressDialogENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSAutorouteProgressDialogENDCLASS = QtMocHelpers::stringData(
    "AutorouteProgressDialog",
    "skip",
    "",
    "cancel",
    "stop",
    "best",
    "spinChange",
    "setMinimum",
    "setMaximum",
    "setValue",
    "sendSkip",
    "sendCancel",
    "sendStop",
    "setSpinLabel",
    "setMessage",
    "setMessage2",
    "setSpinValue",
    "disableButtons",
    "sendBest",
    "internalSpinChange"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSAutorouteProgressDialogENDCLASS_t {
    uint offsetsAndSizes[40];
    char stringdata0[24];
    char stringdata1[5];
    char stringdata2[1];
    char stringdata3[7];
    char stringdata4[5];
    char stringdata5[5];
    char stringdata6[11];
    char stringdata7[11];
    char stringdata8[11];
    char stringdata9[9];
    char stringdata10[9];
    char stringdata11[11];
    char stringdata12[9];
    char stringdata13[13];
    char stringdata14[11];
    char stringdata15[12];
    char stringdata16[13];
    char stringdata17[15];
    char stringdata18[9];
    char stringdata19[19];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSAutorouteProgressDialogENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSAutorouteProgressDialogENDCLASS_t qt_meta_stringdata_CLASSAutorouteProgressDialogENDCLASS = {
    {
        QT_MOC_LITERAL(0, 23),  // "AutorouteProgressDialog"
        QT_MOC_LITERAL(24, 4),  // "skip"
        QT_MOC_LITERAL(29, 0),  // ""
        QT_MOC_LITERAL(30, 6),  // "cancel"
        QT_MOC_LITERAL(37, 4),  // "stop"
        QT_MOC_LITERAL(42, 4),  // "best"
        QT_MOC_LITERAL(47, 10),  // "spinChange"
        QT_MOC_LITERAL(58, 10),  // "setMinimum"
        QT_MOC_LITERAL(69, 10),  // "setMaximum"
        QT_MOC_LITERAL(80, 8),  // "setValue"
        QT_MOC_LITERAL(89, 8),  // "sendSkip"
        QT_MOC_LITERAL(98, 10),  // "sendCancel"
        QT_MOC_LITERAL(109, 8),  // "sendStop"
        QT_MOC_LITERAL(118, 12),  // "setSpinLabel"
        QT_MOC_LITERAL(131, 10),  // "setMessage"
        QT_MOC_LITERAL(142, 11),  // "setMessage2"
        QT_MOC_LITERAL(154, 12),  // "setSpinValue"
        QT_MOC_LITERAL(167, 14),  // "disableButtons"
        QT_MOC_LITERAL(182, 8),  // "sendBest"
        QT_MOC_LITERAL(191, 18)   // "internalSpinChange"
    },
    "AutorouteProgressDialog",
    "skip",
    "",
    "cancel",
    "stop",
    "best",
    "spinChange",
    "setMinimum",
    "setMaximum",
    "setValue",
    "sendSkip",
    "sendCancel",
    "sendStop",
    "setSpinLabel",
    "setMessage",
    "setMessage2",
    "setSpinValue",
    "disableButtons",
    "sendBest",
    "internalSpinChange"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSAutorouteProgressDialogENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  122,    2, 0x06,    1 /* Public */,
       3,    0,  123,    2, 0x06,    2 /* Public */,
       4,    0,  124,    2, 0x06,    3 /* Public */,
       5,    0,  125,    2, 0x06,    4 /* Public */,
       6,    1,  126,    2, 0x06,    5 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       7,    1,  129,    2, 0x0a,    7 /* Public */,
       8,    1,  132,    2, 0x0a,    9 /* Public */,
       9,    1,  135,    2, 0x0a,   11 /* Public */,
      10,    0,  138,    2, 0x0a,   13 /* Public */,
      11,    0,  139,    2, 0x0a,   14 /* Public */,
      12,    0,  140,    2, 0x0a,   15 /* Public */,
      13,    1,  141,    2, 0x0a,   16 /* Public */,
      14,    1,  144,    2, 0x0a,   18 /* Public */,
      15,    1,  147,    2, 0x0a,   20 /* Public */,
      16,    1,  150,    2, 0x0a,   22 /* Public */,
      17,    0,  153,    2, 0x0a,   24 /* Public */,
      18,    0,  154,    2, 0x0a,   25 /* Public */,
      19,    1,  155,    2, 0x09,   26 /* Protected */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,

       0        // eod
};

Q_CONSTINIT const QMetaObject AutorouteProgressDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_CLASSAutorouteProgressDialogENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSAutorouteProgressDialogENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSAutorouteProgressDialogENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<AutorouteProgressDialog, std::true_type>,
        // method 'skip'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cancel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'stop'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'best'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'spinChange'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setMinimum'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setMaximum'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'setValue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'sendSkip'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sendCancel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sendStop'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setSpinLabel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setMessage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setMessage2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setSpinValue'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'disableButtons'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sendBest'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'internalSpinChange'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>
    >,
    nullptr
} };

void AutorouteProgressDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<AutorouteProgressDialog *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->skip(); break;
        case 1: _t->cancel(); break;
        case 2: _t->stop(); break;
        case 3: _t->best(); break;
        case 4: _t->spinChange((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->setMinimum((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->setMaximum((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->setValue((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: _t->sendSkip(); break;
        case 9: _t->sendCancel(); break;
        case 10: _t->sendStop(); break;
        case 11: _t->setSpinLabel((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 12: _t->setMessage((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 13: _t->setMessage2((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 14: _t->setSpinValue((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 15: _t->disableButtons(); break;
        case 16: _t->sendBest(); break;
        case 17: _t->internalSpinChange((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (AutorouteProgressDialog::*)();
            if (_t _q_method = &AutorouteProgressDialog::skip; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (AutorouteProgressDialog::*)();
            if (_t _q_method = &AutorouteProgressDialog::cancel; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (AutorouteProgressDialog::*)();
            if (_t _q_method = &AutorouteProgressDialog::stop; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (AutorouteProgressDialog::*)();
            if (_t _q_method = &AutorouteProgressDialog::best; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (AutorouteProgressDialog::*)(int );
            if (_t _q_method = &AutorouteProgressDialog::spinChange; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
    }
}

const QMetaObject *AutorouteProgressDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AutorouteProgressDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSAutorouteProgressDialogENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int AutorouteProgressDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void AutorouteProgressDialog::skip()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void AutorouteProgressDialog::cancel()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void AutorouteProgressDialog::stop()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void AutorouteProgressDialog::best()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void AutorouteProgressDialog::spinChange(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSArrowButtonENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSArrowButtonENDCLASS = QtMocHelpers::stringData(
    "ArrowButton"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSArrowButtonENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[12];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSArrowButtonENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSArrowButtonENDCLASS_t qt_meta_stringdata_CLASSArrowButtonENDCLASS = {
    {
        QT_MOC_LITERAL(0, 11)   // "ArrowButton"
    },
    "ArrowButton"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSArrowButtonENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject ArrowButton::staticMetaObject = { {
    QMetaObject::SuperData::link<QLabel::staticMetaObject>(),
    qt_meta_stringdata_CLASSArrowButtonENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSArrowButtonENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSArrowButtonENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ArrowButton, std::true_type>
    >,
    nullptr
} };

void ArrowButton::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *ArrowButton::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ArrowButton::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSArrowButtonENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QLabel::qt_metacast(_clname);
}

int ArrowButton::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QLabel::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
