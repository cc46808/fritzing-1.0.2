/****************************************************************************
** Meta object code from reading C++ file 'welcomeview.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fritzing-app/src/sketch/welcomeview.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'welcomeview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSCustomListItemENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSCustomListItemENDCLASS = QtMocHelpers::stringData(
    "CustomListItem",
    "leftItemClicked",
    "",
    "data",
    "rightItemClicked",
    "onLeftButtonClicked",
    "onRightButtonClicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSCustomListItemENDCLASS_t {
    uint offsetsAndSizes[14];
    char stringdata0[15];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[5];
    char stringdata4[17];
    char stringdata5[20];
    char stringdata6[21];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSCustomListItemENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSCustomListItemENDCLASS_t qt_meta_stringdata_CLASSCustomListItemENDCLASS = {
    {
        QT_MOC_LITERAL(0, 14),  // "CustomListItem"
        QT_MOC_LITERAL(15, 15),  // "leftItemClicked"
        QT_MOC_LITERAL(31, 0),  // ""
        QT_MOC_LITERAL(32, 4),  // "data"
        QT_MOC_LITERAL(37, 16),  // "rightItemClicked"
        QT_MOC_LITERAL(54, 19),  // "onLeftButtonClicked"
        QT_MOC_LITERAL(74, 20)   // "onRightButtonClicked"
    },
    "CustomListItem",
    "leftItemClicked",
    "",
    "data",
    "rightItemClicked",
    "onLeftButtonClicked",
    "onRightButtonClicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSCustomListItemENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   38,    2, 0x06,    1 /* Public */,
       4,    1,   41,    2, 0x06,    3 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       5,    0,   44,    2, 0x08,    5 /* Private */,
       6,    0,   45,    2, 0x08,    6 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject CustomListItem::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSCustomListItemENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSCustomListItemENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSCustomListItemENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<CustomListItem, std::true_type>,
        // method 'leftItemClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'rightItemClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'onLeftButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onRightButtonClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void CustomListItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CustomListItem *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->leftItemClicked((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->rightItemClicked((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->onLeftButtonClicked(); break;
        case 3: _t->onRightButtonClicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (CustomListItem::*)(const QString & );
            if (_t _q_method = &CustomListItem::leftItemClicked; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (CustomListItem::*)(const QString & );
            if (_t _q_method = &CustomListItem::rightItemClicked; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject *CustomListItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CustomListItem::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSCustomListItemENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int CustomListItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void CustomListItem::leftItemClicked(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CustomListItem::rightItemClicked(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSBlogListWidgetENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSBlogListWidgetENDCLASS = QtMocHelpers::stringData(
    "BlogListWidget",
    "itemEnteredSlot",
    "",
    "QListWidgetItem*",
    "titleTextColor",
    "titleTextFontFamily",
    "titleTextFontSize",
    "titleTextExtraLeading",
    "introTextColor",
    "introTextFontFamily",
    "introTextFontSize",
    "introTextExtraLeading",
    "dateTextColor",
    "dateTextFontFamily",
    "dateTextFontSize"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSBlogListWidgetENDCLASS_t {
    uint offsetsAndSizes[30];
    char stringdata0[15];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[17];
    char stringdata4[15];
    char stringdata5[20];
    char stringdata6[18];
    char stringdata7[22];
    char stringdata8[15];
    char stringdata9[20];
    char stringdata10[18];
    char stringdata11[22];
    char stringdata12[14];
    char stringdata13[19];
    char stringdata14[17];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSBlogListWidgetENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSBlogListWidgetENDCLASS_t qt_meta_stringdata_CLASSBlogListWidgetENDCLASS = {
    {
        QT_MOC_LITERAL(0, 14),  // "BlogListWidget"
        QT_MOC_LITERAL(15, 15),  // "itemEnteredSlot"
        QT_MOC_LITERAL(31, 0),  // ""
        QT_MOC_LITERAL(32, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(49, 14),  // "titleTextColor"
        QT_MOC_LITERAL(64, 19),  // "titleTextFontFamily"
        QT_MOC_LITERAL(84, 17),  // "titleTextFontSize"
        QT_MOC_LITERAL(102, 21),  // "titleTextExtraLeading"
        QT_MOC_LITERAL(124, 14),  // "introTextColor"
        QT_MOC_LITERAL(139, 19),  // "introTextFontFamily"
        QT_MOC_LITERAL(159, 17),  // "introTextFontSize"
        QT_MOC_LITERAL(177, 21),  // "introTextExtraLeading"
        QT_MOC_LITERAL(199, 13),  // "dateTextColor"
        QT_MOC_LITERAL(213, 18),  // "dateTextFontFamily"
        QT_MOC_LITERAL(232, 16)   // "dateTextFontSize"
    },
    "BlogListWidget",
    "itemEnteredSlot",
    "",
    "QListWidgetItem*",
    "titleTextColor",
    "titleTextFontFamily",
    "titleTextFontSize",
    "titleTextExtraLeading",
    "introTextColor",
    "introTextFontFamily",
    "introTextFontSize",
    "introTextExtraLeading",
    "dateTextColor",
    "dateTextFontFamily",
    "dateTextFontSize"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSBlogListWidgetENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
      11,   23, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   20,    2, 0x0a,   12 /* Public */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    2,

 // properties: name, type, flags
       4, QMetaType::QColor, 0x00015103, uint(-1), 0,
       5, QMetaType::QString, 0x00015103, uint(-1), 0,
       6, QMetaType::QString, 0x00015103, uint(-1), 0,
       7, QMetaType::QString, 0x00015103, uint(-1), 0,
       8, QMetaType::QColor, 0x00015103, uint(-1), 0,
       9, QMetaType::QString, 0x00015103, uint(-1), 0,
      10, QMetaType::QString, 0x00015103, uint(-1), 0,
      11, QMetaType::QString, 0x00015103, uint(-1), 0,
      12, QMetaType::QColor, 0x00015103, uint(-1), 0,
      13, QMetaType::QString, 0x00015103, uint(-1), 0,
      14, QMetaType::QString, 0x00015103, uint(-1), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject BlogListWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QListWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSBlogListWidgetENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSBlogListWidgetENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSBlogListWidgetENDCLASS_t,
        // property 'titleTextColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'titleTextFontFamily'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'titleTextFontSize'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'titleTextExtraLeading'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'introTextColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'introTextFontFamily'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'introTextFontSize'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'introTextExtraLeading'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'dateTextColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'dateTextFontFamily'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'dateTextFontSize'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<BlogListWidget, std::true_type>,
        // method 'itemEnteredSlot'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>
    >,
    nullptr
} };

void BlogListWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<BlogListWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->itemEnteredSlot((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        default: ;
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<BlogListWidget *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->titleTextColor(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->titleTextFontFamily(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->titleTextFontSize(); break;
        case 3: *reinterpret_cast< QString*>(_v) = _t->titleTextExtraLeading(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->introTextColor(); break;
        case 5: *reinterpret_cast< QString*>(_v) = _t->introTextFontFamily(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->introTextFontSize(); break;
        case 7: *reinterpret_cast< QString*>(_v) = _t->introTextExtraLeading(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->dateTextColor(); break;
        case 9: *reinterpret_cast< QString*>(_v) = _t->dateTextFontFamily(); break;
        case 10: *reinterpret_cast< QString*>(_v) = _t->dateTextFontSize(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<BlogListWidget *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTitleTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setTitleTextFontFamily(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setTitleTextFontSize(*reinterpret_cast< QString*>(_v)); break;
        case 3: _t->setTitleTextExtraLeading(*reinterpret_cast< QString*>(_v)); break;
        case 4: _t->setIntroTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setIntroTextFontFamily(*reinterpret_cast< QString*>(_v)); break;
        case 6: _t->setIntroTextFontSize(*reinterpret_cast< QString*>(_v)); break;
        case 7: _t->setIntroTextExtraLeading(*reinterpret_cast< QString*>(_v)); break;
        case 8: _t->setDateTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setDateTextFontFamily(*reinterpret_cast< QString*>(_v)); break;
        case 10: _t->setDateTextFontSize(*reinterpret_cast< QString*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *BlogListWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BlogListWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSBlogListWidgetENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QListWidget::qt_metacast(_clname);
}

int BlogListWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QListWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 1;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSWelcomeViewENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSWelcomeViewENDCLASS = QtMocHelpers::stringData(
    "WelcomeView",
    "newSketch",
    "",
    "openSketch",
    "recentSketch",
    "filename",
    "actionText",
    "clickRecent",
    "gotBlogSnippet",
    "QNetworkReply*",
    "gotBlogImage",
    "clickBlog",
    "recentSketchClicked",
    "data",
    "uploadLinkClicked",
    "blogItemClicked",
    "QListWidgetItem*",
    "nextTip"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSWelcomeViewENDCLASS_t {
    uint offsetsAndSizes[36];
    char stringdata0[12];
    char stringdata1[10];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[13];
    char stringdata5[9];
    char stringdata6[11];
    char stringdata7[12];
    char stringdata8[15];
    char stringdata9[15];
    char stringdata10[13];
    char stringdata11[10];
    char stringdata12[20];
    char stringdata13[5];
    char stringdata14[18];
    char stringdata15[16];
    char stringdata16[17];
    char stringdata17[8];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSWelcomeViewENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSWelcomeViewENDCLASS_t qt_meta_stringdata_CLASSWelcomeViewENDCLASS = {
    {
        QT_MOC_LITERAL(0, 11),  // "WelcomeView"
        QT_MOC_LITERAL(12, 9),  // "newSketch"
        QT_MOC_LITERAL(22, 0),  // ""
        QT_MOC_LITERAL(23, 10),  // "openSketch"
        QT_MOC_LITERAL(34, 12),  // "recentSketch"
        QT_MOC_LITERAL(47, 8),  // "filename"
        QT_MOC_LITERAL(56, 10),  // "actionText"
        QT_MOC_LITERAL(67, 11),  // "clickRecent"
        QT_MOC_LITERAL(79, 14),  // "gotBlogSnippet"
        QT_MOC_LITERAL(94, 14),  // "QNetworkReply*"
        QT_MOC_LITERAL(109, 12),  // "gotBlogImage"
        QT_MOC_LITERAL(122, 9),  // "clickBlog"
        QT_MOC_LITERAL(132, 19),  // "recentSketchClicked"
        QT_MOC_LITERAL(152, 4),  // "data"
        QT_MOC_LITERAL(157, 17),  // "uploadLinkClicked"
        QT_MOC_LITERAL(175, 15),  // "blogItemClicked"
        QT_MOC_LITERAL(191, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(208, 7)   // "nextTip"
    },
    "WelcomeView",
    "newSketch",
    "",
    "openSketch",
    "recentSketch",
    "filename",
    "actionText",
    "clickRecent",
    "gotBlogSnippet",
    "QNetworkReply*",
    "gotBlogImage",
    "clickBlog",
    "recentSketchClicked",
    "data",
    "uploadLinkClicked",
    "blogItemClicked",
    "QListWidgetItem*",
    "nextTip"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSWelcomeViewENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   80,    2, 0x06,    1 /* Public */,
       3,    0,   81,    2, 0x06,    2 /* Public */,
       4,    2,   82,    2, 0x06,    3 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       7,    1,   87,    2, 0x09,    6 /* Protected */,
       8,    1,   90,    2, 0x09,    8 /* Protected */,
      10,    1,   93,    2, 0x09,   10 /* Protected */,
      11,    1,   96,    2, 0x09,   12 /* Protected */,
      12,    1,   99,    2, 0x09,   14 /* Protected */,
      14,    1,  102,    2, 0x09,   16 /* Protected */,
      15,    1,  105,    2, 0x09,   18 /* Protected */,
      17,    0,  108,    2, 0x09,   20 /* Protected */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    5,    6,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, 0x80000000 | 16,    2,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject WelcomeView::staticMetaObject = { {
    QMetaObject::SuperData::link<QFrame::staticMetaObject>(),
    qt_meta_stringdata_CLASSWelcomeViewENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSWelcomeViewENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSWelcomeViewENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<WelcomeView, std::true_type>,
        // method 'newSketch'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openSketch'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recentSketch'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'clickRecent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'gotBlogSnippet'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QNetworkReply *, std::false_type>,
        // method 'gotBlogImage'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QNetworkReply *, std::false_type>,
        // method 'clickBlog'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'recentSketchClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'uploadLinkClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'blogItemClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'nextTip'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void WelcomeView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<WelcomeView *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->newSketch(); break;
        case 1: _t->openSketch(); break;
        case 2: _t->recentSketch((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 3: _t->clickRecent((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->gotBlogSnippet((*reinterpret_cast< std::add_pointer_t<QNetworkReply*>>(_a[1]))); break;
        case 5: _t->gotBlogImage((*reinterpret_cast< std::add_pointer_t<QNetworkReply*>>(_a[1]))); break;
        case 6: _t->clickBlog((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->recentSketchClicked((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->uploadLinkClicked((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 9: _t->blogItemClicked((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 10: _t->nextTip(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QNetworkReply* >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QNetworkReply* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (WelcomeView::*)();
            if (_t _q_method = &WelcomeView::newSketch; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (WelcomeView::*)();
            if (_t _q_method = &WelcomeView::openSketch; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (WelcomeView::*)(const QString & , const QString & );
            if (_t _q_method = &WelcomeView::recentSketch; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject *WelcomeView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *WelcomeView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSWelcomeViewENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QFrame::qt_metacast(_clname);
}

int WelcomeView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void WelcomeView::newSketch()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void WelcomeView::openSketch()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void WelcomeView::recentSketch(const QString & _t1, const QString & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSBlogListDelegateENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSBlogListDelegateENDCLASS = QtMocHelpers::stringData(
    "BlogListDelegate"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSBlogListDelegateENDCLASS_t {
    uint offsetsAndSizes[2];
    char stringdata0[17];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSBlogListDelegateENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSBlogListDelegateENDCLASS_t qt_meta_stringdata_CLASSBlogListDelegateENDCLASS = {
    {
        QT_MOC_LITERAL(0, 16)   // "BlogListDelegate"
    },
    "BlogListDelegate"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSBlogListDelegateENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

Q_CONSTINIT const QMetaObject BlogListDelegate::staticMetaObject = { {
    QMetaObject::SuperData::link<QAbstractItemDelegate::staticMetaObject>(),
    qt_meta_stringdata_CLASSBlogListDelegateENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSBlogListDelegateENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSBlogListDelegateENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<BlogListDelegate, std::true_type>
    >,
    nullptr
} };

void BlogListDelegate::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *BlogListDelegate::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BlogListDelegate::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSBlogListDelegateENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QAbstractItemDelegate::qt_metacast(_clname);
}

int BlogListDelegate::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractItemDelegate::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
